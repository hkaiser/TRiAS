/****************************************************************************
 * ximagehandler.h for pvm 2.4
 * Author Joel Welling
 * Motif extension added by Robert Earhart
 * Copyright 1993, Pittsburgh Supercomputing Center, Carnegie Mellon University
 *
 * Permission use, copy, and modify this software and its documentation
 * without fee for personal use or use within your organization is hereby
 * granted, provided that the above copyright notice is preserved in all
 * copies and that that copyright and this permission notice appear in
 * supporting documentation.  Permission to redistribute this software to
 * other organizations or individuals is not granted;  that must be
 * negotiated with the PSC.  Neither the PSC nor Carnegie Mellon
 * University make any representations about the suitability of this
 * software for any purpose.  It is provided "as is" without express or
 * implied warranty.
 *****************************************************************************/

/**
 **	$Header: /sdsc/dev/vis/image/imtools/v3.0/imxdisplay/src/RCS/ximagehandler.h,v 1.5 94/06/30 15:14:17 secoskyj Exp $
 **	Copyright (c) 1989-1994  San Diego Supercomputer Center (SDSC)
 **		a division of General Atomics, San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/


/**
 **  FILE
 **	ximagehander.h	-  
 **
 **  PROJECT
 **	IM		-  
 **
 **  DESCRIPTION
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	ximagehandler.h,v $
 **	Revision 1.5  94/06/30  15:14:17  secoskyj
 **	Added member functions and #define's to support shared color routines
 **	
 **	Revision 1.4  94/05/27  20:00:40  secoskyj
 **	More robustly working with switching btwn dither and perfect color
 **	Will reread the files back in between dither and not dithered
 **	
 **	Revision 1.3  94/05/18  10:12:10  secoskyj
 **	Working is pseudocolor with colormaps changing.
 **	
 **	Revision 1.2  94/03/23  18:08:21  secoskyj
 **	Removed HEADER definition
 **	
 **	Revision 1.1  94/03/23  17:31:46  secoskyj
 **	Initial revision
 **	
 **	
 **/


#include <math.h>

#define XIH_VCUSTOM	(1)
#define XIH_VPSEUDO	(2)
#define XIH_VSHARED	(3)

class rgbImage;

#ifndef AVOID_XVIEW
class xvautoimagehandler_window1_objects;
#endif

XVisualInfo *get_best_visual(Display *dpy, int screen);

class XImageHandler : public baseImageHandler {
public:
  XImageHandler( Display *dpy_in, int screen_in, Window win_in );
  ~XImageHandler();
  void display( rgbImage *image , short refresh=1);
  void redraw();
  void resize();
  void installClt();
  void unInstallClt();
  int xsize() const { return (int)win_x_size; }
  int ysize() const { return (int)win_y_size; }
  void resetMapInfo();
private:
  Boolean inited;
  void get_window_size();
  void (XImageHandler::*display_fun)(XImage *ximage);
  void (XImageHandler::*init_fun)();
  void monochrome_display(XImage *ximage);
  void pseudocolor_display(XImage *ximage);
  void directcolor_display(XImage *ximage);
  void customcolor_display(XImage *ximage);
  void sharedcolor_display(XImage *ximage);
  void monochrome_init();
  void pseudocolor_init();
  void directcolor_init();
  void customcolor_init();
  void sharedcolor_init();
  int server_is_sun_or_hp();
  void generate_sun_rgbmap();
  void generate_cust_rgbmap();
  int XIHAllocColorsFromClt( ImClt *clt );
  Display *dpy;
  int screen;
  Window win;
  int depth;
  Visual *visual;
  Pixmap current_pixmap;
#ifdef NOTDEF
  static XStandardColormap map_info;
#endif
  XStandardColormap map_info;
  static int map_info_set;
  GC gc;
  unsigned long *pixelMap;
  unsigned int win_x_size, win_y_size, image_x_size, image_y_size;
  long rgb_to_intensity( long r, long g, long b )
    {
      // We assume incoming values are 0 to 255
      return( (77*r + 151*g + 27*b) / 256 );
    }
  XImage *ximage;
#ifdef LOCAL
  Boolean using_local;
#else
#ifdef SHM
  Boolean using_shm;
  XShmSegmentInfo shminfo;
#endif /* SHM */
#endif /* LOCAL */
}; 

#ifndef AVOID_XVIEW
class XvautoImageHandler : public baseImageHandler {
public:
  XvautoImageHandler( rgbImage *image, char *name );
  ~XvautoImageHandler();
  void display( rgbImage *image, short refresh=1);
  static Attr_attribute WIN_IHANDLER_KEY;
  static Attr_attribute WIN_AUTOHANDLER_KEY;
  int xsize() const { return ihandler->xsize(); }
  int ysize() const { return ihandler->ysize(); }
private:
  xvautoimagehandler_window1_objects *ui_objects;
  XImageHandler *ihandler;
};
#endif

#ifdef MOTIF
class XmautoImageHandler: public baseImageHandler {
  XImageHandler *the_image;
  Widget draw_me, draw_parent;
  Boolean does_top;
  Boolean check();
  
public:
  FILE *fp;
  XmautoImageHandler(Widget parent, Widget base_parent = NULL,
		     Arg *top_args = NULL, int top_n = 0,
		     rgbImage *initial_image = NULL,
		     FILE *fp = NULL);
  ~XmautoImageHandler();
  void redraw();
  void resize();
  void display(rgbImage *image, short refresh=1);
  Widget widget() {return(draw_me);};
  int xsize() const { return the_image->xsize(); }
  int ysize() const { return the_image->ysize(); }
};

#endif /*ifdef MOTIF*/
