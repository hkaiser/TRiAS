/**
 **	$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/jtst.c,v 1.10 93/07/08 12:14:50 secoskyj Exp $
 **	Copyright (c) 1989-1992  San Diego Supercomputer Center (SDSC)
 **		San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER  "$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/jtst.c,v 1.10 93/07/08 12:14:50 secoskyj Exp $"

/**
 **  FILE
 **	jtst.c		- imconv GUI precursor
 **
 **  PROJECT
 **	IM		- Image Manipulation Tools
 **
 **  DESCRIPTION
 **	A first attempt at a graphical interface for imconv.
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **	main		f  main program
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	jtst.c,v $
 **	Revision 1.10  93/07/08  12:14:50  secoskyj
 **	Update to new directory
 **	
 **	Revision 1.9  93/07/05  19:25:44  secoskyj
 **	Alphabetizes directory list with alphasort and scandir
 **	Core dump when select a format that the file is not.  I
 **	was trying to manage a widget that did not exist.  Not a
 **	problem in libim
 **	
 **	..
 **	
 **	Revision 1.8  93/07/02  00:39:24  secoskyj
 **	Conversion working with a scrolled text box to display
 **	the status of the conversion.  Status view could
 **	be better, now just what textural imconv outputs.
 **	
 **	Revision 1.7  93/07/01  18:41:00  secoskyj
 **	Converts, but messages output to stdout instead of
 **	a dialog.
 **	
 **	Revision 1.6  93/07/01  01:33:46  secoskyj
 **	Converting, but still buggy.  Need to clean up code.
 **	
 **	Revision 1.5  93/06/30  17:23:24  secoskyj
 **	Realigned pop down output option menus
 **	
 **	Revision 1.4  93/06/30  13:58:40  secoskyj
 **	Added correct RCS logging and header information to source file.
 **	.,
 **	
 **	
 **/

#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <stdio.h>

#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#include <Xm/Xm.h>
#include <Xm/CascadeB.h>
#include <Xm/MainW.h>
#include <Xm/PushB.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/Form.h>
#include <Xm/Text.h>
#include <Xm/Label.h>
#include <Xm/List.h>
#include <Xm/ToggleB.h>
#include <Xm/FileSB.h>
#include <Xm/MessageB.h>

#include "im.h"
#include "imtools.h"

#define VIS_INPUT_FILES		(12)
#define VIS_INPUT_TYPES		(4)
#define VIS_NUM_COLS		(40)
#define VIS_ITEM_COUNT		(12)
#define SMALL_OFFSET		(5)
#define MED_OFFSET		(10)
#define INCLUDE_OFFSET		(12)
#define HORIZ_FORM_OFFSET	(15)
#define VERT_FORM_OFFSET	(15)
#define FAT_BUTTON		(10)
#define MAX_DIR_ENTRIES		(256)
#define MAX_DIR_NAME		(256)
#define MAX_NIMFORMATS		(100)
#define MAX_BUF_STR		(256)
#define MAX_FILEEXT_LEN		(10)


#define MENU_CONVERT		(10)
#define MENU_EXIT		(11)
#define MENU_LOGFILE		(20)
#define MENU_VERBOSE		(21)
#define MENU_HELP_FORMATS	(30)
#define MENU_HELP_PARAM		(31)
#define MENU_HELP_ABOUT		(32)

#define INPUT_BROWSESEL		(0)
#define INPUT_DFLTACTION	(1)
#define INPUT_EXTSEL		(2)
#define INPUT_MULTSEL		(3)
#define INPUT_SINGLESEL		(4)

#define IALPHA_YES	(1)
#define	IALPHA_NO	(2)
#define ICLT_YES	(1)
#define ICLT_NO		(2)
#define ITYPE_INDEX	(1)
#define ITYPE_RGB	(2)
#define	ITYPE_2D	(3)
#define ICHANNEL_1	(1)
#define ICHANNEL_3	(2)
#define ICHANDEPTH_1	(1)
#define ICHANDEPTH_2	(2)
#define ICHANDEPTH_4	(3)
#define ICHANDEPTH_5	(4)
#define ICHANDEPTH_8	(5)
#define ICHANDEPTH_16	(6)
#define ICOMPRESS_NO	(1)
#define ICOMPRESS_RLE	(2)
#define ICOMPRESS_LZW	(3)
#define ICOMPRESS_PB	(4)
#define ICOMPRESS_DCT	(5)
#define IINTERLEAV_NO		(1)
#define IINTERLEAV_LINE		(2)
#define IINTERLEAV_PLANE	(3)

#define MULT_FILE_SEL_STR	("<multiple files selected>")
#define BELL_VOLUME		(100)

Display		*display;
Widget		inputDirText, outputDirText;
Widget		outputFnameText;
Widget		inputDirList;
Widget		inputTypesList, outputTypesList;
Boolean		DirChange = False;
Boolean		autodetValue = True;
char		outFileExt[MAX_FILEEXT_LEN];
Widget		*compressButtons, *channelButtons, *chanDepthButtons;
Widget		*interleavButtons, *typeButtons;
Widget		*alphaButtons, *cltButtons;
Widget		CompressMenu, ChannelMenu, ChanDepthMenu;
Widget		InterleavMenu, TypeMenu;
Widget		AlphaMenu, CLTMenu;
private int	CompressVal, ChannelVal, ChanDepthVal;
private int	InterleavVal, TypeVal;
private int	AlphaVal, CLTVal;
TagTable	*imageFlagsTable;
TagTable	*imageDataTable;
Widget		outputDlg, outputDlgText, outputOKButton;
extern int	XImToolsErrorHandler();
extern int	XImToolsInfoHandler();
extern int	alphasort( struct dirent **, struct dirent ** );


static char *AlphaOpts[] = 		{ "Automatic  ",
						"Yes",
						"No" };

static char *CLTOpts[] = 		{ "Automatic  ",
						"Yes",
						"No" };

static char *CompressionTypes[] = 	{ "Automatic  ",
						"None",
						"RLE",
						"LZW",
						"PackBits",
						"DCT" };

static char *Channels[] = 		{ "Automatic  ",
						"1 channel",
						"3 channels" };

static char *ChanDepth[] = 		{ "Automatic  ",
						"1 bit",
						"2 bits",
						"4 bits",
						"5 bits",
						"8 bits",
						"16 bits" };

static char *Interleaving[] = 		{ "Automatic  ",
						"None",
						"Line",
						"Plane" };

static char *Types[] = 			{ "Automatic  ",
						"Index",
						"RGB",
						"2D Geometry" };



/*
 *  FUNCTION: outputDlgCB() - unmange outputDlg when OK button pressed
 */
outputDlgCB( w, client_data, call_data )
	Widget 	w;
	caddr_t	client_data;
	caddr_t	call_data;
{
	XtUnmanageChild( outputDlg );
}



/*
 *  FUNCTION: CreateOutputDlg - create output dialog box
 */
Widget CreateOutputDlg( parent )
	Widget parent;
{
	Arg		al[15];
	int		ac;
	int		i;
	Widget		child[5];
	Widget		dlg;
	XmString	labelXStr;

	ac = 0;
	XtSetArg( al[ac], XmNhorizontalSpacing, MED_OFFSET );
	XtSetArg( al[ac], XmNverticalSpacing, MED_OFFSET );
	dlg = XmCreateFormDialog( parent, "Conversion Status",
		al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNresizeHeight, True ); ac++;
	XtSetArg( al[ac], XmNresizeWidth, True ); ac++;
	XtSetArg( al[ac], XmNeditMode, XmMULTI_LINE_EDIT ); ac++;
	XtSetArg( al[ac], XmNeditable, False ); ac++;
	XtSetArg( al[ac], XmNrows, 24 ); ac++;
	XtSetArg( al[ac], XmNcolumns, 80 ); ac++;
	XtSetArg( al[ac], XmNscrollHorizontal, True ); ac++;
	XtSetArg( al[ac], XmNscrollVertical, True ); ac++;
	outputDlgText = XmCreateScrolledText( dlg, "outputDlgText", al, ac );
	XtManageChild( outputDlgText );

	
	labelXStr = XmStringCreateLtoR( "OK", XmSTRING_DEFAULT_CHARSET );

	ac = 0;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopWidget, outputDlgText ); ac++;
	outputOKButton = XmCreatePushButton( dlg, "outputOKButton", al, ac );
	XtManageChild( outputOKButton );
	XtAddCallback( outputOKButton, XmNactivateCallback, outputDlgCB,	
		NULL );

	return( dlg );
}


/*
 *  FUNCTION:  outputDlgOK( yesno ) - turn ok button on or off
 */
outputDlgOKButton( yesno )
	Boolean yesno;
{
	Arg		al[5];
	int		ac;
	int		i;
	Widget		child[5];

	XtSetSensitive( outputOKButton, yesno );
}



/*
 *  FUNCTION: outputDlgConcat( str ) - concat a string to the current
 *		outputDlg message
 */
outputDlgConcat( str )
	char *str;
{
	int	end;

	end = XmTextGetLastPosition( outputDlgText );
	XmTextInsert( outputDlgText, end, str );
	end = XmTextGetLastPosition( outputDlgText );
	XmTextShowPosition( outputDlgText, end );
}



/*
 *  FUNCTION: outputDlgClr( ) - clear string in output dialog
 *		outputDlg message
 */
outputDlgClr( )
{
	XmTextSetString( outputDlgText, "" );
}



/*
 *  FUNCTION: buildFlagsTable - put output options into a flag table
 */
TagTable *buildFlagsTable()
{
	TagTable	*flagsTable;
	int		i;
	int		itmp;
	char		*tmp;
	int		(*handler)();

	if ( ( flagsTable = TagTableAlloc() ) == TAGTABLENULL )
	{
		TagPError( ImToolsProgram );
		exit( 1 );
	}

	TagTableAppend( flagsTable, 
		TagEntryAlloc( "program name", POINTER, &ImToolsProgram ) );

	handler = XImToolsErrorHandler;
	TagTableAppend( flagsTable,
		TagEntryAlloc( "error handler", POINTER, &handler ) );

	handler = XImToolsInfoHandler;
	TagTableAppend( flagsTable,
		TagEntryAlloc( "info handler", POINTER, &handler ) );


	switch ( TypeVal )
	{
	case ITYPE_INDEX:
		itmp = IMTYPEINDEX;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image type request", INT, &itmp ) );
		break;

	case ITYPE_RGB:
		itmp = IMTYPERGB;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image type request", INT, &itmp ) );
		break;
	}


	switch ( CLTVal )
	{
	case ICLT_YES:
		itmp = IMCLTYES;
		TagTableAppend( flagsTable, 
			TagEntryAlloc( "image clt request", INT, &itmp ) );
		break;

	case ICLT_NO:
		itmp = IMCLTNO;
		TagTableAppend( flagsTable, 
			TagEntryAlloc( "image clt request", INT, &itmp ) );
		break;
	}


	switch ( AlphaVal )
	{
	case ICLT_YES:
		itmp = IMALPHAYES;
		TagTableAppend( flagsTable, 
			TagEntryAlloc( "image alpha request", INT, &itmp ) );
		break;

	case ICLT_NO:
		itmp = IMCLTNO;
		TagTableAppend( flagsTable, 
			TagEntryAlloc( "image alpha request", INT, &itmp ) );
		break;
	}



	switch ( ChanDepthVal )
	{
	case ICHANDEPTH_1:
		itmp = 1;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_2:
		itmp = 2;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_4:
		itmp = 4;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_5:
		itmp = 5;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_8:
		itmp = 8;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_16:
		itmp = 16;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;
	}



	switch ( ChannelVal )
	{
	case ICHANNEL_1:
		itmp = 1;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel number request", 
				INT, &itmp ) );
		break;

	case ICHANNEL_3:
		itmp = 3;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel number request", 
				INT, &itmp ) );
		break;
	}



	switch ( InterleavVal )
	{
	case IINTERLEAV_NO:
		itmp = IMINTERNONE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image interleave request",
				INT, &itmp ) );
		break;

	case IINTERLEAV_LINE:
		itmp = IMINTERLINE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image interleave request",
				INT, &itmp ) );
		break;

	case IINTERLEAV_PLANE:
		itmp = IMINTERPLANE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image interleave request",
				INT, &itmp ) );
		break;
	}


	switch ( CompressVal )
	{
	case ICOMPRESS_NO:
		itmp = IMCOMPNONE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;

	case ICOMPRESS_RLE:
		itmp = IMCOMPRLE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;

	case ICOMPRESS_LZW:
		itmp = IMCOMPLZW;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;

	case ICOMPRESS_PB:
		itmp = IMCOMPPB;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;

	case ICOMPRESS_DCT:
		itmp = IMCOMPDCT;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;
	}



	return ( flagsTable );
}


/*
 *  FUNCTION: buildDataTable - allocate data table for read and write routines
 */
TagTable *buildDataTable()
{
	TagTable *dataTable;

	if ( ( dataTable = TagTableAlloc() ) == TAGTABLENULL )
	{
		TagPError( "jtst" );
		exit( 1 );
	}

	return ( dataTable );
}
	
	

/*
 *  FUNCTION: listFillDir - fill a list with the current directory
 */

listFillDir( listW )
	Widget listW;
{
	DIR 		*dirp;
	struct dirent 	**dirents;
	XmString	filename[MAX_DIR_ENTRIES];
	char		dirName[MAX_DIR_NAME];
	Arg		al[10];
	int		ac;
	int		i, numEntries;
	struct stat	fileStats;


	numEntries = scandir( ".", &dirents, NULL, alphasort );
	if ( numEntries < 0 )
	{
		fprintf( stderr, "Difficulty with scandir command.\n" );
		exit( 0 );
	}

	/*
	 *  Place each directory entry name into an XmString array
	 */

	for ( i = 0; i < numEntries; i++ )
	{
		strcpy( dirName, dirents[i]->d_name );

		stat( dirName, &fileStats );

		/*
		 *  If the item is a directory add a / to the end of the name,
		 *  if the item is executable, add a * to the end of the name.
		 */

		if ( S_IFDIR & fileStats.st_mode )
		{
			strcat( dirName, "/" );
		}
		else
		{
			if ( ( S_IXUSR | S_IXGRP | S_IXOTH ) &
				fileStats.st_mode )
			{
				strcat( dirName, "*" );
			}
		}

		filename[i] = XmStringCreateLtoR( dirName,
				XmSTRING_DEFAULT_CHARSET );
	}

	ac = 0;
	XtSetArg( al[ac], XmNitems, filename ); ac++;
	XtSetArg( al[ac], XmNitemCount, i ); ac++;
	XtSetValues( listW, al, ac );

	/*
	 *  Select first item, but do not call selection callback in
	 *  the process
	 */

	XmListSelectPos( listW, 1, False );

	for ( i = i - 1 ; i >= 0; i-- )
	{
		XmStringFree( filename[i] );
		free( dirents[i] );
	}

	free( dirents );
}


/*
 *  FUNCTION: textFillCurDir - fill a text field with the current directory
 */

textFillCurDir( textW )
	Widget textW;
{
	char 		pathname[MAXPATHLEN];
	int		posn;

	/*
	 *  Get the current working directory and insert this text into
	 *  the passed text widget
	 */

	getwd( pathname );

	XmTextSetString( textW, pathname );

	/*
	 *  Make sure the the end of the string in the text widget is
	 *  visible
	 */

	posn = XmTextGetLastPosition( textW );
	XmTextShowPosition( textW, posn );
	XmTextSetInsertionPosition( textW, posn );
}



/*
 *  FUNCTION: MenuCB - menu callback handler
 */

MenuCB( w, client_data, call_data )
	Widget 	w;
	caddr_t	client_data;
	caddr_t	call_data;
{
	switch ( (int) client_data )
	{
		case MENU_EXIT:
			printf( "jtst: exiting...\n" );

			free( compressButtons );
			free( channelButtons );
			free( chanDepthButtons );
			free( interleavButtons );
			free( typeButtons );

			exit( 0 );
			break;

		case MENU_CONVERT:
			printf( "jtst: Convert requested.\n" );
			break;

		case MENU_LOGFILE:
			printf( "jtst: Log File... requested.\n" );
			break;

		case MENU_VERBOSE:
			printf( "jtst: Verbose requested.\n" );
			break;

		case MENU_HELP_FORMATS:
			printf( "jtst: help on formats requested.\n" );
			break;

		case MENU_HELP_PARAM:
			printf( "jtst: help on output params requested.\n" );
			break;

		case MENU_HELP_ABOUT:
			printf( "This is a precursor to the imconv GUI\n" );
			break;

		default:
			printf( "jtst: unknown menu callback.\n" );
			break;
	}
}



/*
 *  FUNCTION: inFileDblCB() - how to handle an input file selection
 */
inFileDblCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	XmListCallbackStruct	*cb;
	XmString		fileName;
	char			*charFname;
	char			*homeDir;
	int			i, len, updateDir;
	DIR			*dirp;
	struct dirent		*dirent;
	struct stat		fileStats;

	updateDir = 0;
	cb = (XmListCallbackStruct *) call_data;
	
	/*
	 *  Get the filename char * that was selected
	 */

	fileName = (XmString)cb->item;
	XmStringGetLtoR( fileName, XmSTRING_DEFAULT_CHARSET, &charFname );
	len = strlen( charFname );

	/*
	 *  Remove / or * characters from end of filename 
	 */

	if ( charFname[len - 1] == '/' || charFname[len - 1] == '*' )
		charFname[len - 1] = '\0';

	dirp = opendir( "." );

	/*
	 *  Current directory no longer exists, handle error elegantly
	 *  In this case, return to the users home directory.  This should
	 *  be ok since the $HOME environment variable is set by login,
	 *  not by the user's shell.
	 *
	 *  Just in case we will check to make sure that $HOME was actuall
	 *  received (gotten) from the environment, else we will cd to root.
	 */

	if ( dirp == NULL )
	{
		homeDir = getenv( "HOME" );

		if ( homeDir == NULL )
			chdir( "/" );
		else
			chdir( homeDir );

		listFillDir( w );
		textFillCurDir( inputDirText );
		textFillCurDir( outputDirText );
		closedir( dirp );
		return;
	}

	/*
	 *  Make sure thet the item selected is still in the directory
	 */

	dirent = readdir( dirp );
	while ( dirent != NULL && strcmp( charFname, dirent->d_name ) )
	{
		dirent = readdir( dirp );
	}

	/*
	 *  If the item is not in the directory, update the directory.
	 */

	if ( dirent == NULL )
	{
		listFillDir( w );
		textFillCurDir( inputDirText );
		textFillCurDir( outputDirText );
		closedir( dirp );
		return;
	};


	/*
	 *  Otherwise, if the selected item is a directory, change directories
	 *  to the selected directory
	 */

	stat( dirent->d_name, &fileStats );
	if ( S_IFDIR & fileStats.st_mode )
	{
		chdir( dirent->d_name );

		listFillDir( w );
		textFillCurDir( inputDirText );
		textFillCurDir( outputDirText );
	}

	closedir( dirp );
	XtFree( charFname );
}



/*
 *  FUNCTION: constrOutFname() - add currently selected image type extention
 *		to filename that is passed in.
 */
char *constrOutFname( filename )
	char *filename;
{
	char	*dotPos;
	char	*outName;
	char	*tmpFname;

	tmpFname = strdup( filename );

	if ( tmpFname[0] != '.' || tmpFname[1] == '\0' )
	{
		dotPos = strrchr( tmpFname, '.' );

		if ( dotPos != 0 )
			dotPos[0] = '\0';
	}

	outName = (char *) malloc( strlen( tmpFname ) + 1 + 
			strlen( outFileExt ) + 1 );
	
	if ( outName == NULL )
	{
		fprintf( stderr, "Not able to allocate memory for string.\n");
		exit( 0 );
	}

	strcpy( outName, tmpFname );
	strcat( outName, "." );
	strcat( outName, outFileExt );

	free( tmpFname );
	return( outName );
}



/*
 *  FUNCTION: getFileExt( filename ) - returns string after last period
 *		in filename (returns a pointer inside of passed string).
 */
char *getFileExt( filename )
	char *filename;
{
	int 	len;
	char	*dotPos;
	char	*fileExt;

	fileExt = NULL;
	len = strlen( filename );

	if ( filename[len - 1] == '/' || filename[len - 1] == '*' )
		filename[len - 1] = '\0';

	if ( filename[0] != '.' || filename[1] == '\0' )
	{
		dotPos = strrchr( filename, '.' );

		if ( dotPos != 0 )
			fileExt = dotPos + 1;
	}

	return( fileExt );
}

	


/*
 *  FUNCTION: inFileExtCB() - called when a selection of items occurs
 */
inFileExtCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	XmListCallbackStruct	*cb;
	Arg			al[10];
	int			ac;
	int 			nItems, len;
	char			*selItem;
	char			*outName, *outExt;
	ImFileFormat 		**ppFmt;	
	ImFileFormat		*pFmt;
	char			**pNames;
	char			selStr[MAX_BUF_STR];
	XmString		selXStr;

	cb = (XmListCallbackStruct *) call_data;
	nItems = cb->selected_item_count;

	if ( nItems == 1 )
	{
		XmStringGetLtoR( cb->selected_items[0],
			XmSTRING_DEFAULT_CHARSET, &selItem );
		
		len = strlen( selItem );

		switch( selItem[len - 1] )
		{
		case '/':
			XtFree( selItem );
			XmTextSetString( outputFnameText, " " );
			XtSetSensitive( outputFnameText, False );
			return;
			break;

		case '*':
			selItem[len - 1] = '\0';
			outName = constrOutFname( selItem );
			break;

		default:
			outName = constrOutFname( selItem );
			break;
		}			

		ac = 0;
		XtSetArg( al[ac], XmNvalue, outName ); ac++;
		XtSetValues( outputFnameText, al, ac );
		XtSetSensitive( outputFnameText, True );
		
		len = XmTextGetLastPosition( outputFnameText );
		XmTextShowPosition( outputFnameText, len );
		XmTextSetInsertionPosition( outputFnameText, len );

		outExt = getFileExt( selItem );

		if ( outExt == NULL )
		{
			XtFree( selItem );
			free( outName );
			return;
		}

		len = strlen( outExt );

		if ( len <= 0 )
		{
			XtFree( selItem );
			free( outName );
			return;
		}


		/*
		 *  See if extention is a valid format name and select the
		 *  image type in the input image type list.
		 */

		for ( ppFmt = ImFileFormats; *ppFmt; ppFmt++ )
		{
			pNames = &(*ppFmt)->format_names[0];
			for ( ; *pNames; pNames++ )
			{
				if ( strcmp( *pNames, outExt ) == 0 )
				{
					/*
					 *  Select the input format list item
					 */

					pFmt = *ppFmt;
					sprintf( selStr, "%-7s %s",
						pFmt->format_names[0],
						pFmt->format_help );

					selXStr = XmStringCreateLtoR( selStr,
						XmSTRING_DEFAULT_CHARSET );

					XmListSelectItem( inputTypesList,
						selXStr, True );
					XmListSetItem( inputTypesList,
						selXStr );
					XmStringFree( selXStr );
					break;
				}
			}
			if ( *pNames )
				break;
		}

		XtFree( selItem );
		free( outName );
	}
	else
	{
		ac = 0;
		XtSetArg( al[ac], XmNvalue, MULT_FILE_SEL_STR ); ac++;
		XtSetValues( outputFnameText, al, ac );
		XtSetSensitive( outputFnameText, False );
	}
}




/*
 *  FUNCTION: dirChangeCB() - notes if a change of directory occured.
 */

dirChangeCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	DirChange = True;
}



/*
 *  FUNCTION: dirUpdateCB() - update listbox with current directory if changed.
 *
 *  DESCRIPTION:	If we lose focus or enter is pressed in the text
 * 			field, see if we need to update the directory
 */

dirUpdateCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	XmAnyCallbackStruct	*cb;

	cb = (XmAnyCallbackStruct *) call_data;

	if ( DirChange == False )
		return;

	DirChange = False;

	if ( !chdir( XmTextGetString( w ) ) )
	{
		listFillDir( inputDirList );
		textFillCurDir( outputDirText );
	}
	textFillCurDir( w );
}
		


/*
 *  FUNCTION: freeDataTable( dataTable ) - free a tag table of image data.
 *	Free vfb and tag table only.  All other data is left to fill memory
 *	(unfortunately).
 */
freeDataTable( dataTable )
	TagTable **dataTable;
{
	int 		i;
	TagEntry 	*dataEntry;	/* used to obtain correct entries   */
	ImVfb 		*vfb;		/* variables used to clear out data */
	ImClt 		*clt;
	char		*name;
	ImHotSpotPtr	*hotspot;
	
	i = TagTableQNEntry( *dataTable, "image vfb" ) - 1;

	for( ; i >= 0; i-- )
	{
		dataEntry = TagTableQDirect( *dataTable, "image vfb", i );
		TagEntryQValue( dataEntry, &vfb );
		ImVfbFree( vfb );
	}
	
	i = TagTableQNEntry( *dataTable, "image clt" ) - 1;

	for( ; i >= 0; i-- )
	{
		dataEntry = TagTableQDirect( *dataTable, "image clt", i );
		TagEntryQValue( dataEntry, &clt );
		ImCltFree( clt );
	}

	i = TagTableQNEntry( *dataTable, "image name" ) - 1;

	for( ; i >= 0; i-- )
	{
		dataEntry = TagTableQDirect( *dataTable, "image name", i );
		TagEntryQValue( dataEntry, &name );
		free( name );
	}

	i = TagTableQNEntry( *dataTable, "image hot spot" ) - 1;

	for( ; i >= 0; i-- )
	{
		dataEntry = TagTableQDirect( *dataTable, "image hot spot", i );
		TagEntryQValue( dataEntry, &hotspot );
		free( hotspot );
	}


	TagTableFree( *dataTable );
}



/*
 *  FUNCTION: inTypeExt() - return extention of input type selected
 */
char *inTypeExt()
{
	char		*inFormat, *inExt, *firstSpace;
	Arg		al[10];
	int		ac;
	XmStringTable	*selXItem;

	ac = 0;
	XtSetArg( al[ac], XmNselectedItems, &selXItem ); ac++;
	XtGetValues( inputTypesList, al, ac );

	XmStringGetLtoR( (XmString) selXItem[0],
		XmSTRING_DEFAULT_CHARSET, &inFormat );

	firstSpace = NULL;
	firstSpace = strchr( inFormat, ' ' );
	if ( firstSpace == NULL )
	{
		fprintf( stderr, "Bad input image type string.\n" );
		exit( 0 );
	}

	firstSpace[0] = '\0';

	inExt = (char *) malloc( strlen( inFormat ) + 1 );

	strcpy( inExt, inFormat );

	return inExt;
}


/*
 *  FUNCTION: convCB() - callback when convert button pressed 
 */
convCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	Arg		al[10];
	int		ac;
	int		nItems, i, len;
	char		*curItem;
	XmStringTable	*selXItems;
	char		*inFormat, *outFilename, *outPath, *outFullName;
	int		res;

	ac = 0;
	XtSetArg( al[ac], XmNselectedItemCount, &nItems ); ac++;
	XtSetArg( al[ac], XmNselectedItems, &selXItems ); ac++;

	XtGetValues( inputDirList, al, ac ); 

	outPath = XmTextGetString( outputDirText );

	outputDlgClr( );
	outputDlgOKButton( False );
	XtManageChild( outputDlg );
	outputDlgConcat( "Conversion Status:\n" );

	imageFlagsTable = buildFlagsTable();
	for ( i = 0; i < nItems; i++ )
	{
		imageDataTable = buildDataTable();

		XmStringGetLtoR( (XmString) selXItems[i],
			XmSTRING_DEFAULT_CHARSET, &curItem );

		XmListSetItem( inputDirList, (XmString) selXItems[i] );

		len = strlen( curItem );

		if ( curItem[len - 1] == '/' )
		{
			outputDlgConcat( "Skipping directory\n" );
			continue;
		}

		if ( curItem[len - 1] == '*' )
			curItem[len - 1] = '\0';

		if ( autodetValue == True )
			inFormat = strdup( "\0" );
		else
			inFormat = inTypeExt( );

		ImToolsVerbose = 1;
		res = XImToolsFileRead( curItem, inFormat, imageFlagsTable,
			imageDataTable );

		if ( res == 0 )
		{
			if ( nItems > 1 )
				outFilename = constrOutFname( strdup(curItem) );
			else
				outFilename = XmTextGetString( outputFnameText);

			outFullName = (char *) malloc( strlen( outPath ) + 1 +
						strlen( outFilename) + 1 );
			
			strcpy( outFullName, outPath );
			strcat( outFullName, "/" );
			strcat( outFullName, outFilename );

			res = XImToolsFileWrite( outFullName, outFileExt,
				imageFlagsTable, imageDataTable );

			free( outFullName );
		}
		free( curItem );
		freeDataTable( &imageDataTable );
	}

	XmListDeselectAllItems( inputDirList );
	listFillDir( inputDirList );
	XmTextSetString( outputFnameText, "" );

	CompressVal = ChannelVal = ChanDepthVal = 0;
	InterleavVal = TypeVal = 0;
	AlphaVal = CLTVal = 0;

	outputDlgConcat( "Conversion Done.\n" );
	outputDlgOKButton( True );
	XBell( display, BELL_VOLUME );

	return;
}
		


/*
 *  FUNCTION: prevueCB() - callback when preview button pressed 
 */
prevueCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	fprintf( stderr, "jtst: Preview button pressed.\n" );
	return;
}



/*
 *  FUNCTION: alaphCB() - callback called when menu item changed
 *		in alpha option menu
 */
alphaCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	AlphaVal = (int) client_data;

	return;
}



/*
 *  FUNCTION: cltCB() - callback called when menu item changed
 *		in color table option menu
 */
cltCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	CLTVal = (int) client_data;

	return;
}



/*
 *  FUNCTION: compressCB() - callback called when menu item changed
 *		in compress option menu
 */
compressCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	CompressVal = (int) client_data;

	return;
}



/*
 *  FUNCTION: channelCB() - callback called when menu item changed
 *		in channels option menu
 */
channelCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	ChannelVal = (int) client_data;

	return;
}



/*
 *  FUNCTION: chanDepthCB() - callback called when menu item changed
 *		in channel depth option menu
 */
chanDepthCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	ChanDepthVal = (int) client_data;

	return;
}



/*
 *  FUNCTION: interleavCB() - callback called when menu item changed
 *		in interleaving option menu
 */
interleavCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	InterleavVal = (int) client_data;

	return;
}



/*
 *  FUNCTION: typeCB() - callback called when menu item changed
 *		in type option menu
 */
typeCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	TypeVal = (int) client_data;

	return;
}



/*
 *  FUNCTION: autodetCB() - callback when autodetect image type toggle 
 *		button is toggled
 */
autodetCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	autodetValue = XmToggleButtonGetState( w );

	if ( autodetValue == True )
		XtSetSensitive( inputTypesList, False );
	else
		XtSetSensitive( inputTypesList, True );
}



/*
 *  FUNCTION: greyAllOutOpts() - grey all popdown menu options
 */
greyAllOutOpts()
{
	int i, len;

	len = sizeof( AlphaOpts ) / sizeof( *AlphaOpts );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( alphaButtons[i], False );

	len = sizeof( CLTOpts ) / sizeof( *CLTOpts );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( cltButtons[i], False );

	len = sizeof( CompressionTypes ) / sizeof( *CompressionTypes );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( compressButtons[i], False );

	len = sizeof( Channels ) / sizeof( *Channels );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( channelButtons[i], False );

	len = sizeof( ChanDepth ) / sizeof( *ChanDepth );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( chanDepthButtons[i], False );

	len = sizeof( Interleaving ) / sizeof( *Interleaving );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( interleavButtons[i], False );

	len = sizeof( Types ) / sizeof( *Types );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( typeButtons[i], False );
}



/*
 *  FUNCTION: sensitizeButtons( ppFmt ) - do the actual sensitization of the
 *		output option buttons so that the available items are not
 *		greyed out.
 */
sensitizeButtons( pFmt )
	ImFileFormat *pFmt;
{
	int			i;
	ImFileFormatWriteMap	*pWrite;

	pWrite = pFmt->format_writeMap;

	/*
	 *  If no write support, leave all the buttons desensitized
	 *  Otherwise sensitize only those buttons which can be used for
	 *  the selected format.
	 */

	if ( pWrite == NULL )
		return;

	for ( ; pWrite->map_outType != -1; pWrite++ )
	{
		if ( pWrite->map_outAttributes & IMALPHAYES )
			XtSetSensitive( alphaButtons[IALPHA_YES], True );
		else
			XtSetSensitive( alphaButtons[IALPHA_NO], True );

		if ( pWrite->map_outAttributes & IMCLTYES )
			XtSetSensitive( cltButtons[ICLT_YES], True );
		else
			XtSetSensitive( cltButtons[ICLT_NO], True );

		switch ( pWrite->map_outType )
		{
		case IMTYPEINDEX:
			XtSetSensitive( typeButtons[ITYPE_INDEX], True );
			break;

		case IMTYPERGB:
			XtSetSensitive( typeButtons[ITYPE_RGB], True );
			break;

		case IMTYPE2D:
			XtSetSensitive( typeButtons[ITYPE_2D], True );
			break;

		default:
			fprintf( stderr, "Unknown type in ImFileFormats\n" );
			fprintf( stderr, "jtst needs to be modified\n" );
			break;
		}

		switch ( pWrite->map_outNChannels )
		{
		case 1:
			XtSetSensitive( channelButtons[ICHANNEL_1], True );
			break;

		case 3:
			XtSetSensitive( channelButtons[ICHANNEL_3], True );
			break;

		default:
			fprintf( stderr, "Unknown channel in ImFileFormats\n" );
			fprintf( stderr, "jtst needs to be modified\n" );
			break;
		}

		switch( pWrite->map_outChannelDepth )
		{
		case 1:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_1], True );
			break;

		case 2:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_2], True );
			break;

		case 4:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_4], True );
			break;

		case 5:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_5], True );
			break;

		case 8:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_8], True );
			break;

		case 16:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_16], True );
			break;

		default:
			fprintf( stderr, "Unknown depth in ImFileFormats\n" );
			fprintf( stderr, "jtst needs to be modified\n" );
			break;
		}

		switch( pWrite->map_outAttributes & IMCOMPMASK )
		{
		case IMCOMPNO:
			XtSetSensitive( compressButtons[ICOMPRESS_NO], True );
			break;

		case IMCOMPRLE:
			XtSetSensitive( compressButtons[ICOMPRESS_RLE], True );
			break;

		case IMCOMPLZW:
			XtSetSensitive( compressButtons[ICOMPRESS_LZW], True );
			break;

		case IMCOMPPB:
			XtSetSensitive( compressButtons[ICOMPRESS_PB], True );
			break;

		case IMCOMPDCT:
			XtSetSensitive( compressButtons[ICOMPRESS_DCT], True );
			break;

		default:
			fprintf( stderr, "Unknown compression in ImFileFormats\n" );
			fprintf( stderr, "jtst needs to be modified\n" );
			break;
		}

		switch( pWrite->map_outAttributes & IMINTERMASK )
		{
		case IMINTERNO:
			XtSetSensitive( interleavButtons[IINTERLEAV_NO], True );
			break;

		case IMINTERLINE:
			XtSetSensitive( interleavButtons[IINTERLEAV_LINE],
				True );
			break;

		case IMINTERPLANE:
			XtSetSensitive( interleavButtons[IINTERLEAV_PLANE],
				True );
			break;

		default:
			fprintf( stderr, "Unknown interleaving in ImFileFormats\n" );
			fprintf( stderr, "jtst needs to be modified\n" );
			break;
		}
	}
}
	


/*
 *  FUNCTION: resetPopDowns() - put output parameter pop down menus at first 
 *		menu option.
 */
resetPopDowns()
{
	Arg	al[5];
	int	ac;

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, alphaButtons[0] ); ac++;
	XtSetValues( AlphaMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, cltButtons[0] ); ac++;
	XtSetValues( CLTMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, compressButtons[0] ); ac++;
	XtSetValues( CompressMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, channelButtons[0] ); ac++;
	XtSetValues( ChannelMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, chanDepthButtons[0] ); ac++;
	XtSetValues( ChanDepthMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, interleavButtons[0] ); ac++;
	XtSetValues( InterleavMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, typeButtons[0] ); ac++;
	XtSetValues( TypeMenu, al, ac );
}



/*
 *  FUNCTION: selectButtons() - selects output option menu buttons
 *		based on which output format is selected.
 */
selectButtons()
{
	ImFileFormat 	**ppFmt;	
	char		**pNames;

	for ( ppFmt = ImFileFormats; *ppFmt; ppFmt++ )
	{
		/*
		 *  Compare format names in ImFileFormats data structure
		 *  to the selected format name in order to access the
		 *  information associated with the image format.
		 */

		pNames = &(*ppFmt)->format_names[0];
		for ( ; *pNames; pNames++ )
		{
			if ( strcmp( *pNames, outFileExt ) == 0 )
			{
				resetPopDowns();
				sensitizeButtons( *ppFmt );
				break;
			}
		}
		if ( *pNames )
			break;
	}
}
	


/*
 *  FUNCTION: outTypeSelCB() - records which output type was selected
 */
outTypeSelCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	XmListCallbackStruct	*cb;
	char			*outType, *firstSpace;
	char			*inFilename;
	char			*outFilename;

	/*
	 *  Get extention of image type selected from the string in the
	 *  list box.  Place the extention onto the output filename after
	 *  removing the current extention on the output filename.
	 */

	cb = (XmListCallbackStruct *) call_data;

	XmStringGetLtoR( cb->item, XmSTRING_DEFAULT_CHARSET,
		&outType );
	
	firstSpace = NULL;
	firstSpace = strchr( outType, ' ' );
	if ( firstSpace == NULL )
	{	
		fprintf( stderr, "Bad output image type string.\n" );
		exit( 0 );
	}

	firstSpace[0] = '\0';
	strcpy( outFileExt, outType );
	XtFree( outType );

	inFilename = XmTextGetString( outputFnameText );

	/*
	 *  Selectively sensitize options which apply to this format.
	 *  Leave other menu options greyed or insensitive.
	 *  Button sensitization is based on the format stored in the
	 *  global variable outFileExt.
	 */

	greyAllOutOpts();
	selectButtons();

	/*
	 *  Change output filename to reflect the change in output type.
	 */

	if ( inFilename[0] == '\0' )
		return;

	if ( strcmp( inFilename, MULT_FILE_SEL_STR ) != 0 )
	{
		outFilename = constrOutFname( inFilename );
		XmTextSetString( outputFnameText, outFilename );
		free( outFilename );
	}

	XtFree( inFilename );
}



/*
 *  FUNCTION: listFillImForm - put imtool formats into a list box.
 */

listFillImForm( listW, ppFmt, inputFormats )
	Widget 		listW;
	ImFileFormat 	**ppFmt;
	Boolean		inputFormats;
{
	ImFileFormat	*pFmt;
	char 		imTypeDescr[MAX_BUF_STR];
	Arg		al[10];
	int		ac, i;
	XmString	typeDescrip[MAX_NIMFORMATS];

	/*
	 *  Get and convert image format strings into XmStrings and place
	 *  them into an XmString array.
	 */

	i = 0;
	for ( ppFmt = ImFileFormats; *ppFmt; ppFmt++ )
	{
		pFmt = *ppFmt;


		/*
		 *  Check to make sure that the format supports reading
		 *  or writing in order to determine if it should be 
		 *  included in the list box of formats.
		 */
		if ( inputFormats == True )
		{
			if ( pFmt->format_readMap == NULL )
				continue;
		}
		else
		{
			if ( pFmt->format_writeMap == NULL )
				continue;
		}

		sprintf( imTypeDescr, "%-7s %s", pFmt->format_names[0],
				pFmt->format_help );

		typeDescrip[i] = XmStringCreateLtoR( imTypeDescr,
				XmSTRING_DEFAULT_CHARSET );

		i++;
	}

	ac = 0;
	XtSetArg( al[ac], XmNitems, typeDescrip ); ac++;
	XtSetArg( al[ac], XmNitemCount, i ); ac++;
	XtSetValues( listW, al, ac );

	XmListSelectPos( listW, 1, True );

	for ( i = i - 1; i >= 0; i-- )
	{
		XmStringFree( typeDescrip[i] );
	}
}


/*
 *  FUNCTION: CreateMenuBar - construct the menu bar and menu structure
 */

static Widget CreateMenuBar( parent )
	Widget parent;
{
	Widget		menuBar;
	Widget		cascade;
	Widget		menuPane;
	Widget		button;
	Widget		separator;

	Arg		al[10];
	int		ac;

	/*
	 *  Create MenuBar
	 */

	ac = 0;
	menuBar = XmCreateMenuBar( parent, "menuBar", al, ac );

	/*
	 *  Create "File" PulldownMenu
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( menuBar, "menu_file", al, ac );

	ac = 0;
	button = XmCreatePushButton( menuPane, "Convert", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_CONVERT );
	XtManageChild( button );

	ac = 0;
	button = XmCreatePushButton( menuPane, "Exit", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_EXIT );
	XtManageChild( button );

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	cascade = XmCreateCascadeButton( menuBar, "File", al, ac );
	XtManageChild( cascade );

	/*
	 *  Create "Options" PulldownMenu
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( menuBar, "menu_opt", al, ac );

	ac = 0;
	button = XmCreatePushButton( menuPane, "Log File...", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_LOGFILE );
	XtManageChild( button );

	ac = 0;
	separator = XmCreateSeparator( menuPane, "Opt_Separator", al, ac );
	XtManageChild( separator );

	ac = 0;
	button = XmCreatePushButton( menuPane, "Verbose", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_VERBOSE );
	XtManageChild( button );

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	cascade = XmCreateCascadeButton( menuBar, "Options", al, ac );
	XtManageChild( cascade );

	/*
	 *  Create "Help" button
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( menuBar, "menu_help", al, ac );

	ac = 0;
	button = XmCreatePushButton( menuPane, "Image Formats", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_HELP_FORMATS );
	XtManageChild( button );

	ac = 0;
	button = XmCreatePushButton( menuPane, "Conversion Parameters",
			al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_HELP_PARAM );
	XtManageChild( button );

	ac = 0;
	separator = XmCreateSeparator( menuPane, "Opt_Separator", al, ac );
	XtManageChild( separator );

	ac = 0;
	button = XmCreatePushButton( menuPane, "About jtst", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_HELP_ABOUT );
	XtManageChild( button );

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	cascade = XmCreateCascadeButton( menuBar, "Help", al, ac );
	XtManageChild( cascade );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHelpWidget, cascade ); ac++;
	XtSetValues( menuBar, al, ac );

	return( menuBar );
}



/*
 *  FUNCTION: CreateInputSec
 */

static Widget CreateInputSec( parent )
	Widget parent;
{
	Widget		inputSec;
	Widget		dirText;
	Widget		dirLabel;
	Widget		convLabel;
	Widget		inputFiles;
	Widget		autodetToggle;
	Widget		intypeList;
	Arg		al[15];
	int		ac;
	XmString	labelStr;
	char		newTrans[64];
	XtTranslations	transTable;

	/*
	 *  Create container for InputSection
	 */
	ac = 0;
	XtSetArg( al[ac], XmNhorizontalSpacing, HORIZ_FORM_OFFSET ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	inputSec = XmCreateForm( parent, "inputSec", al, ac );


	/*
	 *  Create label for directory text field
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Input File(s):",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	dirLabel = XmCreateLabel( inputSec, "dirLabel", al, ac );
	XtManageChild( dirLabel );
	XmStringFree( labelStr );


	/*
	 *  Create directory entry line
	 *  Create new translation of Return key while entry line is 
	 *  active.  Make the Return key call the activate callback.
	 */
	strcpy( newTrans, "<Key>Return : activate()" );
	transTable = XtParseTranslationTable( newTrans );

	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, dirLabel ); ac++;
	XtSetArg( al[ac], XmNrows, 1 ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNeditMode, XmSINGLE_LINE_EDIT ); ac++;
	dirText = XmCreateText( inputSec, "dirText", al, ac );
	XtOverrideTranslations( dirText, transTable );
	XtManageChild( dirText );


	/*
	 *  Set up global variable, so that we can access the text field
	 *  from the routine that does the directory browsing
	 */
	inputDirText = dirText;



	/*
	 *  Create Input File Selection List
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, dirText ); ac++;
	XtSetArg( al[ac], XmNtopOffset, SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNvisibleItemCount, VIS_INPUT_FILES ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNscrollBarDisplayPolicy, XmSTATIC ); ac++;
	XtSetArg( al[ac], XmNselectionPolicy, XmEXTENDED_SELECT ); ac++;

	inputFiles = XmCreateScrolledList( inputSec, "inputFiles", al, ac);
	
	inputDirList = inputFiles;

	XtAddCallback( inputFiles, XmNdefaultActionCallback, inFileDblCB,
			NULL );
	XtAddCallback( inputFiles, XmNextendedSelectionCallback,
			inFileExtCB, NULL );

	XtManageChild( inputFiles );

	textFillCurDir( inputDirText );
	listFillDir( inputFiles );

	XtAddCallback( dirText, XmNmodifyVerifyCallback, dirChangeCB, NULL );
	XtAddCallback( dirText, XmNlosingFocusCallback, dirUpdateCB, NULL );
	XtAddCallback( dirText, XmNactivateCallback, dirUpdateCB, NULL );

	/*
	 *  Create Input Conversion label
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Input Conversion:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, inputFiles ); ac++;
	XtSetArg( al[ac], XmNtopOffset, MED_OFFSET + SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	convLabel = XmCreateLabel( inputSec, "convLabel", al, ac );
	XtManageChild( convLabel );
	XmStringFree( labelStr );


	/*
	 *  Create Automatic type detection toggle button
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Automatic type detection",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, convLabel ); ac++;
	XtSetArg( al[ac], XmNshadowThickness, 0 ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	autodetToggle = XmCreateToggleButton( inputSec, "autodetToggle",
				al, ac );
	XtManageChild( autodetToggle );
	XmStringFree( labelStr );
	XtAddCallback( autodetToggle, XmNvalueChangedCallback,
			autodetCB, NULL );


	/*
	 *  Create Input Type List
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, autodetToggle ); ac++;
	XtSetArg( al[ac], XmNtopOffset, SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNvisibleItemCount, VIS_INPUT_TYPES ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNscrollBarDisplayPolicy, XmSTATIC ); ac++;

	intypeList = XmCreateScrolledList( inputSec, "intypeList", al, ac);
	XtManageChild( intypeList );

	/*
	 *  Set global variable so that others can access list
	 *  ( autodetect toggle button )
	 */

	inputTypesList = intypeList;

	listFillImForm( intypeList, *ImFileFormats, True );

	autodetValue = True;
	XmToggleButtonSetState( autodetToggle, autodetValue, True );

	return( inputSec );
}



/*
 *  FUNCTION: CreateButtonBar - Construct the conversion button bar
 */

static Widget CreateButtonBar( parent )
	Widget parent;
{
	Widget 		buttonBar;
	Widget		convertButton, previewButton;
	XmString	labelStr;
	Arg		al[10];
	int		ac;

	ac = 0;
	XtSetArg( al[ac], XmNhorizontalSpacing, HORIZ_FORM_OFFSET ); ac++;
	buttonBar = XmCreateForm( parent, "buttonBar", al, ac );

	ac = 0;
	labelStr = XmStringCreateLtoR( "Convert >>>", 
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNmarginHeight, FAT_BUTTON ); ac++;
	XtSetArg( al[ac], XmNmarginWidth, FAT_BUTTON ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopOffset, 15 * MED_OFFSET ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	convertButton = XmCreatePushButton( buttonBar, "convertButton",
				al, ac );
	XtAddCallback( convertButton, XmNactivateCallback, convCB, NULL );
	XtManageChild( convertButton );

	ac = 0;
	labelStr = XmStringCreateLtoR( "Preview", 
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNmarginHeight, FAT_BUTTON ); ac++;
	XtSetArg( al[ac], XmNmarginWidth, FAT_BUTTON ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, convertButton ); ac++;
	XtSetArg( al[ac], XmNtopOffset, MED_OFFSET ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	previewButton = XmCreatePushButton( buttonBar, "previewButton",
				al, ac );
	XtAddCallback( previewButton, XmNactivateCallback, prevueCB, NULL );
	XtManageChild( previewButton );

	XmStringFree( labelStr );

	return buttonBar;
}



/*
 *  FUNCTION: CreateOutputSec
 */
static Widget CreateOutputSec( parent )
	Widget parent;
{
	Widget		outputSec;
	Widget		dirLabel;
	Widget		dirText, filenameText;
	Widget		paramLabel;
	Widget		includeLabel;
	Widget		menuPane, defaultButton, menuButton;
	Widget		outTypeLabel;
	Widget		outTypeList;
	Arg		al[15];
	int		ac, i, len;
	XmString	labelStr;


	/*
	 *  Create container for output section of interface
	 */
	ac = 0;
	XtSetArg( al[ac], XmNhorizontalSpacing, HORIZ_FORM_OFFSET ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	outputSec = XmCreateForm( parent, "outputSec", al, ac );

	
	/*
	 *  Create label for path and filename of output
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Output File:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	dirLabel = XmCreateLabel( outputSec, "dirLabel", al, ac );
	XtManageChild( dirLabel );
	XmStringFree( labelStr );


	/*
	 *  Create output path entry
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, dirLabel ); ac++;
	XtSetArg( al[ac], XmNrows, 1 ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNeditMode, XmSINGLE_LINE_EDIT ); ac++;
	dirText = XmCreateText( outputSec, "dirText", al, ac );
	XtManageChild( dirText );


	/*
	 *  Set global variable so that other routines can have access
	 *  to this widget (directory changed callback to place the
	 *  the current directory in this widget
	 */
	outputDirText = dirText;
	textFillCurDir( outputDirText );


	/*
	 *  Create output filename entry
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, dirText ); ac++;
	XtSetArg( al[ac], XmNrows, 1 ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNeditMode, XmSINGLE_LINE_EDIT ); ac++;
	filenameText = XmCreateText( outputSec, "dirText", al, ac );
	XtManageChild( filenameText );

	/*
	 *  Set up global variable so that this widget can be accessed
	 *  from other routines.
	 */
	outputFnameText = filenameText;


	/*
	 *  Create label for output conversion parameters
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Output Conversion Parameters:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, filenameText ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	paramLabel = XmCreateLabel( outputSec, "paramLabel", al, ac );
	XtManageChild( paramLabel );
	XmStringFree( labelStr );


	/*
	 *  Create Alpha option menu (pop-down like)
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( outputSec, "alphaPane", al, ac);

	ac = 0;
	len = sizeof( AlphaOpts ) / sizeof( *AlphaOpts );
	alphaButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButton( menuPane, AlphaOpts[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, alphaCB,
				i );
		XtManageChild( menuButton );

		/*
		 *  Start building array of buttons used for compress 
		 *  menu.  These buttons form a parallel array with the
		 *  static string array of button labels.  This parallel
		 *  array is used to determine which buttons to sensitize
		 *  when certain image formats are selected.
		 */

		alphaButtons[i] = menuButton;
	}

	ac = 0;
	labelStr = XmStringCreateLtoR( "Alpha          ",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, paramLabel ); ac++;
	AlphaMenu = XmCreateOptionMenu( outputSec, "alphaMenu", al, ac );
	XtManageChild( AlphaMenu );
	XmStringFree( labelStr );

	
	/*
	 *  Create Color Table option menu (pop-down like)
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( outputSec, "cltPane", al, ac);

	ac = 0;
	len = sizeof( CLTOpts ) / sizeof( *CLTOpts );
	cltButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButton( menuPane, CLTOpts[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, cltCB,
				i );
		XtManageChild( menuButton );

		/*
		 *  Start building array of buttons used for compress 
		 *  menu.  These buttons form a parallel array with the
		 *  static string array of button labels.  This parallel
		 *  array is used to determine which buttons to sensitize
		 *  when certain image formats are selected.
		 */

		cltButtons[i] = menuButton;
	}

	ac = 0;
	labelStr = XmStringCreateLtoR( "Color Table    ",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, AlphaMenu ); ac++;
	CLTMenu = XmCreateOptionMenu( outputSec, "cltMenu", al, ac );
	XtManageChild( CLTMenu );
	XmStringFree( labelStr );

	
	/*
	 *  Create Compression option menu (pop-down like)
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( outputSec, "compressPane", al, ac);

	ac = 0;
	len = sizeof( CompressionTypes ) / sizeof( *CompressionTypes );
	compressButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButton( menuPane, CompressionTypes[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, compressCB,
				i );
		XtManageChild( menuButton );

		/*
		 *  Start building array of buttons used for compress 
		 *  menu.  These buttons form a parallel array with the
		 *  static string array of button labels.  This parallel
		 *  array is used to determine which buttons to sensitize
		 *  when certain image formats are selected.
		 */

		compressButtons[i] = menuButton;
	}

	ac = 0;
	labelStr = XmStringCreateLtoR( "Compression    ",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, CLTMenu ); ac++;
	CompressMenu = XmCreateOptionMenu( outputSec, "compressMenu", al, ac );
	XtManageChild( CompressMenu );
	XmStringFree( labelStr );

	
	/*
	 *  Create Channels option menu (pop-down like)
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( outputSec, "channelPane", al, ac);

	ac = 0;
	len = sizeof( Channels ) / sizeof( *Channels );
	channelButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButton( menuPane, Channels[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, channelCB,
				i );
		XtManageChild( menuButton );

		channelButtons[i] = menuButton;
	}

	ac = 0;
	labelStr = XmStringCreateLtoR( "Channels       ",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, CompressMenu ); ac++;
	ChannelMenu = XmCreateOptionMenu( outputSec, "channelMenu", al, ac );
	XtManageChild( ChannelMenu );
	XmStringFree( labelStr );

	
	/*
	 *  Create Channel Depth option menu (pop-down like)
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( outputSec, "chanDepthMP", al, ac);

	ac = 0;
	len = sizeof( ChanDepth ) / sizeof( *ChanDepth );
	chanDepthButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButton( menuPane, ChanDepth[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, chanDepthCB,
				i );
		XtManageChild( menuButton );

		chanDepthButtons[i] = menuButton;
	}

	ac = 0;
	labelStr = XmStringCreateLtoR( "Channel Depth  ",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, ChannelMenu ); ac++;
	ChanDepthMenu = XmCreateOptionMenu( outputSec, "chanDepthMenu",
				al, ac );
	XtManageChild( ChanDepthMenu );
	XmStringFree( labelStr );

	
	/*
	 *  Create Type menu (pop-down like)
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( outputSec, "typeMP", al, ac);

	ac = 0;
	len = sizeof( Types ) / sizeof( *Types );
	typeButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButton( menuPane, Types[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, typeCB,
				i );
		XtManageChild( menuButton );

		typeButtons[i] = menuButton;
	}

	ac = 0;
	labelStr = XmStringCreateLtoR( "Type           ",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, ChanDepthMenu ); ac++;
	TypeMenu = XmCreateOptionMenu( outputSec, "typeMenu",
				al, ac );
	XtManageChild( TypeMenu );
	XmStringFree( labelStr );


	/*
	 *  Create Interleaving menu (pop-down like)
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( outputSec, "interleavMP", al, ac);

	ac = 0;
	len = sizeof( Interleaving ) / sizeof( *Interleaving );
	interleavButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButton( menuPane, Interleaving[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, interleavCB,
				i );
		XtManageChild( menuButton );

		interleavButtons[i] = menuButton;
	}

	ac = 0;
	labelStr = XmStringCreateLtoR( "Interleaving   ",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, TypeMenu ); ac++;
	InterleavMenu = XmCreateOptionMenu( outputSec, "interleavMenu",
				al, ac );
	XtManageChild( InterleavMenu );
	XmStringFree( labelStr );


	
	/*
	 *  Create label for output types
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Output Type:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, InterleavMenu ); ac++;
	outTypeLabel = XmCreateLabel( outputSec, "outTypeLabel", al, ac );
	XtManageChild( outTypeLabel );
	XmStringFree( labelStr );

	/*
	 *  Create Output Type List
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, outTypeLabel ); ac++;
	XtSetArg( al[ac], XmNtopOffset, SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNvisibleItemCount, VIS_INPUT_TYPES ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNscrollBarDisplayPolicy, XmSTATIC ); ac++;

	outTypeList = XmCreateScrolledList( outputSec, "outTypeList", al, ac);
	XtManageChild( outTypeList );

	/*
	 *  Setup global version of output type so that the selected type
	 *  can be retrieved by other functions.
	 */
	outputTypesList = outTypeList;

	XtAddCallback( outputTypesList, XmNbrowseSelectionCallback,
			outTypeSelCB, NULL );

	listFillImForm( outTypeList, *ImFileFormats, False );

	return( outputSec );
}





/*
 *  FUNCTION: main
 *
 */

main( argc, argv )
	unsigned int argc;
	char **argv;
{
	Widget		appShell;
	Widget		main;
	Widget		menuBar;
	Widget		workRegion;
	Widget		inputSec, buttonBar, outputSec;
	XtAppContext	appContext;
	char 		*progname;
	int		ac;
	Arg		al[10];


	if ( ImToolsProgram = strrchr( argv[0], '/' ) )
		ImToolsProgram++;
	else
		ImToolsProgram = argv[0];

	XtToolkitInitialize( );
	appContext = XtCreateApplicationContext( );
	display = XtOpenDisplay( appContext, NULL, ImToolsProgram, 
			ImToolsProgram, NULL, 0, &argc, argv );

	if ( !display )
	{
		XtWarning( "jtst: can't open display." );
		exit( 0 );
	}

	appShell = XtAppCreateShell( ImToolsProgram, ImToolsProgram,
			applicationShellWidgetClass, display, NULL, 0 );

	
	/*
	 *  Create MainWindow;
	 */

	ac = 0;
	XtSetArg( al[ac], XmNscrollingPolicy, XmAPPLICATION_DEFINED ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNbottomWidget, appShell ); ac++;
	main = XmCreateMainWindow( appShell, "main", al, ac );
	XtManageChild( main );

	/*
	 *  CreateMenuBar in MainWindow
	 */

	menuBar = CreateMenuBar( main );
	XtManageChild( menuBar );

	ac = 0;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNbottomWidget, main ); ac++;
	workRegion = XmCreateForm( main, "workRegion", al, ac );
	XtManageChild( workRegion );

	/*
	 *  Create output dialog box
	 */
	outputDlg = CreateOutputDlg( workRegion );

	/*
	 *  Create Input Section
	 */
	inputSec = CreateInputSec( workRegion );
	XtManageChild( inputSec );

	/*
	 *  Create Button Bar
	 */
	buttonBar = CreateButtonBar( workRegion );
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNleftWidget, inputSec ); ac++;
	XtSetValues( buttonBar, al, ac );
	XtManageChild( buttonBar );

	/*
	 *  Create Ouput Section
	 */
	outputSec = CreateOutputSec( workRegion );
	ac = 0;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNleftWidget, buttonBar ); ac++;
	XtSetValues( outputSec, al, ac );
	XtManageChild( outputSec );


	XmMainWindowSetAreas( main, menuBar, NULL, NULL, NULL,
				workRegion );

	XtRealizeWidget( appShell );

	XtAppMainLoop( appContext );
}
