/**	$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxconv.h,v 1.4 93/09/27 12:04:17 secoskyj Exp $
 **	Copyright (c) 1989-1992  San Diego Supercomputer Center (SDSC)
 **		San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

/**
 **  FILE
 **	imxconv.h	- imconv GUI header
 **
 **  PROJECT
 **	IM		- Image Manipulation Tools
 **
 **  DESCRIPTION
 **	Contains things global to the imxconv interface, such at the 
 **	fallback look and feel of the interface.
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **	colorResources[]	v	holds default color and font choices
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	imxconv.h,v $
 **	Revision 1.4  93/09/27  12:04:17  secoskyj
 **	Changed color of background for text widgets within
 **	a custom dialog box.
 **	
 **	Revision 1.3  93/08/26  12:50:02  secoskyj
 **	Now workRegion (inside frame) text boxes appear in teh
 **	correct color of gray
 **	
 **	Revision 1.2  93/07/19  16:36:26  secoskyj
 **	removed HEADER definition
 **	
 **	Revision 1.1  93/07/19  16:06:19  secoskyj
 **	Initial revision
 **	
 **	
 **/

/*
 *  VARIABLE
 *	private String colorResources[]
 *
 *  DESCRIPTION
 *	This array holds the fallback resources for the imxconv interface.
 *	The resources that are set here are color and font resources.
 *
 *  NOTES
 *	All the fonts used here may not be on all systems.
 *
 */
static String colorResources[] = {
  "*XmLabel*fontList:   		-*-helvetica-bold-r-normal-*-14-*-*-*-*-*-iso8859-1",
  "*XmLabelGadget*fontList:		-*-helvetica-medium-r-normal-*-14-*-iso8859-1",
  "*XmScale*fontList:   		-*-helvetica-bold-r-normal-*-14-*-*-*-*-*-iso8859-1",
  "*XmBulletinBoard*labelFontList:	-*-helvetica-bold-r-normal-*-14-*-*-*-*-*-iso8859-1",
  "*optionmenu.XmLabelGadget*fontList:	-*-helvetica-bold-r-normal-*-14-*-*-*-*-*-iso8859-1",
  "*XmPushButton*fontList:   		-*-helvetica-bold-r-normal-*-14-*-*-*-*-*-iso8859-1",
  "*XmPushButtonGadget*fontList:	-*-helvetica-medium-r-normal-*-14-*-iso8859-1",
  "*XmToggleButton*fontList:	-*-helvetica-medium-r-normal-*-14-*-iso8859-1",
  "*XmToggleButtonGadget*fontList:	-*-helvetica-medium-r-normal-*-14-*-iso8859-1",
  "*optionmenu*fontList:		-*-helvetica-medium-r-normal-*-14-*-iso8859-1",
  "*XmIconGadget*fontList:		-*-helvetica-medium-r-normal-*-14-*-iso8859-1",
  "*XmBulletinBoard*buttonFontList: -*-helvetica-medium-r-normal-*-14-*-iso8859-1",
  "*menubar*fontList:   		-*-helvetica-bold-o-normal-*-14-*-iso8859-1",
  "*XmMenuShell*XmPushButton*fontList:  -*-helvetica-bold-o-normal-*-14-*-iso8859-1",
  "*XmMenuShell*XmLabelGadget*fontList: -*-helvetica-bold-o-normal-*-14-*-iso8859-1",
  "*XmMenuShell*XmPushButtonGadget*fontList: -*-helvetica-bold-o-normal-*-14-*-iso8859-1",
  "*XmMenuShell*XmCascadeButton*fontList: -*-helvetica-bold-o-normal-*-14-*-iso8859-1",
  "*XmMenuShell*XmCascadeButtonGadget*fontList: -*-helvetica-bold-o-normal-*-14-*-iso8859-1",
  "*XmMenuShell*XmToggleButton*fontList: -*-helvetica-bold-o-normal-*-14-*-iso8859-1",
  "*XmMenuShell*XmToggleButtonGadget*fontList: -*-helvetica-bold-o-normal-*-14-*-iso8859-1",
  "*XmPulldownMenu*fontList:	-*-helvetica-bold-o-normal-*-14-*-iso8859-1",
  "*XmList*fontList:	-*-courier-medium-r-normal-*-14-*-iso8859-1",
  "*XmText*fontList:	-*-courier-medium-r-normal-*-14-*-iso8859-1",
  "*XmTextField.fontList: -*-courier-medium-r-normal-*-14-*-iso8859-1",
  
  "*optionmenu*marginHeight: 	0",
  "*optionmenu*marginTop: 		5",
  "*optionmenu*marginBottom: 	5",
  "*optionmenu*marginWidth: 	5",
  "*XmPulldownMenu*XmPushButton*marginHeight:	1",
  "*xMPulldownMenu*XmPushButton*marginWidth:	1",
  "*XmPulldownMenu*XmPushButton*marginLeft:	3",
  "*XmPulldownMenu*XmPushButton*marginRight:	3",
  "*XmList*listMarginWidth:        3",
  "*menubar*marginHeight: 		1",
  "*menubar.marginHeight: 		0",
  "*menubar*marginLeft:  		1",
  "*menubar.spacing:  		7",
  "*XmMenuShell*marginLeft:  	3",
  "*XmMenuShell*marginRight:  	4",
  "*XmMenuShell*XmToggleButtonGadget*spacing: 	 2",
  "*XmMenuShell*XmToggleButtonGadget*marginHeight:  0",
  "*XmMenuShell*XmToggleButtonGadget*indicatorSize: 12",
  "*XmMenuShell*XmLabelGadget*marginHeight: 4",
  "*XmToggleButtonGadget*spacing: 	4",
  "*XmToggleButton*spacing: 	4",
  "*XmScrolledWindow*spacing: 	0",
  "*XmScrollBar*width: 		        18",
  "*XmScrollBar*height: 		18",
  "*XmScale*scaleHeight: 		20",
  "*XmText*marginHeight:		4",
  "*fillOnSelect:			True",
  "*visibleWhenOff:		        True",
  "*XmText*highlightThickness:		0",
  "*XmTextField*highlightThickness:	0",
  "*XmPushButton*highlightThickness:	0",
  "*XmScrollBar*highlightThickness:     0",
  "*highlightThickness:	                0",

  "*Foreground:			 		#000000000000",
  "*XmScrollBar*Foreground:             	#afafafafafaf",
  "*Background:                         	#afafafafafaf",
  "*workRegion*XmFrame*Background:   		#a0a0a0a0a0a0",
  "*workRegion*XmFrame*XmList*Background:	#afafafafafaf",
  "*workRegion*XmFrame*XmTextField*Background:	#afafafafafaf",
  "*workRegion*XmFrame*XmText*Background:	#afafafafafaf",
#ifdef NOTDEF
  "*workRegion*XmFrame*optionmenu*Background:	#afafafafafaf",
#endif
  "*XmList*Background:     			#afafafafafaf",
  "*XmText*Background:	 	        	#afafafafafaf",
  "*TroughColor:                        	#a0a0a0a0a0a0",
  "*XmSelectionBox*Background:	 		#afafafafafaf",
  "*XmMessageBox*Background:	 		#afafafafafaf",
  "*XmLabel*Foreground:                 	#1d1d15155b5b",
  "*XmToggleButton*Foreground:          	#1d1d15155b5b",
  "*XmPushButton*Foreground:            	#5b5b00000000",
  "*XmTextField*Background:	        	#afafafafafaf",
  "*SelectColor:				#ffffffff0000",
  "*HighlightColor:		 		#afafafafafaf",

  "*TopShadowColor:                     	#dfdfdfdfdfdf",
  "*XmList*TopShadowColor:              	#dfdfdfdfdfdf",
  "*XmText*TopShadowColor:              	#dfdfdfdfdfdf",
  "*XmSelectionBox*TopShadowColor:      	#dfdfdfdfdfdf",
  "*XmMessageBox*TopShadowColor:        	#dfdfdfdfdfdf",

  "*outputDlg*Background:   			#a0a0a0a0a0a0",
  "*outputDlg*XmText*Background: 		#afafafafafaf",
  "*outputDlg*XmList*Background:		#afafafafafaf",
  NULL,
};
