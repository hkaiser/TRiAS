#!/bin/sh
#
# Program: ximconv
#
# This file is an automatically created shell script
# for starting the application named: ximconv.tcl
#
# adapt the following variables to fit your
# local site
#
# set wish command to different directories for different
# machines
WISH_CMD=/sdsc/dev/sys/windowing/tk/tk32/bin/sun4/wish
if test "$WISH_CMD" = ""; then
  if [ -x /bin/4d ]; then
    if [ `/bin/4d` ]; then
      WISH_CMD=/sdsc/dev/sys/windowing/tk/tk32/bin/sgi4d/wish
    fi
  fi

  if [ -x /usr/kvm/sun4 ]; then
    if [ `/usr/kvm/sun4` ]; then
      WISH_CMD=/sdsc/dev/sys/windowing/tk/tk32/bin/sun4/wish
    fi
  fi
  if [ -x /usr/kvm/sun4c ]; then
    if [ `/usr/kvm/sun4c` ]; then
      WISH_CMD=/sdsc/dev/sys/windowing/tk/tk32/bin/sun4/wish
    fi
  fi
  if [ -x /usr/kvm/sparc ]; then
    if [ `/usr/kvm/sparc` ]; then
      WISH_CMD=/sdsc/dev/sys/windowing/tk/tk32/bin/sun4/wish
    fi
  fi

  if [ -x /bin/machine ]; then
    if [ `/bin/machine` = "mips" ]; then
      WISH_CMD=/sdsc/dev/sys/windowing/tk/tk32/bin/decstation/wish
    fi
  fi
fi
#
# XF_LOAD_PATH is the path were the tcl modules
# for this application are located
if test "$XF_LOAD_PATH" = ""; then
  XF_LOAD_PATH=./
else
  XF_LOAD_PATH=$XF_LOAD_PATH:/usr/local/lib/
fi
#
#
ARGC=$#
COMMANDLINE=
while [ $ARGC -gt 0 ]; do
  C=$1
  shift
  ARGC=`expr $ARGC - 1`
  case $C in
    -xfloadpath)
      if [ $ARGC -gt 0 ]; then
        C=$1
        shift
        ARGC=`expr $ARGC - 1`
        XF_LOAD_PATH=$C:$XF_LOAD_PATH
      else
        echo "ximconv.tcl: expected path for -xfloadpath"
        exit 2
      fi;;
    *)
      COMMANDLINE=$COMMANDLINE" "$C;;
  esac
done
#
export XF_LOAD_PATH
for p in `echo $XF_LOAD_PATH|awk 'BEGIN{RS=":"}{print $0}'`; do
  if test -f $p/ximconv.tcl; then 
    exec $WISH_CMD -n ximconv -f $p/ximconv.tcl $COMMANDLINE
  fi
done
echo "Could not find: ximconv.tcl"
# eof

