/****************************************************************************
 * xlogserver.cc
 * Authors Robert Earhart, Joel Welling
 * Copyright 1993, Pittsburgh Supercomputing Center, Carnegie Mellon University
 *
 * Permission use, copy, and modify this software and its documentation
 * without fee for personal use or use within your organization is hereby
 * granted, provided that the above copyright notice is preserved in all
 * copies and that that copyright and this permission notice appear in
 * supporting documentation.  Permission to redistribute this software to
 * other organizations or individuals is not granted;  that must be
 * negotiated with the PSC.  Neither the PSC nor Carnegie Mellon
 * University make any representations about the suitability of this
 * software for any purpose.  It is provided "as is" without express or
 * implied warranty.
 *****************************************************************************/

/**
 **	$Header: /sdsc/dev/vis/image/ihandler/src/RCS/ihandler_demo.cc,v 1.1 94/03/23 17:45:11 secoskyj Exp $
 **	Copyright (c) 1989-1994  San Diego Supercomputer Center (SDSC)
 **		a division of General Atomics, San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER  "$Header: /sdsc/dev/vis/image/ihandler/src/RCS/ihandler_demo.cc,v 1.1 94/03/23 17:45:11 secoskyj Exp $"

/**
 **  FILE
 **	ihandler_demo.cc	-  
 **
 **  PROJECT
 **	IM		-  
 **
 **  DESCRIPTION
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	ihandler_demo.cc,v $
 **	Revision 1.1  94/03/23  17:45:11  secoskyj
 **	Initial revision
 **	
 **	
 **/


#include <stdio.h>
#include <stdlib.h>
#include <X11/Xatom.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/RowColumn.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>

#include "im.h"
#include "rgbimage.h"
#include "imagehandler.h"
#include "ximagehandler.h"

static char *exename;
static Widget toplevel;
static baseImageHandler *ihandler;

static char *fname;

static void show_cb (Widget w,
		     XtPointer data,
		     XtPointer cb) {
  FILE *fp;
  rgbImage *image;
  
  fprintf(stderr,"Displaying the file %s\n",fname);

  if (! (fp=fopen(fname, "r"))) {
    fprintf(stderr,"invalid filename %s\n",fname);
    exit(-1);
  }
  
  image=new rgbImage(fp, fname);
  
  if (!image->valid()) {
    fprintf(stderr,"invalid image file %s\n",fname);
    fclose(fp);
    delete(image);
    exit(-1);
  }

  ihandler->display(image);

  baseImageHandler *other_ihandler=
    new XmautoImageHandler( toplevel, NULL, NULL, 0, image, fp );
}

static void exit_cb (Widget w,
		     XtPointer data,
		     XtPointer cb) {
  delete ihandler;
  exit(0);
}

main( int argc, char *argv[] )
{
  const int MAX_ARGS= 20;

  Widget main_window;
  Widget menu_bar;
  Widget menu_pane;
  Widget button;
  Arg    args[MAX_ARGS];
  int n;
  
  exename= argv[0];
  fname= argv[1];

  if (argc != 2) {
    fprintf(stderr,"usage: %s filename\n",argv[0]);
    exit(-1);
  }

  toplevel = XtInitialize(argv[0], "ihandler_demo", NULL, 0, &argc, argv);
  n= 0;
  main_window = XmCreateMainWindow(toplevel, "main", args, n);
  XtManageChild(main_window);
  n= 0;
  menu_bar = XmCreateMenuBar(main_window, "menu_bar", args, n);
  XtManageChild(menu_bar);
  n = 0;
  menu_pane = XmCreatePulldownMenu(menu_bar, "menu_pane", args, n);
  
  /* Create File Menu */
  XmString title_string= XmStringCreate("File", XmSTRING_DEFAULT_CHARSET);
  n = 0;
  XtSetArg(args[n], XmNsubMenuId, menu_pane); n++;
  XtSetArg(args[n], XmNlabelString, title_string); n++;
  XtSetArg(args[n], XmNmnemonic, 'F'); n++;
  button = XmCreateCascadeButton(menu_bar, "file", args, n);
  if (title_string) XmStringFree(title_string);
  XtManageChild(button);
  
  /* Create Show button */
  title_string= XmStringCreate("Show", XmSTRING_DEFAULT_CHARSET);
  n = 0;
  XtSetArg(args[n], XmNlabelString, title_string); n++;
  XtSetArg(args[n], XmNmnemonic, 'S'); n++;
  button = XmCreatePushButton(menu_pane, "show", args, n);
  XtAddCallback(button, XmNactivateCallback, show_cb, NULL);
  if (title_string) XmStringFree(title_string);
  XtManageChild(button);
  
  /* Create Exit button */
  title_string= XmStringCreate("Exit", XmSTRING_DEFAULT_CHARSET);
  n = 0;
  XtSetArg(args[n], XmNlabelString, title_string); n++;
  XtSetArg(args[n], XmNmnemonic, 'E'); n++;
  button = XmCreatePushButton(menu_pane, "exit", args, n);
  XtAddCallback(button, XmNactivateCallback, exit_cb, NULL);
  if (title_string) XmStringFree(title_string);
  XtManageChild(button);
  
  XtRealizeWidget(toplevel);

  Atom atomcolormapwindows= 
    XInternAtom(XtDisplay(toplevel), "WM_COLORMAP_WINDOWS", False);
  
  Window canvas_win = XtWindow(toplevel);
  XChangeProperty( XtDisplay(toplevel), XtWindow(toplevel), 
		   atomcolormapwindows, XA_WINDOW, 32, PropModeAppend, 
		   (unsigned char *)&canvas_win, 1 );

  ihandler= new XmautoImageHandler( toplevel );

  XtMainLoop();
  
}
