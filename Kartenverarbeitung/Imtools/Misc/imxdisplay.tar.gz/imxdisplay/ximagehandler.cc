/*****************************************************************************
 * ximagehandler.cc for pvm 2.4
 * Author Joel Welling, Rob Earhart
 * Copyright 1993, Pittsburgh Supercomputing Center, Carnegie Mellon University
 *
 * Permission use, copy, and modify this software and its documentation
 * without fee for personal use or use within your organization is hereby
 * granted, provided that the above copyright notice is preserved in all
 * copies and that that copyright and this permission notice appear in
 * supporting documentation.  Permission to redistribute this software to
 * other organizations or individuals is not granted;  that must be
 * negotiated with the PSC.  Neither the PSC nor Carnegie Mellon
 * University make any representations about the suitability of this
 * software for any purpose.  It is provided "as is" without express or
 * implied warranty.
 *****************************************************************************/

/**
 **	$Header: /sdsc/dev/vis/image/imtools/v3.0/imxdisplay/src/RCS/ximagehandler.cc,v 1.6 94/06/30 15:12:57 secoskyj Exp $
 **	Copyright (c) 1989-1994  San Diego Supercomputer Center (SDSC)
 **		a division of General Atomics, San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER  "$Header: /sdsc/dev/vis/image/imtools/v3.0/imxdisplay/src/RCS/ximagehandler.cc,v 1.6 94/06/30 15:12:57 secoskyj Exp $"

/**
 **  FILE
 **	ximagehander.c	-  
 **
 **  PROJECT
 **	IM		-  
 **
 **  DESCRIPTION
 **	An image tool to create a storyboard, or grid, of images from a given
 **	set of images.
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	ximagehandler.cc,v $
 **	Revision 1.6  94/06/30  15:12:57  secoskyj
 **	Added shared color support where all the images are forced to the
 **	first image's colormap.  Also integrated the three different 8-bit
 **	visual display options so that the user can go from one to the other
 **	from a menu in the interface
 **	
 **	Revision 1.5  94/05/27  20:00:26  secoskyj
 **	More robustly working with switching btwn dither and perfect color
 **	
 **	Revision 1.4  94/05/20  17:38:06  secoskyj
 **	the *_init functions now convert the read in vfb
 **	to the correct format to be displayed on the 
 **	visual being used
 **	
 **	Revision 1.3  94/05/20  17:06:01  secoskyj
 **	When leaving a window it will uninstall the current
 **	colormap, but will also install the default colormap
 **	to make sure the "correct" color map is installed 
 **	
 **	Revision 1.2  94/05/18  10:11:51  secoskyj
 **	Working with pseudocolor with colormaps changing
 **	
 **	Revision 1.1  94/03/23  17:30:05  secoskyj
 **	Initial revision
 **	
 **	
 **/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <X11/Intrinsic.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xmu/StdCmap.h>

/* I don't know why this isn't being defined on sparcs...
   but it isn't )Rob
*/

extern "C" Status XmuLookupStandardColormap(
    Display*            /* dpy */,
    int                 /* screen */,
    VisualID            /* visualid */,
    unsigned int        /* depth */,
    Atom                /* property */,
    Bool                /* replace */,
    Bool                /* retain */
);

#ifndef AVOID_XVIEW
#include <xview/xview.h>
#endif

#include <im.h>

#include "rgbimage.h"
#include "imagehandler.h"
#include "ximagehandler.h"

/* Notes-
 */

#ifdef NOTDEF
XStandardColormap XImageHandler::map_info;
#endif
Boolean okClt;
XStandardColormap stdCmap, defaultCmap;
extern int SubVisual;
int initedClt;

int XImageHandler::map_info_set= 0;

/*This is needed by a lot of things that use the class...*/

/*Note that the value returned by this ought to be deleted,
  if not null.
*/

XVisualInfo *get_best_visual(Display *dpy, int screen) {
    /*This should query the dpy for the best visual, and set depth
      and visual appropriately.*/

    XVisualInfo *vinfo = new XVisualInfo;
    
    /*Okay, try for 24 bit TrueColor...*/
    if (XMatchVisualInfo(dpy, screen, 24, TrueColor, vinfo))
	return(vinfo);
    
    /*First go for a 24 bit DirectColor (what I'm using as I write this :)*/
    if (XMatchVisualInfo(dpy, screen, 24, DirectColor, vinfo))
	return(vinfo);
    
    /*Okay, try for 12 bit DirectColor...*/
    if (XMatchVisualInfo(dpy, screen, 12, DirectColor, vinfo))
	return(vinfo);
    
    /*Okay, try for 12 bit TrueColor...*/
    if (XMatchVisualInfo(dpy, screen, 12, TrueColor, vinfo))
	return(vinfo);
    
    /*Okay, try for 12 bit PseudoColor...*/
    if (XMatchVisualInfo(dpy, screen, 12, TrueColor, vinfo))
	return(vinfo);
    
    /*Okay, try for 8 bit PseudoColor...*/
    if (XMatchVisualInfo(dpy, screen, 8, PseudoColor, vinfo))
	return(vinfo);
    
    /*Okay, try for 8 bit DirectColor...*/
    if (XMatchVisualInfo(dpy, screen, 8, DirectColor, vinfo))
	return(vinfo);
    
    /*Okay, try for 4 bit PseudoColor...*/
    if (XMatchVisualInfo(dpy, screen, 4, PseudoColor, vinfo))
	return(vinfo);
    
    /*Okay, try for 2 bit PseudoColor...*/
    if (XMatchVisualInfo(dpy, screen, 2, PseudoColor, vinfo))
	return(vinfo);

    /*If almost all fails, go for monochrome*/
    if (XMatchVisualInfo(dpy, screen, 2, StaticGray, vinfo))
	return(vinfo);

    /*If everything else fails, let the caller pick. */

    delete(vinfo);
 
    return(NULL);
}

XImageHandler::XImageHandler( Display *dpy_in, int screen_in, Window win_in )
: baseImageHandler()
{
  dpy= dpy_in;
  screen= screen_in;
  win= win_in;

  current_pixmap=0;
  
  inited=False;
  gc = NULL;
  map_info.colormap = 0;

  get_window_size();
  
  /* Determine the color capabilities of the device*/

  /*Since we're passed a window, use the window's visual and depth.*/
  {
      XWindowAttributes win_attrs;
      XGetWindowAttributes(dpy, win, &win_attrs);
      visual = win_attrs.visual;
      depth = win_attrs.depth;
  }

  // Check for monochrome case
  if (depth == 1) {
    init_fun = &XImageHandler::monochrome_init;
    display_fun= &XImageHandler::monochrome_display;
    return;
  }
  
  // Handle all other cases
  switch (visual->c_class) {
  case (int)TrueColor:
  case (int)DirectColor:
      init_fun = &XImageHandler::directcolor_init;
    display_fun= &XImageHandler::directcolor_display;
    break;
  case (int)PseudoColor:

    switch ( SubVisual )
    {
    case XIH_VCUSTOM:
	init_fun = &XImageHandler::customcolor_init;
	display_fun= &XImageHandler::customcolor_display;
	break;
    case XIH_VSHARED:
	init_fun = &XImageHandler::sharedcolor_init;
	display_fun= &XImageHandler::sharedcolor_display;
	break;
    default:
	init_fun = &XImageHandler::pseudocolor_init;
	display_fun= &XImageHandler::pseudocolor_display;
	break;
    }
    break;

  case (int)StaticColor:
    fprintf(stderr,
   "XImageHandler: Sorry, no color support for StaticColor visual type\n");
    exit(-1);
    break;
  case (int)GrayScale:
    fprintf(stderr,
   "XImageHandler: Sorry, no color support for GrayScale visual type\n");
    exit(-1);
    break;
  case (int)StaticGray:
    fprintf(stderr,
   "XImageHandler: Sorry, no color support for StaticGray visual type\n");
    exit(-1);
    break;
  };
}

XImageHandler::~XImageHandler()
{
    if (current_pixmap) XFreePixmap(dpy, current_pixmap);
    if (gc) XFreeGC(dpy, gc);
}




static Boolean check_display_local(Display *dpy) {
  char *name = DisplayString(dpy);

  if (*name == ':') /*Guaranteed to be local*/
     return True;
  else return False; /*Should check... maybe later.*/
}

void XImageHandler::display( rgbImage *image, short refresh)
{
  XWindowAttributes attrib;

  current_image= image;
  
  if (!XGetWindowAttributes(dpy,win,&attrib)) {
    fprintf(stderr,
	    "XImageHandler::generate_sun_rgbmap: Can't get attributes!\n");
    exit(-1);
  }

  if (current_pixmap)
      XFreePixmap(dpy, current_pixmap);

  image_x_size = image->xsize(); image_y_size = image->ysize();

  current_pixmap = XCreatePixmap(dpy, (Drawable)attrib.root, image->xsize(),
				 image->ysize(), depth);
    
  unsigned long valuemask;
  XGCValues xgcv;

  if (gc)
      XFreeGC(dpy, gc);
  
  valuemask= (GCForeground | GCBackground);
  xgcv.background= WhitePixel(dpy, screen);
  xgcv.foreground= BlackPixel(dpy, screen);
  gc= XCreateGC(dpy, win, valuemask, &xgcv);

  ximage= XGetImage(dpy, current_pixmap, 0, 0, image->xsize(), image->ysize(),
		    AllPlanes, ZPixmap);

  if (!ximage) {
      fprintf(stderr,
	      "XImageHandler::display: XGetImage failed!\n");
      exit(-1);
  }
  
  if (! inited)
      (this->*init_fun)();
  
  (this->*display_fun)(ximage);

  XPutImage(dpy, current_pixmap, gc, ximage, 0, 0, 0, 0,
	    image->xsize(), image->ysize());

  XDestroyImage(ximage);

  if (refresh && (attrib.map_state == IsViewable)) redraw();
}

void XImageHandler::redraw()
{
  /*Heh. BitBlt is so nice...*/
  get_window_size();
  if (inited) {
	  XCopyArea(dpy, current_pixmap, win, gc, 0, 0, win_x_size, win_y_size,
		    0, 0);
  }
/*
 *  ATTENTION
 *
 */
	installClt();
}

void XImageHandler::resize()
{
  /* This routine handles resize events on the window.
     Of course, all this really boils down to is generating
     a redraw request if the window grew.*/

    unsigned int old_win_x_size=win_x_size;
    unsigned int old_win_y_size=win_y_size;

    get_window_size();
    if (inited) {
	if ((win_x_size > old_win_x_size) || (win_y_size > old_win_y_size))
	    redraw();
    }
}


void XImageHandler::installClt()
{
    /*
     *  okClt is just a semaphore variable which is false when 
     *  the pointer is outside of the player window and is true
     *  when the pointer is inside the player window.
     */

    if ( okClt == False || SubVisual == XIH_VPSEUDO )
    {
	return;
    }
    XInstallColormap( dpy, map_info.colormap );
    XSetWindowColormap(dpy, win, map_info.colormap);
}


void XImageHandler::unInstallClt()
{
    if ( SubVisual == XIH_VPSEUDO )
    {
	return;
    }
    XUninstallColormap( dpy, map_info.colormap );

    /*
     *  Make sure the "system" colormap gets reinstalled when 
     *  we leave the image part of the window.  Will ensure other
     *  cmaps laying around will not get installed
     */

    XInstallColormap( dpy, DefaultColormap( dpy, screen ) );
    XSetWindowColormap(dpy, win, DefaultColormap( dpy, screen ) );
}



void XImageHandler::get_window_size()
{
  // This routine adjusts this object's ideas about window size to match
  // the current state of its window.

  Drawable root;
  int x, y;
  unsigned int border_width, depth_dummy;
  static unsigned int width, height;

  if ( !XGetGeometry(dpy, (Drawable)win, &root, &x, &y, &width, &height,
		     &border_width, &depth_dummy) ) {
    fprintf(stderr,"XImageHandler::get_window_size: fatal error!\n");
    exit(-1);
  }

  win_x_size= width;
  win_y_size= height;
}

void XImageHandler::monochrome_display(XImage *ximage)
{
    unsigned int xlim, ylim;
    unsigned long white= WhitePixel(dpy, screen);
    unsigned long black= BlackPixel(dpy, screen);
    register int i,j;
    register unsigned long pixel;
    int run_backwards= 0;
    long *thiserr, *nexterr, *tmperr, *tmpmem;
    register long *nptr, *tptr;
    
    const int fs_scale=1024;
    const int half_fs_scale=512;

    xlim= current_image->xsize();
    ylim= current_image->ysize();
    
    tmpmem= new long(2*(xlim + 2));
    thiserr=tmpmem;
    nexterr=tmpmem+xlim+2;
    
    /* Initialize Floyd-Steinberg error vectors */
    srandom((int) time(0));
    for (int col = 0; col < (int) xlim; ++col) {
	thiserr[col] = (random() % fs_scale - half_fs_scale) / 4;
    }
    
    /*We alternate carrying error to right and left to get a slightly
      better dither.*/
    for (j=0; j < (int) ylim; j++) {
	/*Clear up storage*/
	for (nptr = nexterr + xlim ; nptr >= nexterr; nptr--) {
            *nptr = 0;
        }
	if (! run_backwards) {
	    nptr=nexterr;
	    tptr=thiserr;
	    for (i=0;i<=(int)(xlim-1);i++) {
		long value= rgb_to_intensity(current_image->pix_r(i,j),
					     current_image->pix_g(i,j),
					     current_image->pix_b(i,j))
		    * fs_scale / 256 + tptr[1];
		if (value>=half_fs_scale) {
 		    pixel= white;
		    value -= fs_scale;
		}
		else {
		    pixel= black;
		}
		(void)XPutPixel(ximage, i, j, pixel);
		tptr[2] += (value * 7) / 16;
		nptr[0] += (value * 3) / 16;
		nptr[1] += (value * 5) / 16;
		nptr[2] += value / 16;
		++tptr;
		++nptr;
	    }
	}
	else {
	    nptr=nexterr + xlim - 1;
	    tptr=thiserr + xlim - 1;
	    for (i=xlim-1;i>=0;i--) {
		long value= rgb_to_intensity(current_image->pix_r(i,j),
					     current_image->pix_g(i,j),
					     current_image->pix_b(i,j))
		    * fs_scale / 256 + tptr[1];
		if (value>=half_fs_scale) {
		    pixel= white;
		    value -= fs_scale;
		}
		else {
		    pixel= black;
		}
		(void)XPutPixel(ximage, i, j, pixel);
		tptr[0] += (value * 7) / 16;
		nptr[2] += (value * 3) / 16;
		nptr[1] += (value * 5) / 16;
		nptr[0] += value / 16;
		
		--tptr;
		--nptr;
	    }
	}
	run_backwards= !run_backwards;
	tmperr=thiserr;
	thiserr=nexterr;
	nexterr=tmperr;
    }
    delete(tmpmem);
}

void XImageHandler::pseudocolor_display(XImage *ximage)
{
    int xlim, ylim;
    register int i,j;
    int run_backwards= 0;
    register long *rnptr, *gnptr, *bnptr, *rtptr, *gtptr, *btptr;
    register long r, g, b;
    register long rpart, gpart, bpart;
    register long rfrac, gfrac, bfrac;
    register unsigned long pixel;
    
    int fs_scale = 1024;
    int half_fs_scale = 512;
    
    xlim= current_image->xsize();
    ylim= current_image->ysize();

    long *tmpmem = new long [ 6*(xlim+2) ];
    long *tmperr;
    long *r_err= tmpmem;
    long *g_err= tmpmem + 2*(xlim+2);
    long *b_err= tmpmem + 4*(xlim+2);

    long *r_err_next = r_err + xlim + 2;
    long *g_err_next = g_err + xlim + 2;
    long *b_err_next = b_err + xlim + 2;
    
    /* Initialize Floyd-Steinberg error vectors */
    srandom((int) time(0));
    for (int col = 0; col <= (xlim+1); ++col) {
	r_err[col] = (random() % fs_scale - half_fs_scale) / 4;
	g_err[col] = (random() % fs_scale - half_fs_scale) / 4;
	b_err[col] = (random() % fs_scale - half_fs_scale) / 4;
    }
    
    for (j=0; j<ylim; j++) {
	/* clean out memory */
	rnptr = r_err_next + xlim + 1;
	gnptr = g_err_next + xlim + 1;
	bnptr = b_err_next + xlim + 1;

	for (; rnptr >= r_err_next; rnptr--,gnptr--,bnptr--)
	    *bnptr = *gnptr = *rnptr = 0;

	if (run_backwards) {
	    rnptr = r_err_next + xlim - 1;
	    gnptr = g_err_next + xlim - 1;
	    bnptr = b_err_next + xlim - 1;

	    rtptr = r_err + xlim - 1;
	    gtptr = g_err + xlim - 1;
	    btptr = b_err + xlim - 1;
	    
	    for (i=xlim-1; i>=0; i--) {

		/* what we're doing here is extracting "part" and "frac"
		   values. "Part" values are used to directly determine
		   the pixel intensity; they should always come out on
		   pixel plane values. "Frac" values should be divided up
		   in the sixteenfold way amongst adjoining dither cells.
		   */

		r= current_image->pix_r(i,j) * fs_scale * map_info.red_max
		    / 256 + rtptr[1];
		if ((rfrac = r % fs_scale) >= half_fs_scale) {
		    rpart = (r + fs_scale - rfrac) / fs_scale;
		    rfrac -= fs_scale;
		} else
		    rpart = (r - rfrac) / fs_scale;
		rtptr[0] += (rfrac * 7) / 16;
		rnptr[2] += (rfrac * 3) / 16;
		rnptr[1] += (rfrac * 5) / 16;
		rnptr[0] += rfrac / 16;
		--rtptr;
		--rnptr;
		
		g= current_image->pix_g(i,j) * fs_scale * map_info.green_max
		    / 256 + gtptr[1];
		if ((gfrac = g % fs_scale) >= half_fs_scale) {
		    gpart = (g + fs_scale - gfrac) / fs_scale;
		    gfrac -= fs_scale;
		} else
		    gpart = (g - gfrac) / fs_scale;
		gtptr[0] += (gfrac * 7) / 16;
		gnptr[2] += (gfrac * 3) / 16;
		gnptr[1] += (gfrac * 5) / 16;
		gnptr[0] += gfrac / 16;
		--gtptr;
		--gnptr;
		
		b= current_image->pix_b(i,j) * fs_scale * map_info.blue_max
		    / 256 + btptr[1];
		if ((bfrac = b % fs_scale) >= half_fs_scale) {
		    bpart = (b + fs_scale - bfrac) / fs_scale;
		    bfrac -= fs_scale;
		} else
		    bpart = (b - bfrac) / fs_scale;
		btptr[0] += (bfrac * 7) / 16;
		bnptr[2] += (bfrac * 3) / 16;
		bnptr[1] += (bfrac * 5) / 16;
		bnptr[0] += bfrac / 16;
		--btptr;
		--bnptr;
		
		pixel= map_info.base_pixel 
		    + rpart*map_info.red_mult
			+ gpart*map_info.green_mult
			    + bpart*map_info.blue_mult;
		
		(void)XPutPixel(ximage, i, j, pixel);
	    }
	}
	else {
	    rnptr = r_err_next;
	    gnptr = g_err_next;
	    bnptr = b_err_next;

	    rtptr = r_err;
	    gtptr = g_err;
	    btptr = b_err;
	    
	    for (i=0; i<=(xlim - 1); i++) {
		r= current_image->pix_r(i,j) * fs_scale * map_info.red_max
		    / 256 + rtptr[1];
		if ((rfrac = r % fs_scale) >= half_fs_scale) {
		    rpart = (r + fs_scale - rfrac) / fs_scale;
		    rfrac -= fs_scale;
		} else
		    rpart = (r - rfrac) / fs_scale;
		rtptr[2] += (rfrac * 7) / 16;
		rnptr[0] += (rfrac * 3) / 16;
		rnptr[1] += (rfrac * 5) / 16;
		rnptr[2] += rfrac / 16;
		++rtptr;
		++rnptr;
		
		g= current_image->pix_g(i,j) * fs_scale * map_info.green_max
		    / 256 + gtptr[1];
		if ((gfrac = g % fs_scale) >= half_fs_scale) {
		    gpart = (g + fs_scale - gfrac) / fs_scale;
		    gfrac -= fs_scale;
		} else
		    gpart = (g - gfrac) / fs_scale;
		gtptr[2] += (gfrac * 7) / 16;
		gnptr[0] += (gfrac * 3) / 16;
		gnptr[1] += (gfrac * 5) / 16;
		gnptr[2] += gfrac / 16;
		++gtptr;
		++gnptr;
		
		b= current_image->pix_b(i,j) * fs_scale * map_info.blue_max
		    / 256 + btptr[1];
		if ((bfrac = b % fs_scale) >= half_fs_scale) {
		    bpart = (b + fs_scale - bfrac) / fs_scale;
		    bfrac -= fs_scale;
		} else
		    bpart = (b - bfrac) / fs_scale;
		btptr[2] += (bfrac * 7) / 16;
		bnptr[0] += (bfrac * 3) / 16;
		bnptr[1] += (bfrac * 5) / 16;
		bnptr[2] += bfrac / 16;
		++btptr;
		++bnptr;
		
		pixel= map_info.base_pixel 
		    + rpart*map_info.red_mult
			+ gpart*map_info.green_mult
			    + bpart*map_info.blue_mult;
		
		(void)XPutPixel(ximage, i, j, pixel);
	    }
	}
	run_backwards= !run_backwards;
	tmperr = r_err;
	r_err = r_err_next;
	r_err_next = tmperr;
	tmperr = g_err;
	g_err = g_err_next;
	g_err_next = tmperr;
	tmperr = b_err;
	b_err = b_err_next;
	b_err_next = tmperr;
    }
    
    delete(tmpmem);
}

void XImageHandler::directcolor_display(XImage *ximage)
{
    int xlim, ylim;
    register int i,j;
    
    xlim= current_image->xsize();
    ylim= current_image->ysize();
    
    if ( (map_info.red_max==255) && (map_info.green_max==255)
	&& (map_info.blue_max==255) ) {
	// short cut to handle most common case
	    for (i=0; i<xlim; i++)
		for (j=0; j<ylim; j++) {
		    unsigned long pixel= map_info.base_pixel
			+current_image->pix_r(i,j)*map_info.red_mult
			    +current_image->pix_g(i,j)*map_info.green_mult
				+current_image->pix_b(i,j)*map_info.blue_mult;
		    (void)XPutPixel(ximage, i, j, pixel);
		}
    }
    else {
	for (i=0; i<xlim; i++)
	    for (j=0; j<ylim; j++) {
		unsigned long pixel= map_info.base_pixel
		    +(((current_image->pix_r(i,j)*(map_info.red_max+1))/256)
		      *map_info.red_mult)
			+(((current_image->pix_g(i,j)*(map_info.green_max+1))/256)
			  *map_info.green_mult)
			    +(((current_image->pix_b(i,j)*(map_info.blue_max+1))/256)
			      *map_info.blue_mult);
		(void)XPutPixel(ximage, i, j, pixel);
	    }
    }
}


void XImageHandler::monochrome_init()
{
    inited=True;
}

int XImageHandler::server_is_sun_or_hp()
/* This routine returns true if the display is a Sun X11/News or HP server */
{
  char *vendor= XServerVendor(dpy);

  return( !strncmp(vendor, "X11/NeWS", 8) 
         || !strncmp(vendor, "Hewlett-Packard Company",23) );
}

static int pxl_compare( const void *p1, const void *p2 )
/* This routine is used by qsort to sort a list of pixel values. */
{
  if (*(long *)p1 > *(long *)p2) return(-1);
  if (*(long *)p1 == *(long *)p2) return(0);
  return(1);
}

void XImageHandler::generate_sun_rgbmap()
/* This routine generates an rgb map that won't frighten X11/News */ 
{
  int noSet= 0, noGrabbed= 0, noAlloced= 0;
  XWindowAttributes attrib;
  XColor *myColors= (XColor *)0;
  unsigned long pixels[512]; 
  int contig_pixels, start_pixel= 0;
  int l, m;
  unsigned int i, j, k;
  int found_map_space;
  static int initCMapBefore;

  /*
   *  Check to see if we have installed the colors into the colormap
   *  for dithering already.  If we have been here before, then return
   *  and set the map_info colormap used by the dithered images
   *  to the standard colormap we set up in a previous casll to 
   *  generate_sun_rgbmap.
   */

  if ( initCMapBefore )
  {
	map_info = defaultCmap;
	return;
  }
  
  /* The actual color map will be the display's default map */
  /*
   *  I thought that I may be able to copy the default map and
   *  modify the copy, but then when moving in and out of the 
   *  application, one will notice the colormap switching, not 
   *  giving the desired effect.  (secoskyj)
   */
  if (!XGetWindowAttributes(dpy,win,&attrib)) {
    fprintf(stderr,
	    "XImageHandler::generate_sun_rgbmap: Can't get attributes!\n");
    exit(-1);
  }
  map_info.colormap= attrib.colormap;
  
  /* grab as many colours as possible */ 
  /* assume < 512 colours needed */ 
  for (l=256; l>0; l/=2) { 
    if (XAllocColorCells(dpy, map_info.colormap, False, 0, 0, 
			 pixels + noAlloced, l)) {
      noAlloced += l;
    }
  }

  /* Sort the available pixels */
  (void)qsort(pixels, noAlloced, sizeof(long), pxl_compare);
  
  /* Find a contiguous stretch to make into a map (top preferred) */
  m= 0;
  found_map_space= 0;
  while (!found_map_space && m<noAlloced) {
    contig_pixels= 0;
    start_pixel= m;
    m += 1;
    while (m<noAlloced && pixels[m] == pixels[m-1]-1) {
      contig_pixels++;
      m++;
    }
    if (contig_pixels>=64) { /* Found a place to put the map */
      if (contig_pixels>=216) { /* 6x6x6 case */
	map_info.red_max= 5;
	map_info.green_max= 5;
	map_info.blue_max= 5;
      }
      else if (contig_pixels>=180) { /* 6x6x5 case */
	map_info.red_max= 5;
	map_info.green_max= 5;
	map_info.blue_max= 4;
      }
      else if (contig_pixels>=150) { /* 6x5x5 case */
	map_info.red_max= 5;
	map_info.green_max= 4;
	map_info.blue_max= 4;
      }
      else if (contig_pixels>=125) { /* 5x5x5 case */
	map_info.red_max= 4;
	map_info.green_max= 4;
	map_info.blue_max= 4;
      }
      else if (contig_pixels>=100) { /* 5x5x4 case */
	map_info.red_max= 4;
	map_info.green_max= 4;
	map_info.blue_max= 3;
      }
      else if (contig_pixels>=80) { /* 5x4x4 case */
	map_info.red_max= 4;
	map_info.green_max= 3;
	map_info.blue_max= 3;
      }
      else { /* 4x4x4 case */
	map_info.red_max= 3;
	map_info.green_max= 3;
	map_info.blue_max= 3;
      }
      map_info.blue_mult= 1;
      map_info.green_mult= map_info.blue_max+1;
      map_info.red_mult= map_info.green_mult * (map_info.green_max + 1);
      map_info.base_pixel= start_pixel;
      noSet = (int) ((map_info.red_max + 1) * (map_info.green_max + 1)
			 * (map_info.blue_max + 1));
      found_map_space= 1;
#ifdef DEBUG
      fprintf( stderr, "Using %dx%dx%d Colormap\n", map_info.red_max+1,
		map_info.green_max+1, map_info.blue_max+1 );
#endif
    }
  }
  if (!found_map_space) {
    fprintf(stderr,
     "XImageHandler::generate_sun_rgbmap: couldn't find color table space!\n");
    exit(-1);
  }
  map_info.base_pixel= pixels[0] - noSet + 1;

  /* Free up unneeded color cells */
  if (start_pixel != 0) 
    XFreeColors(dpy, map_info.colormap, pixels, start_pixel, 0);
  if (start_pixel+noSet < noAlloced)
    XFreeColors(dpy, map_info.colormap, pixels+start_pixel+noSet, 
		noAlloced-(start_pixel+noSet), 0);    
  
  /* make up our default colour table */ 
  myColors= new XColor[noSet];
  
  /* Create the map */
  noGrabbed= 0;
  for (i=0; i<=map_info.red_max; ++i)
      for (j=0;j<=map_info.green_max; ++j)
	for (k=0; k<=map_info.blue_max;++k) {
	  myColors[noGrabbed].flags =
	    DoRed | DoGreen | DoBlue;
	myColors[noGrabbed].pixel = map_info.base_pixel + 
	    i * map_info.red_mult +
	      j * map_info.green_mult +
		k * map_info.blue_mult;
	/* now fill out the values */
	myColors[noGrabbed].red = (unsigned short)
	    ((i * 65535)/ map_info.red_max);
	myColors[noGrabbed].green = (unsigned short)
	    ((j * 65535) / map_info.green_max);
	myColors[noGrabbed].blue = (unsigned short)
	    ((k * 65535)/ map_info.blue_max);
	noGrabbed++;
    } 
  
  /* now store the colours, should be OK */ 
  XStoreColors(dpy, map_info.colormap, myColors, noGrabbed); 
  
  /* Clean up */
  delete myColors;

  /*
   *  Show that we have been here before, so that we can reuse the
   *  the colors which we have allocated in the default colormap
   */

  initCMapBefore = 1;
}


void XImageHandler::resetMapInfo()
{
	map_info_set = 0;
}

void XImageHandler::pseudocolor_init()	
{
    inited=True;

    /*
     *  Dithering code like image to be in 24-bit format, so convert
     *  to 24-bit if necessary (toRgb()) is smart enough to figure out
     *  if the image needs to be converted.
     */

    current_image->toRgb();

    /* Have to handle Sun X11/News and HP separately */
    if (!map_info_set) {
	generate_sun_rgbmap();
#ifdef NOTDEF
	if (server_is_sun_or_hp()) {
	    generate_sun_rgbmap();
	}
	else {
	    XStandardColormap *mymaps;
	    int count;
	    if (XGetRGBColormaps(dpy, RootWindow(dpy,screen), &mymaps, &count,
				 XA_RGB_DEFAULT_MAP)) {
		map_info= *mymaps; // bitwise copy will work
	    }
	    else {
		if (XmuLookupStandardColormap(dpy, screen,
					      XVisualIDFromVisual(visual),
					      depth, XA_RGB_DEFAULT_MAP, 
					      False, True)) {
		    if (XGetRGBColormaps(dpy, RootWindow(dpy,screen),
					 &mymaps, &count,
					 XA_RGB_DEFAULT_MAP)) {
			map_info= *mymaps; // bitwise copy will work
			}
		    else {
			fprintf(stderr,
				"Can't get appropriate colormap!\n");
			exit(-1);
		    }
		}
		else {
		    fprintf(stderr,"Can't get appropriate colormap!\n");
		    exit(-1);
		}
	    }
	}
#endif
	map_info_set= 1;
	defaultCmap = map_info;
    }
    else
    {
	/*
	 *  Copy the current colormap used for dithering for this
	 *  image, and keep you fingers crossed that it works ok.
	 */
	map_info = defaultCmap;
    }

    XSetWindowColormap(dpy, win, map_info.colormap);
}

void XImageHandler::directcolor_init()	
{
    inited=True;

    /*
     *  Convert to rgb if not already in rgb format
     */

    current_image->toRgb();

    /* We assume this is a 24 bit system with 8 bits per color */
    map_info.base_pixel= 0;
    map_info.red_max= 255;
    map_info.red_mult= 256*256;
    map_info.green_max= 255;
    map_info.green_mult= 256;
    map_info.blue_max= 255;
    map_info.blue_mult= 1;
    map_info.colormap= DefaultColormap(dpy,screen);
}



/*
 *  FUNCTION
 *	vxdXAllocColorsFromClt --  allocate static X colors from a CLT
 *
 *  DESCRIPTION
 *	Read the entries from the given CLT and allocate a static X
 *	color for each in the given X colormap.  True is returned if
 *	we succeed, otherwise False is returned.
 *
 *	We also allocate and fill the vxdPixel array, used to map VFB
 *	indices into X indicies.
 *
 *	If we fail, we free all of the colors we allocated.
 */
int XImageHandler::XIHAllocColorsFromClt(ImClt *clt)
{
	register ImCltPtr	pClt;	/* current CLT color pointer	*/
	register int		i;	/* counters			*/
	register int		nColors;/* size of CLT			*/
  	XColor 			*myColors= (XColor *)0;
	XWindowAttributes 	attrib;
	int			colorShift = 8;

	nColors = ImCltQNColors(clt);

	map_info.colormap = XCreateColormap( dpy, win, visual, AllocAll );
	map_info.base_pixel = 0;

	/*
	 * Allocate index table
	 */
	myColors= new XColor[nColors];
	if(myColors == NULL)
	{
		fprintf(stderr,"Unable to allocate colors\n");
		return 0;
	}

	/*
	 * Allocate entries
	 */
	pClt = ImCltQFirst(clt);

	for(i=0; i < nColors; i++) 
	{
		myColors[i].flags = DoRed | DoGreen | DoBlue;
		myColors[i].pixel = i;
		myColors[i].red = ImCltQRed(pClt) << colorShift;
		myColors[i].green = ImCltQGreen(pClt) << colorShift;
		myColors[i].blue = ImCltQBlue(pClt) << colorShift;
		ImCltSInc(clt,pClt);
	}

	/* now store the colours, should be OK */ 
	XStoreColors(dpy, map_info.colormap, myColors, nColors); 
	  
	/* Clean up */
	delete myColors;

	return 1;
}



void XImageHandler::customcolor_init()
{
	ImClt *clt;

    	inited=True;

	/*
	 *  Convert to visual format if not already in visual format
	 *  toIndex8 is smart to enough to figure out if an image is 
	 *  already in index8 format.
	 */

	current_image->toIndex8();
	clt = current_image->vfbClt();
	XIHAllocColorsFromClt(clt);

	return;
}



void XImageHandler::customcolor_display(XImage *ximage)
{
    int xlim, ylim;
    register int i,j;

    xlim= current_image->xsize();
    ylim= current_image->ysize();

    for (i=0; i<xlim; i++)
    {
	for (j=0; j<ylim; j++)
	{
		unsigned long pixel= current_image->index8( i, j );
		(void)XPutPixel(ximage, i, j, pixel);
	}
    }
    installClt();

    /*
     *  XFlush(dpy);
     */
}




int findClosest( Display *dpy, XColor *colors, XColor *srchColor,
	int nColors )
{
	unsigned long		i, diff, min_diff, tmp;
	int			cmapEntry;
	int			colorShift = 8;

	diff = min_diff = 32 * 256 * 256 * 2;
	srchColor->red = (srchColor->red >> colorShift) & 0xff;
	srchColor->green = (srchColor->green >> colorShift) & 0xff;
	srchColor->blue = (srchColor->blue >> colorShift) & 0xff;


	i = nColors;
	while ( ( i > 0 ) && ( diff != 0) )
	{
		i--;
		tmp = srchColor->red - colors[i].red;
		tmp *= tmp;
		diff = 11 * tmp;

		tmp = srchColor->green - colors[i].green;
		tmp *= tmp;
		diff += 16 * tmp;

		tmp = srchColor->blue - colors[i].blue;
		tmp *= tmp;
		diff += 5 * tmp;

		if ( diff < min_diff )
		{
			min_diff = diff;
			cmapEntry = i;
		}
	}

	srchColor->red = colors[cmapEntry].red;
	srchColor->green = colors[cmapEntry].green;
	srchColor->blue = colors[cmapEntry].blue;
	srchColor->pixel = cmapEntry;

	return cmapEntry;
}



void XImageHandler::sharedcolor_init()
{
	ImClt *clt;
	XColor color;
	unsigned long i;
	int nColors;
	int colorShift = 8;
        ImCltPtr pClt;
	XColor cmapColors[256];

    	inited=True;

	/*
	 *  Convert to visual format if not already in visual format
	 *  toIndex8 is smart to enough to figure out if an image is 
	 *  already in index8 format.
	 */

	current_image->toIndex8();

	/*
	 *  Since the colormap will be shared, only allocate one of
	 *  them.
	 */

	clt = current_image->vfbClt();
	nColors = ImCltQNColors( clt );
	pixelMap = new unsigned long[nColors];
	if ( pixelMap == NULL )
	{
		fprintf( stderr, "Unable to allocate pixel table\n" );
		exit( 1 );
	}

	if ( !initedClt )
	{
		fprintf( stderr, "Generating Shared Colormap\n" );
		XIHAllocColorsFromClt(clt);
		stdCmap = map_info;
		for ( i = 0; i < nColors; i++ )
			pixelMap[i] = i;
		initedClt = 1;
	}
	else
	{
		map_info = stdCmap;
		color.flags = DoRed | DoGreen | DoBlue;

		for ( i = 0; i < nColors; i++ )
		{
			cmapColors[i].pixel = i;
			cmapColors[i].flags = DoRed | DoGreen | DoBlue;
		}

		XQueryColors( dpy, map_info.colormap, cmapColors, nColors );

		for ( i = 0; i < nColors; i++ )
		{
			cmapColors[i].red = (cmapColors[i].red >> colorShift)
							& 0xff;
			cmapColors[i].green = (cmapColors[i].green >>colorShift)
							&0xff;
			cmapColors[i].blue = (cmapColors[i].blue >> colorShift)
							& 0xff;
		}

		pClt = ImCltQFirst( clt );
		for ( i = 0; i < nColors; i++ )
		{
			color.pixel = i;
			color.red = ImCltQRed( pClt ) << colorShift;
			color.green = ImCltQGreen( pClt ) << colorShift;
			color.blue = ImCltQBlue( pClt ) << colorShift;

			findClosest( dpy, cmapColors, &color, nColors );
			pixelMap[i] = color.pixel;
			ImCltSInc( clt, pClt );
		}
	}

	return;
}



void XImageHandler::sharedcolor_display(XImage *ximage)
{
    int 		xlim, ylim;
    register int 	i,j;

    xlim= current_image->xsize();
    ylim= current_image->ysize();

    for (i=0; i<xlim; i++)
    {
	for (j=0; j<ylim; j++)
	{
		unsigned long pixel= current_image->index8( i, j );

		/*
		 *  Most of this function should be the same as 
		 *  customcolor display, but we need to reindex the image
		 *  at this point, before we create the ximage structure
		 */
		
		(void)XPutPixel(ximage, i, j, pixelMap[pixel]);
	}
    }

    /*
     *  XFlush(dpy);
     */
}
