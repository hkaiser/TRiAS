/**	$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxconv.c,v 1.16 93/09/27 11:30:48 secoskyj Exp Locker: secoskyj $
 **	Copyright (c) 1989-1992  San Diego Supercomputer Center (SDSC)
 **		San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER  "$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxconv.c,v 1.16 93/09/27 11:30:48 secoskyj Exp Locker: secoskyj $"

/**
 **  FILE
 **	imxconv.c	- imconv GUI
 **
 **  PROJECT
 **	IM		- Image Manipulation Tools
 **
 **  DESCRIPTION
 **	A graphical user interface for imconv.  Attempts to make output
 **	parameter selection easier along with the conversion of multiple
 **	image files.
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **	main		f  main program
 **
 **  PRIVATE CONTENTS
 **	VIS_INPUT_FILES		d	Number of input files to initially
 **					list in input image file file
 **					selection box
 **	VIS_INPUT_TYPES		d	Number of lines to initially display
 **					in input types list box (same
 **					list used to store automatic type
 **					detection)
 **	VIS_NUM_COLS		d	Number of columns to initially
 **					display for filename text and list
 **					widgets
 **	SMALL_OFFSET		d	Number of pixels used for small
 **					widget to widget offsets
 **	MED_OFFSET		d	Number of pixels used for medium
 **					widget to widget offsets
 **	HORIZ_FORM_OFFSET	d	Number of pixels to offset the main
 **					form from the window border on the
 **					horizontal axis
 **	VERT_FORM_OFFSET	d	Number of pixels to offset the main
 **					form from the window border on the
 **					vertical axis
 **	FAT_BUTTON		d	Width of fat button on button bar
 **	MAX_DIR_ENTRIES		d	Maximum number of allowable directory
 **					entries per directory
 **	MAX_DIR_NAME		d	Maximum length of a directory name or
 **					filename
 **	MAX_NIMFORMATS		d	Maximum number of formats supported
 **	MAX_BUF_STR		d	Maximum length for buffer strings
 **	MAX_FILEEXT_LEN		d	Maximum length for a file extention
 **	MULT_FILE_SEL_STR	d	String used in place of an output
 **					name when multiple filenames are
 **					selected
 **	AUTODET_STR		d	String used as a message to indicate
 **					that the automatic file detection data
 **					is being displayed in the input types
 **					scrolled list
 **	INPUTTYPE_STR		d	String used as a message to instruct
 **					the user to select an input image type
 **	BELL_VOLUME		d	Volume of bell when using XBell()
 **
 **
 **	MENU_CONVERT		d	MENU_* defines are used to tell which
 **	MENU_EXIT		d	menu item was selected in the menu
 **	MENU_LOGFILE		d	callback routine
 **	MENU_VERBOSE		d
 **	MENU_EXPERT		d
 **	MENU_HELP_FORMATS	d
 **	MENU_HELP_PARAM		d
 **	MENU_HELP_ABOUT		d
 **
 **
 **	IALPHA_YES		d	I* defines are used to control the
 **	IALPHA_NO		d	options buttons used in the output
 **	ICLT_YES		d	parameter option menus.  The indices
 **	ICLT_NO			d	for each of the defined constants 
 **	ITYPE_INDEX		d	represents the position that the 
 **	ITYPE_RGB		d	corresponding string take in the 
 **	ITYPE_2D		d	string array for the menu.  For example
 **	ICHANNEL_1		d	ICHANDEPTH_5 is the 4th item on 
 **	ICHANNEL_3		d	the Channel Depth menu, so its value
 **	ICHANDEPTH_1		d	is 3.  If one looks at the string
 **	ICHANDEPTH_2		d	arrays for the menu items, one will
 **	ICHANDEPTH_4		d	understand these indices a little
 **	ICHANDEPTH_5		d	better.
 **	ICHANDEPTH_8		d
 **	ICHANDEPTH_16		d
 **	ICOMPRESS_NO		d
 **	ICOMPRESS_RLE		d
 **	ICOMPRESS_LZW		d
 **	ICOMPRESS_PB		d
 **	ICOMPRESS_DCT		d
 **	IINTERLEAV_NO		d
 **	IINTERLEAV_LINE		d
 **	IINTERLEAV_PLANE	d
 **
 **  HISTORY
 **	$Log:	imxconv.c,v $
 **	Revision 1.16  93/09/27  11:30:48  secoskyj
 **	Removed input message text area, just commented out,
 **	can bring back if necessary
 **	
 **	Revision 1.15  93/09/27  11:16:01  secoskyj
 **	Several changes:  standard and expert mode, output parameter help
 **	working, format help working, better handling of input file directory
 **	text field, limit placed on how small application window can be,
 **	other misc text, font, and color adjustments, added spearator
 **	to custom dialog boxes
 **	
 **	Revision 1.14  93/08/27  10:06:02  secoskyj
 **	Resizing changes, based position of input, buttonbar, and output
 **	sections on XmATTACH_POSITION where percentages are used instead
 **	of fixed pixel offsets.  This allows the resizing of the window
 **	to look better.
 **	Added input section message text box, which does not work yet.
 **	Input directory text field functionality changed slightly, will
 **	not erase mistyped diretories, just beeps and does nothing.
 **	
 **	Revision 1.13  93/08/24  15:39:19  secoskyj
 **	Abort button during a conversion works
 **	
 **	Revision 1.12  93/08/23  19:43:08  secoskyj
 **	Iconfy icon added
 **	No "Are you sure you wish to exit?" dialog
 **	Sunken look for input and output sections
 **	
 **	Revision 1.11  93/07/22  15:56:04  secoskyj
 **	Added delete functionality.
 **	Removed bug with checking verboseFlag instead of
 **	autodetValue with displaying the automatic type
 **	detection in the inputTypesList
 **	
 **	Revision 1.10  93/07/22  12:46:21  secoskyj
 **	More space on output status screen
 **	If verbose is off, there is no output status screen
 **	Uses new message dialog box routines to output
 **	features coming dialogs.
 **	
 **	Revision 1.9  93/07/19  14:58:26  secoskyj
 **	Added better function header comments and cleaned 
 **	up several areas of the code.
 **	Changed constrOutFname routine so that it would
 **	construct more meaningful output filenames with
 **	type extentions that it does not recognize.
 **	Added a Delete option to the File menu, the actual
 **	action has not yet been implemented
 **	Rearranged the order that the output option menus are
 **	greyed and selectively ungreyed based on which 
 **	format was selected.
 **	
 **	Revision 1.8  93/07/15  13:28:45  secoskyj
 **	A number of changes: redesigned automatic type detection
 **	area.  Added another file to hold the dialog box 
 **	management functions, imxdlg.c and imxdlg.h.  Added support
 **	for an exit confirmation window and move code to control
 **	output status dialog box to imxdlg.c
 **	
 **	Revision 1.7  93/07/13  15:11:12  secoskyj
 **	Added X cursor when a person moved the cursor into 
 **	the input types list and automatic type detection is
 **	on.  This is going to soon change will a new 
 **	design of the input file types list.
 **	
 **	Revision 1.6  93/07/09  15:30:25  secoskyj
 **	don't use strdup() any more since it is not
 **	supported on DEC.
 **	
 **	Revision 1.5  93/07/07  18:15:39  secoskyj
 **	Output Status dialog scrolled text window resizes instead of
 **	OK button resizing.
 **	Output Status dialog updated everytime text is written to 
 **	the text widget.  This improves the appearance greatly.
 **	
 **	Revision 1.4  93/07/06  14:13:17  secoskyj
 **	Now detectes format of a file which does not have a
 **	matching extention, if possible.
 **	
 **	Revision 1.3  93/07/06  11:03:34  secoskyj
 **	Testing rci ability in new src directory
 **	
 **	Revision 1.2  93/07/05  20:19:35  secoskyj
 **	Added bottom padding
 **	Double click on file, will convert
 **	Changed names to imxconv
 **	
 **	Revision 1.1  93/07/05  19:36:20  secoskyj
 **	Initial revision
 **	
 **	
 **	
 **/

#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <stdio.h>

#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/cursorfont.h>

#include <Xm/Xm.h>
#include <Xm/CascadeB.h>
#include <Xm/MainW.h>
#include <Xm/PushB.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/Form.h>
#include <Xm/Text.h>
#include <Xm/Label.h>
#include <Xm/List.h>
#include <Xm/ToggleB.h>
#include <Xm/FileSB.h>
#include <Xm/MessageB.h>
#include <Xm/PushBG.h>
#include <Xm/TextF.h>
#include <Xm/ToggleBG.h>
#include <Xm/Frame.h>
#include <Xm/CascadeBG.h>

#include "imxconv.h"
#include "im.h"
#include "imtools.h"
#include "imxtools.h"
#include "imxdlg.h"
#include "imxhelp.h"

#define VIS_INPUT_FILES		(12)
#define VIS_INPUT_TYPES		(6)
#define VIS_NUM_COLS		(40)
#define SMALL_OFFSET		(5)
#define MED_OFFSET		(10)
#define INCLUDE_OFFSET		(12)
#define HORIZ_FORM_OFFSET	(15)
#define VERT_FORM_OFFSET	(15)
#define FAT_BUTTON		(10)
#define MAX_DIR_ENTRIES		(256)
#define MAX_DIR_NAME		(256)
#define MAX_NIMFORMATS		(100)
#define MAX_BUF_STR		(256)
#define MAX_FILEEXT_LEN		(128)
#define MULT_FILE_SEL_STR	("<multiple files selected>")
#define AUTODET_STR		("File type(s) detected:")
#define INPUTTYPE_STR		("Select input file type:")
#define BELL_VOLUME		(100)
#define OUTPUT_PARAM_OFFSET	(35)
#define FRAME_THICKNESS		(2)
#define VIS_MESSAGE_ROWS	(5)


#define MENU_CONVERT		(10)
#define MENU_EXIT		(11)
#define MENU_DELETE		(12)
#define MENU_LOGFILE		(20)
#define MENU_VERBOSE		(21)
#define MENU_EXPERT		(22)
#define MENU_HELP_FORMATS	(30)
#define MENU_HELP_PARAM		(31)
#define MENU_HELP_ABOUT		(32)

#define INPUT_BROWSESEL		(0)
#define INPUT_DFLTACTION	(1)
#define INPUT_EXTSEL		(2)
#define INPUT_MULTSEL		(3)
#define INPUT_SINGLESEL		(4)

#define IALPHA_YES	(1)
#define	IALPHA_NO	(2)
#define ICLT_YES	(1)
#define ICLT_NO		(2)
#define ITYPE_INDEX	(1)
#define ITYPE_RGB	(2)
#define	ITYPE_2D	(3)
#define ICHANNEL_1	(1)
#define ICHANNEL_3	(2)
#define ICHANDEPTH_1	(1)
#define ICHANDEPTH_2	(2)
#define ICHANDEPTH_4	(3)
#define ICHANDEPTH_5	(4)
#define ICHANDEPTH_8	(5)
#define ICHANDEPTH_16	(6)
#define ICOMPRESS_NO	(1)
#define ICOMPRESS_RLE	(2)
#define ICOMPRESS_LZW	(3)
#define ICOMPRESS_PB	(4)
#define ICOMPRESS_DCT	(5)
#define IINTERLEAV_NO		(1)
#define IINTERLEAV_LINE		(2)
#define IINTERLEAV_PLANE	(3)

#define ISTOR_1BITINDEX		(1)
#define ISTOR_4BITINDEX		(2)
#define ISTOR_8BITINDEX		(3)
#define ISTOR_16BITINDEX	(4)
#define ISTOR_15BITRGB		(5)
#define ISTOR_24BITRGB		(6)

#define STOR_CLT_NOALPHA	(0)
#define STOR_CLT_ALPHA		(1)
#define STOR_NOCLT_NOALPHA	(2)
#define STOR_NOCLT_ALPHA	(3)


/*
 *  EXTERN GLOBALS:
 *
 *	outputDlg		- output dialog widget
 *
 *	alphasort( )		- routine used to sort directory entries
 *
 */
extern Widget	outputDlg;
extern Widget	outputDlgAbortButton;
extern Boolean	cancelFlag;
extern Widget	helpDlg;
extern Widget	helpOutOptsDlg, helpOutOptsText;
extern char	*helpOutOptsStr;
extern int	alphasort( /* struct dirent **, struct dirent ** */ );


/*
 *  PRIVATE GLOBALS:
 *
 *	*display	-  display used by user interface
 *
 *     	appShell	-  application shell widget
 *
 *	inputDirText	-  text field widget that contains the 
 *			   input directory
 *
 *	outputDirText	-  text field widget that contains the
 *			   output directory
 *
 *	outputFnameText	-  text field widget that contains the
 *			   output filename
 *
 *	inputDirList	-  scrolled list widget which contains
 *			   a list of files in the current directory
 *			   This widget is the main file selection box
 *			   widget
 *
 *	inputTypesList	-  scrolled list widget which hold either
 *			   the list of valid input types or the
 *			   files which automatic type detection has
 *			   been done onn
 *
 *	outputTypesList	-  scrolled list widget which hold the valid
 *			   output file types
 *
 *	inputTypeLabel	-  label used to indictate what information
 *			   is being displayed in the inputTypesList
 *
 *	DirChange	-  flag used to tell if the directory text field
 *			   has been changed.
 *
 *	autodetValue	-  stores the value of the automatic type detection
 *			   toggle button.
 *
 *	outFileExt[]	-  stores the current output filename extention
 *
 *	*compressButtons	-  These are button arrays that contains the 
 *	*channelButtons		   buttons used in the output parameter 
 *	*chanDepthButtons	   option menus (pop-down like menus)
 *	*interleavButtons
 *	*typeButtons
 *	*alphaButtons
 *	*cltButtons
 *
 *	CompressMenu		- These widgets are the options menu widgets
 *	ChannelMenu		  that are used for the output parameter 
 *	ChanDepthMenu		  option menus
 *	InterleavMenu
 *	TypeMenu
 *	AlphaMenu
 *	CLTMenu
 *
 *	CompressVal		-  These variables store the current output
 *	ChannelVal		   parameter option menu values (that is 
 *	ChanDepthVal		   which menu items are currently selected
 *	InterleavVal
 *	TypeVal
 *	AlphaVal
 *	CLTVal
 *
 *	*AlphaOpts[]		- These string arrays hold the labels for the
 *	*CLTOpts[]		  output parameter option menus
 *	*CompressionTypes[]
 *	*Channels[]
 *	*ChanDepth[]
 *	*Interleaving[]
 *	*Types[]
 *
 *	*imageFlagsTable	-  points to the flags table to use for this
 *				   image conversion
 *
 *	*imageDataTable	-  points to the data table used for the current 
 *			   image conversion
 *
 *	questDlg	-  widget used for question dialogs.
 *
 *	busyCursor	-  holds the clock cursor
 *
 *	verboseFlag	-  holds value of verbose menu item.
 *
 *	expertFlag	-  holds value of Standard Mode menu item.
 *
 */

private Display		*display;
private Widget		appShell;
private Widget		inputDirText, outputDirText;
private Widget		outputFnameText;
private Widget		outputExpertOpts, outputStandardOpts;
private Widget		inputDirList;
private Widget		inputTypesList;
private Widget		outputTypesList = NULL;
private Widget		inputTypeLabel;
private Widget		inputMessageText;
private Widget		cltStdLabel, alphaStdLabel;
private Boolean		DirChange = False;
private Boolean		autodetValue = True;
private char		outFileExt[MAX_FILEEXT_LEN];
private Widget		*compressButtons, *channelButtons, *chanDepthButtons;
private Widget		*interleavButtons, *typeButtons;
private Widget		*alphaButtons, *cltButtons;
private Widget		*storageButtons, *storageOptsButtons; 
private Widget		*compressStdButtons; 
private Widget		CompressMenu, ChannelMenu, ChanDepthMenu;
private Widget		InterleavMenu, TypeMenu;
private Widget		AlphaMenu, CLTMenu;
private Widget		StorageMenu, CompressStdMenu;
private int		CompressVal, ChannelVal, ChanDepthVal;
private int		InterleavVal, TypeVal;
private int		AlphaVal, CLTVal;
private int		StorageVal, StorageOptsVal;
private TagTable	*imageFlagsTable;
private TagTable	*imageDataTable;
private Widget		questDlg, delDlg, errorDlg, aboutDlg;
private Cursor		busyCursor;
private Boolean		verboseFlag = True;
private Boolean		expertFlag = True;
private	Widget		outTypeLabel;


private char *AlphaOpts[] = 		{ "Automatic  ",
						"Yes",
						"No" };

private char *CLTOpts[] = 		{ "Automatic  ",
						"Yes",
						"No" };

private char *CompressionTypes[] = 	{ "Automatic  ",
						"None",
						"RLE",
						"LZW",
						"PackBits",
						"DCT" };

private char *Channels[] = 		{ "Automatic  ",
						"1 channel",
						"3 channels" };

private char *ChanDepth[] = 		{ "Automatic  ",
						"1 bit",
						"2 bits",
						"4 bits",
						"5 bits",
						"8 bits",
						"16 bits" };

private char *Interleaving[] = 		{ "Automatic  ",
						"None",
						"Line",
						"Plane" };

private char *Types[] = 		{ "Automatic  ",
						"Index",
						"RGB",
						"2D Geom." };

private char *Storage[] = 		{ "Automatic",
						"1-bit Index",
						"4-bit Index",
						"8-bit Index",
						"16-bit Index",
						"15-bit RGB",
						"24-bit RGB" };

private char *StorageOpts[] = 		{ "CLT, no Alpha",
						"CLT, Alpha",
						"no CLT, no Alpha",
						"no CLT, Alpha" };



/*
 *  FUNCTION
 *	strDup	- emulates strdup().
 *
 *  PARAMETERS
 *	char *str	- string to duplicate
 *
 *  DESCRIPTION
 *	Mallocs memory and copies passed string into malloced memory.
 *	Returns a pointer to the new memory location.
 *
 */
private char
*strDup( str )
	char *str;
{
	char *newstr;

	newstr = (char *) malloc( strlen( str ) + 1 );
	if ( newstr == NULL )
	{
		fprintf( stderr, "Error allocating memory in strDup().\n" );
		exit( 1 );
	}
	strcpy( newstr, str );
	return newstr;
}



/*
 *  FUNCTION
 *	busyPointerOn	- turn on watch pointer cursor
 *
 *  PARAMETERS
 *	Widget w	- widget to turn watch cursor on for
 *
 */
private void
busyPointerOn( w )
	Widget w;
{
	Window	widgetWindow;

	widgetWindow = XtWindow( w );

	if ( widgetWindow != NULL )
		XDefineCursor( display, widgetWindow, busyCursor );
}




/*
 *  FUNCTION
 *	busyPointerOff	- turn off watch pointer cursor
 *
 *  PARAMETERS
 *	Widget w	- widget to turn watch cursor off for
 *
 */
private void
busyPointerOff( w )
	Widget w;
{
	Window	widgetWindow;

	widgetWindow = XtWindow( w );

	if ( widgetWindow != NULL )
		XUndefineCursor( display, widgetWindow );
}




/*
 *  FUNCTION
 *	buildFlagsTable	- place output options into a flag table
 *
 *  DESCRIPTION
 *	Constructs a flags table based on the current vales that are 
 *	set in the output parameter option menus.
 *	Reads global variables in order to find out which options that
 *	the user may have selected.
 *
 */
private TagTable*
buildFlagsTable( )
{
	TagTable	*flagsTable;
	int		i;
	int		itmp;
	char		*tmp;
	int		(*handler)( );

	if ( ( flagsTable = TagTableAlloc( ) ) == TAGTABLENULL )
	{
		TagPError( ImToolsProgram );
		exit( 1 );
	}

	TagTableAppend( flagsTable, 
		TagEntryAlloc( "program name", POINTER, &ImToolsProgram ) );

	handler = ImXToolsErrorHandler;
	TagTableAppend( flagsTable,
		TagEntryAlloc( "error handler", POINTER, &handler ) );

	handler = ImXToolsInfoHandler;
	TagTableAppend( flagsTable,
		TagEntryAlloc( "info handler", POINTER, &handler ) );


	switch ( TypeVal )
	{
	case ITYPE_INDEX:
		itmp = IMTYPEINDEX;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image type request", INT, &itmp ) );
		break;

	case ITYPE_RGB:
		itmp = IMTYPERGB;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image type request", INT, &itmp ) );
		break;
	}


	switch ( CLTVal )
	{
	case ICLT_YES:
		itmp = IMCLTYES;
		TagTableAppend( flagsTable, 
			TagEntryAlloc( "image clt request", INT, &itmp ) );
		break;

	case ICLT_NO:
		itmp = IMCLTNO;
		TagTableAppend( flagsTable, 
			TagEntryAlloc( "image clt request", INT, &itmp ) );
		break;
	}


	switch ( AlphaVal )
	{
	case ICLT_YES:
		itmp = IMALPHAYES;
		TagTableAppend( flagsTable, 
			TagEntryAlloc( "image alpha request", INT, &itmp ) );
		break;

	case ICLT_NO:
		itmp = IMCLTNO;
		TagTableAppend( flagsTable, 
			TagEntryAlloc( "image alpha request", INT, &itmp ) );
		break;
	}


	switch ( ChanDepthVal )
	{
	case ICHANDEPTH_1:
		itmp = 1;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_2:
		itmp = 2;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_4:
		itmp = 4;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_5:
		itmp = 5;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_8:
		itmp = 8;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;

	case ICHANDEPTH_16:
		itmp = 16;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel depth request",
				INT, &itmp ) );
		break;
	}


	switch ( ChannelVal )
	{
	case ICHANNEL_1:
		itmp = 1;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel number request", 
				INT, &itmp ) );
		break;

	case ICHANNEL_3:
		itmp = 3;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image channel number request", 
				INT, &itmp ) );
		break;
	}



	switch ( InterleavVal )
	{
	case IINTERLEAV_NO:
		itmp = IMINTERNONE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image interleave request",
				INT, &itmp ) );
		break;

	case IINTERLEAV_LINE:
		itmp = IMINTERLINE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image interleave request",
				INT, &itmp ) );
		break;

	case IINTERLEAV_PLANE:
		itmp = IMINTERPLANE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image interleave request",
				INT, &itmp ) );
		break;
	}


	switch ( CompressVal )
	{
	case ICOMPRESS_NO:
		itmp = IMCOMPNONE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;

	case ICOMPRESS_RLE:
		itmp = IMCOMPRLE;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;

	case ICOMPRESS_LZW:
		itmp = IMCOMPLZW;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;

	case ICOMPRESS_PB:
		itmp = IMCOMPPB;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;

	case ICOMPRESS_DCT:
		itmp = IMCOMPDCT;
		TagTableAppend( flagsTable,
			TagEntryAlloc( "image compression request", 
				INT, &itmp ) );
		break;
	}



	return ( flagsTable );
}



/*
 *  FUNCTION
 *	buildDataTable	- allocate data table for read and write routines
 *  
 *  DESCRIPTION
 *	Allocates a data table used in image conversions and returns 
 * 	a pointer to the data table.
 *
 */
private TagTable *
buildDataTable()
{
	TagTable *dataTable;

	if ( ( dataTable = TagTableAlloc() ) == TAGTABLENULL )
	{
		TagPError( ImToolsProgram );
		exit( 1 );
	}

	return ( dataTable );
}
	
	

/*
 *  FUNCTION
 *	listFillDir	- fill a list with the current directory
 *
 *  PARAMETERS
 *	Widget listW	- list widget to fill with the current directory
 *
 *  DESCRIPTION
 *	The function proceeds in two parts, the first read and alphabetize
 *	the filenames in a dirctory using scandir( ) and then place these
 *	filenames into a list widget.  We cook up the filenames a little bit
 *	by catting a '/' to the end of directory names and a '*' to the
 *	end of executable files.
 *
 *  NOTES
 *	Since scandir( ) is used, it should not be hard to create a selection
 *	function for scandir so that regular expression file filters could
 *	be implemented in the interface.
 *
 */
private void
listFillDir( listW )
	Widget listW;
{
	DIR 		*dirp;
	struct dirent 	**dirents;
	XmString	filename[MAX_DIR_ENTRIES];
	char		dirName[MAX_DIR_NAME];
	Arg		al[10];
	int		ac;
	int		i, numEntries;
	struct stat	fileStats;


	numEntries = scandir( ".", &dirents, NULL, alphasort );
	if ( numEntries < 0 )
	{
		fprintf( stderr, "Difficulty with scandir command.\n" );
		exit( 1 );
	}

	/*
	 *  Place each directory entry name into an XmString array
	 */

	for ( i = 0; i < numEntries; i++ )
	{
		strcpy( dirName, dirents[i]->d_name );

		stat( dirName, &fileStats );

		/*
		 *  If the item is a directory add a / to the end of the name,
		 *  if the item is executable, add a * to the end of the name.
		 */

		if ( S_IFDIR & fileStats.st_mode )
		{
			strcat( dirName, "/" );
		}
		else
		{
			if ( ( S_IXUSR | S_IXGRP | S_IXOTH ) &
				fileStats.st_mode )
			{
				strcat( dirName, "*" );
			}
		}

		filename[i] = XmStringCreateLtoR( dirName,
				XmSTRING_DEFAULT_CHARSET );
	}

	ac = 0;
	XtSetArg( al[ac], XmNitems, filename ); ac++;
	XtSetArg( al[ac], XmNitemCount, i ); ac++;
	XtSetValues( listW, al, ac );

	/*
	 *  Select first item, but do not call selection callback in
	 *  the process
	 */

	XmListSelectPos( listW, 1, False );

	for ( i = i - 1 ; i >= 0; i-- )
	{
		XmStringFree( filename[i] );
		free( dirents[i] );
	}

	free( dirents );
}


/*
 *  FUNCTION
 *	textFillCurDir	- fill a text field with the current directory
 *
 *  PARAMETERS
 *	Widget textW	- text field widget to fill with the current directory
 *
 *  DESCRIPTION
 *	Place the text for the working directory into a text field.  Make
 *	sure that the end of the text in the text field is visible.
 *
 */
private void
textFillCurDir( textW )
	Widget textW;
{
	char 		pathname[MAXPATHLEN];
	int		posn;

	/*
	 *  Get the current working directory and insert this text into
	 *  the passed text widget
	 */

	getwd( pathname );

	XmTextFieldSetString( textW, pathname );

	/*
	 *  Make sure the the end of the string in the text widget is
	 *  visible
	 */

	posn = XmTextFieldGetLastPosition( textW );
	XmTextFieldShowPosition( textW, posn );
	XmTextFieldSetInsertionPosition( textW, posn );
}



/*
 *  FUNCTION
 *	freeDataTable	- free a tag table of image data.
 *
 *  PARAMETERS
 *	TagTable dataTable	- data table to clear out
 *
 *  DESCRIPTION
 *	Free if exists any vfb, clt, name, or hotspot in a data table.
 *	This routine was originally copied from imstoryboard.
 *
 */
private void
freeDataTable( dataTable )
	TagTable **dataTable;
{
	int 		i;
	TagEntry 	*dataEntry;	/* used to obtain correct entries   */
	ImVfb 		*vfb;		/* variables used to clear out data */
	ImClt 		*clt;
	char		*name;
	ImHotSpotPtr	*hotspot;
	
	i = TagTableQNEntry( *dataTable, "image vfb" ) - 1;

	for( ; i >= 0; i-- )
	{
		dataEntry = TagTableQDirect( *dataTable, "image vfb", i );
		TagEntryQValue( dataEntry, &vfb );
		ImVfbFree( vfb );
	}
	
	i = TagTableQNEntry( *dataTable, "image clt" ) - 1;

	for( ; i >= 0; i-- )
	{
		dataEntry = TagTableQDirect( *dataTable, "image clt", i );
		TagEntryQValue( dataEntry, &clt );
		ImCltFree( clt );
	}

	i = TagTableQNEntry( *dataTable, "image name" ) - 1;

	for( ; i >= 0; i-- )
	{
		dataEntry = TagTableQDirect( *dataTable, "image name", i );
		TagEntryQValue( dataEntry, &name );
		free( name );
	}

	i = TagTableQNEntry( *dataTable, "image hot spot" ) - 1;

	for( ; i >= 0; i-- )
	{
		dataEntry = TagTableQDirect( *dataTable, "image hot spot", i );
		TagEntryQValue( dataEntry, &hotspot );
		free( hotspot );
	}


	TagTableFree( *dataTable );
}



/*
 *  FUNCTION
 *	inTypeExt	- return extention of input type selected
 *
 *  DESCRIPTION
 *	This routine returns the extention of the file based on what
 *	type is selected in the input type list.
 *
 *  NOTES
 *	This routine mallocs memory for teh return value.  This memory
 *	must be freed by the programmer.
 *
 */
private char *
inTypeExt( )
{
	char		*inFormat, *inExt, *firstSpace;
	Arg		al[5];
	int		ac;
	XmStringTable	*selXItem;

	ac = 0;
	XtSetArg( al[ac], XmNselectedItems, &selXItem ); ac++;
	XtGetValues( inputTypesList, al, ac );

	XmStringGetLtoR( (XmString) selXItem[0],
		XmSTRING_DEFAULT_CHARSET, &inFormat );

	firstSpace = NULL;
	firstSpace = strchr( inFormat, ' ' );
	if ( firstSpace == NULL )
	{
		fprintf( stderr, "Bad input image type string.\n" );
		exit( 1 );
	}

	firstSpace[0] = '\0';

	inExt = (char *) malloc( strlen( inFormat ) + 1 );

	strcpy( inExt, inFormat );

	XtFree( inFormat );

	return( inExt );
}


/*
 *  FUNCTION
 *	getFileExt	- returns string after last period in filename
 *			  (returns a pointer inside of passed string).
 *
 *  PARAMETERS
 *	char *filename	- filename we are going to get the extention of
 *
 *  DESCRIPTION
 *	First strips off a trailing '/' or '*' from the filename.
 *	Then searches backwards until it finds a '.' and returns 
 *	a pointer to this position plus one.
 *
 *  NOTES
 *	The return value of this function should not be freed since
 *	the routine is returning a pointer inside of the string that
 *	is passed to the function.
 *
 */
private char *
getFileExt( filename )
	char *filename;
{
	int 	len;
	char	*dotPos;
	char	*fileExt;

	fileExt = NULL;
	len = strlen( filename );

	if ( filename[len - 1] == '/' || filename[len - 1] == '*' )
		filename[len - 1] = '\0';

	if ( filename[0] != '.' || filename[1] == '\0' )
	{
		dotPos = strrchr( filename, '.' );

		if ( dotPos != 0 )
			fileExt = dotPos + 1;
	}

	return( fileExt );
}

	
/*
 *  FUNCTION
 *	constrOutFname	- add currently selected image type extention
 *			  to filename that is passed in.
 *
 *  PARAMETERS
 *	char *filename	- filename to concatenate the output type onto
 *
 *  DESCRIPTION
 *	Looks for the first '.' from the right.  Will chop off everything
 *	after the period, including the period, and will attach the output
 *	extention onto the end of the remaining string.  The reason we
 *	chop off the period is to mark the end of the string.  They may
 *	not be anything after the period, so we cannot start chopping
 *	after the period.
 *
 *  NOTES
 *	The return value of this routine was malloced up and should 
 *	be freed when the user is finished with it.
 *
 */
private char *
constrOutFname( filename )
	char *filename;
{
	Boolean		foundExt;
	char		*dotPos, *fileExt;
	char		*outName;
	char		*tmpFname;
	ImFileFormat 	**ppFmt;	
	char		**pNames;

	tmpFname = strDup( filename );

	/*
	 *  Check to see if we recognize the input file extention.
	 *  If we do not, then do not replace the input file extention with
	 *  the output file extention.  Otherwise replace the input file
	 *  extention with the output file extention.
	 */

	foundExt = False;
	fileExt = getFileExt( tmpFname );

	if ( fileExt != NULL )
	{
		for ( ppFmt = ImFileFormats; *ppFmt && foundExt == False;
				ppFmt++ )
		{
			pNames = &(*ppFmt)->format_names[0];
			for ( ; *pNames; pNames++ )
			{
				if ( strcmp( *pNames, fileExt ) == 0 )
				{
					foundExt = True;
					break;
				}
			}
			if ( *pNames )
				break;
		}
	}

	/*
	 *  If we recognize the file extention, then remove the '.' from the
	 *  filename (located just before the file extention.
	 *  We should be ok in doing this (i.e. no seg faults) since foundExt
	 *  will not be True if there was no file extention present
	 *  on the file.  If the file extention is present, then we are
	 *  guaranteed that there will be a '.'.
	 */

	if ( foundExt == True )
		*( fileExt - 1 ) = '\0';

	outName = (char *) malloc( strlen( tmpFname ) + 1 + 
			strlen( outFileExt ) + 1 );
	
	if ( outName == NULL )
	{
		fprintf( stderr, "Not able to allocate memory for string.\n" );
		exit( 1 );
	}

	strcpy( outName, tmpFname );
	strcat( outName, "." );
	strcat( outName, outFileExt );

	free( tmpFname );
	return( outName );
}



/*
 *  FUNCTION
 *	listFillSelFiles	- Place all of the selected files from
 *				  srcList into dstList with their image
 *				  file type.
 *
 *  PARAMETERS
 *	Widget dstList		- destination list for the operation
 *	Widget srcList		- source list, the list to get the filenames
 *				  from.
 *
 *  DESCRIPTION
 *	This routine gets all the selected filenames from the srcList and
 *	determines the image format for each of them.  It then formats
 *	a string and places these strings into the dstList.
 *	The file type extention will be used unless there is an error.  In
 *	the case of an error, the extention will be:
 *		DIR	- a directory
 *		ERR	- could not open file for reading
 *		UNK	- could not determine file format with
 *			  ImFileQFFormat( )
 *
 */
private void
listFillSelFiles( dstList, srcList )
	Widget dstList;
	Widget srcList;
{
	Arg		al[10];
	int		ac;
	int		nItems, actualItems, i, len;
	XmString	insXItems[MAX_DIR_ENTRIES];
	XmStringTable	*selXItems;
	char		*selItem;
	char		*inType;
	char		insStr[128];
	FILE		*fp;
	struct stat	fileStats;

	ac = 0;
	XtSetArg( al[ac], XmNselectedItemCount, &nItems ); ac++;
	XtSetArg( al[ac], XmNselectedItems, &selXItems ); ac++;
	XtGetValues( srcList, al, ac ); 

	actualItems = 0;
	for ( i = 0; i < nItems; i++ )
	{
		XmStringGetLtoR( (XmString) selXItems[i],
			XmSTRING_DEFAULT_CHARSET, &selItem );

		len = strlen( selItem );

		if ( selItem[len - 1] == '/' || selItem[len - 1] == '*' )
			selItem[len - 1] = '\0';

		/*
		 *  Open the file and attempt to find out the image type
		 *  of the file.
		 */

		fp = NULL;
		stat( selItem, &fileStats );

		if ( S_IFDIR & fileStats.st_mode )
		{
			inType = strDup( "DIR" );
		}
		else if ( (fp = fopen( selItem, "r" )) == NULL )
		{
			inType = strDup( "Error" );
		}
		else if ( ( inType = ImFileQFFormat(fp, selItem) ) == NULL )
		{
			inType = strDup( "Unknown" );
		}

		if ( fp != NULL )
			fclose( fp );

		/*
		 *  Don't display directories in list
		 */

		if ( strcmp( inType, "DIR" ) )
		{
			sprintf( insStr, "%-9s %s", inType, selItem );
			insXItems[actualItems] = XmStringCreateLtoR( insStr,
					XmSTRING_DEFAULT_CHARSET );
			actualItems++;
		}

		XtFree( selItem );
		if ( !strcmp( inType, "DIR" ) )
			free( inType );
		if ( !strcmp( inType, "Error" ) )
			free( inType );
		if ( !strcmp( inType, "Unknown" ) )
			free( inType );
	}

	/*
	 *  Nasty hack to get the list to redraw when no items are going 
	 *  to be put in it.  Draw the list with one item to make sure
	 *  that the list is drawn correctly, then redraw the list with
	 *  no items like it should be drawn.
	 */

	if ( actualItems == 0 )
	{
		insXItems[actualItems] = XmStringCreateLtoR( "",
						XmSTRING_DEFAULT_CHARSET );
		actualItems++;

		ac = 0;
		XtSetArg( al[ac], XmNitems, insXItems ); ac++;
		XtSetArg( al[ac], XmNitemCount, actualItems ); ac++;
		XtSetValues( dstList, al, ac );

		actualItems--;
	}


	ac = 0;
	XtSetArg( al[ac], XmNitems, insXItems ); ac++;
	XtSetArg( al[ac], XmNitemCount, actualItems ); ac++;
	XtSetValues( dstList, al, ac );

	/*
	 *  Select first item, but do not call selection callback in
	 *  the process
	 */

	XmListSelectPos( dstList, 1, False );

	for ( i = 0 ; i < actualItems; i++ )
	{
		XmStringFree( insXItems[i] );
	}
}




/*
 *  Modified code from the O'Reilly book on Motif Programming (vol. 6)
 *
 */
Boolean checkForInterrupt( )
{
	Display *dpy = XtDisplay( appShell );
	Window win = XtWindow( outputDlgAbortButton );
	XEvent event;

	/* Make sure all our requests get to the server */
	XFlush( dpy );

	/* Let motif process all pending exposure events for us. */
	XmUpdateDisplay( outputDlg );

	/* Check the event loop for events in the dialog ("Stop"?) */
	while ( XCheckMaskEvent( dpy,
		ButtonPressMask | ButtonReleaseMask | ButtonMotionMask |
		PointerMotionMask | KeyPressMask | KeyReleaseMask,
		&event ) )
	{
		/* got an "interesting" event. */
		if (event.xany.window == win)
		{
			XtDispatchEvent(&event); /* it's in our dialog.. */
		}
		else /* uninteresting event--throw it away and sound bell */
			XBell(dpy, 50);
	}
	return cancelFlag;
}




/*
 *  FUNCTION
 *	convertImg( )	- function called to initiate a conversion
 *
 *  DESCRIPTION
 *	When called starts a conversion of the selected input images.
 *	1) Gets all the selected input files
 *	2) Gets output path
 *	3) Clears and manage output status dialog
 *	4) Turn busy cursor on
 *	5) Step through each filename, converting with libim routines
 *	6) Deselect filenames and update file selection box
 *	7) Turn busy cursor off
 *
 */
private void
convertImg( )
{
	Arg		al[10];
	int		ac;
	int		nItems, i, len;
	char		*curItem;
	XmStringTable	*selXItems;
	char		*inFormat, *outFilename, *outPath, *outFullName;
	char		workingDir[MAXPATHLEN];
	Boolean		sameOutputDir;
	int		res;
	char		buf[MAX_BUF_STR];
	XEvent		event;

	/*
	 *  Initialize cancelFlag
	 */
	cancelFlag = False;

	ac = 0;
	XtSetArg( al[ac], XmNselectedItemCount, &nItems ); ac++;
	XtSetArg( al[ac], XmNselectedItems, &selXItems ); ac++;

	XtGetValues( inputDirList, al, ac ); 

	getwd( workingDir );
	outPath = XmTextFieldGetString( outputDirText );

	sameOutputDir = FALSE;
	if ( !strcmp( workingDir, outPath ) )
		sameOutputDir = TRUE;

	outputDlgClr( );
	outputDlgOKButtonCtrl( False );
	outputDlgManage( verboseFlag );
	outputDlgConcat( "Conversion Status:\n" );

	busyPointerOn( appShell );

	ImToolsVerbose = 1;
	imageFlagsTable = buildFlagsTable( );
	for ( i = 0; i < nItems; i++ )
	{
		imageDataTable = buildDataTable( );

		XmStringGetLtoR( (XmString) selXItems[i],
			XmSTRING_DEFAULT_CHARSET, &curItem );

		XmListSetItem( inputDirList, (XmString) selXItems[i] );

		len = strlen( curItem );

		if ( curItem[len - 1] == '/' )
		{
			outputDlgConcat( "Skipping directory\n" );
			continue;
		}

		if ( curItem[len - 1] == '*' )
			curItem[len - 1] = '\0';

		if ( autodetValue == True )
			inFormat = strDup( "\0" );
		else
			inFormat = inTypeExt( );

		sprintf( buf, "(%d/%d)", i, nItems );
		outputDlgPercentSet( buf );
		outputDlgStatusSet( curItem );

		if ( checkForInterrupt( ) )
			break;

		res = ImXToolsFileRead( curItem, inFormat, imageFlagsTable,
			imageDataTable );

		if ( cancelFlag == True )
		{
			fprintf( stderr, "cancel button pressed\n" );
			cancelFlag = False;
		}

		if ( checkForInterrupt( ) )
			break;

		if ( res == 0 )
		{
			/*
			 *  If performing a single file conversion, then
			 *  get filename from outputFnameText widget
			 *  since the user may have typed in a different
			 *  filename than the one suggested by 
			 *  constrOutFname( ).
			 */

			if ( nItems == 1 )
			{
				outFilename = XmTextFieldGetString(
							outputFnameText );
			}
			else
			{
				outFilename = constrOutFname( strDup(curItem) );
			}

			/*
			 *  Cat path and filename together
			 *  May not be necessary to cat path onto filename
			 *  (first case of if).
			 */

			if ( sameOutputDir )
			{
				outFullName = (char *) malloc( 
						strlen( outFilename ) + 1 );
				
				strcpy( outFullName, outFilename );
			}
			else
			{
				outFullName = (char *) malloc(
						strlen( outPath ) + 1 +
						strlen( outFilename ) + 1 );
				
				strcpy( outFullName, outPath );
				strcat( outFullName, "/" );
				strcat( outFullName, outFilename );
			}

			res = ImXToolsFileWrite( outFullName, outFileExt,
				imageFlagsTable, imageDataTable );

			free( outFullName );
			free( outFilename );
		}

		free( curItem );
		freeDataTable( &imageDataTable );
		outputDlgConcat( "\n" );
	}

	/*
	 *  Set the percent string to 100% 
	 */

	sprintf( buf, "(%d/%d)", i, nItems );
	outputDlgPercentSet( buf );
	outputDlgStatusSet( "" );

	XmListDeselectAllItems( inputDirList );
	listFillDir( inputDirList );
	XmTextFieldSetString( outputFnameText, "" );

	if ( autodetValue == True )
		listFillSelFiles( inputTypesList, inputDirList );

	if ( cancelFlag == True )
		outputDlgConcat( "Conversion Aborted.\n" );
	else
		outputDlgConcat( "Conversion Done.\n" );

	outputDlgOKButtonCtrl( True );
	XBell( display, BELL_VOLUME );

	busyPointerOff( appShell );

	XtFree( outPath );

	return;
}



/*
 *  FUNCTION
 *	deleteCB( )	- function called to initiate delete images
 *
 *  DESCRIPTION
 *
 */
private int
deleteCB( w, client_data, call_data )
	Widget 	w;
	caddr_t	client_data;
	caddr_t	call_data;
{
	Arg		al[10];
	int		ac;
	int		nItems, i, len;
	char		*curItem;
	XmStringTable	*selXItems;

	ac = 0;
	XtSetArg( al[ac], XmNselectedItemCount, &nItems ); ac++;
	XtSetArg( al[ac], XmNselectedItems, &selXItems ); ac++;
	XtGetValues( inputDirList, al, ac ); 

	busyPointerOn( appShell );

	for ( i = 0; i < nItems; i++ )
	{
		XmStringGetLtoR( (XmString) selXItems[i],
			XmSTRING_DEFAULT_CHARSET, &curItem );

		XmListSetItem( inputDirList, (XmString) selXItems[i] );
		XmUpdateDisplay( inputDirList );

		len = strlen( curItem );

		if ( curItem[len - 1] == '/' )
		{
			continue;
		}

		if ( curItem[len - 1] == '*' )
			curItem[len - 1] = '\0';

		unlink( curItem );
		free( curItem );
	}

	XmListDeselectAllItems( inputDirList );
	listFillDir( inputDirList );
	XmTextFieldSetString( outputFnameText, "" );

	if ( autodetValue == True )
		listFillSelFiles( inputTypesList, inputDirList );

	busyPointerOff( appShell );

	return;
}


private void
aboutCB( )
{
	manageImXDlg( aboutDlg, "About ImXConv", "Beta Version of ImXConv\nE-mail all comments and other suggestions\nto secoskyj@sdsc.edu.", NULL, NULL );
}



private void
ManageExpertMode( mode )
	Boolean mode;
{
	/*
	 *  These lines should help to eliminate flicker
	 *  Actually they also make sure that the outputParamForm
	 *  resizes correctly.
	 */

	if ( outTypeLabel != NULL )
	{
		XtUnmanageChild( outTypeLabel );
	}

	if ( mode == True )
	{
		XtManageChild( outputExpertOpts );
		XtUnmanageChild( outputStandardOpts );
	}
	else
	{
		XtManageChild( outputStandardOpts );
		XtUnmanageChild( outputExpertOpts );
	}

	/*
	 *  These lines should help to eliminate flicker
	 *  Actually they also make sure that the outputParamForm
	 *  resizes correctly.
	 */

	if ( outTypeLabel != NULL )
	{
		XtManageChild( outTypeLabel );
	}
}



/*
 *  FUNCTION
 *	MenuCB 	- menu callback handler
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Large case statement to figure out which menu button was pressed.
 *	Take an action according to the value passed in call_data.
 *
 */
private int
MenuCB( w, client_data, call_data )
	Widget 	w;
	caddr_t	client_data;
	caddr_t	call_data;
{
	switch ( (int) client_data )
	{
	case MENU_EXIT:
		free( compressButtons );
		free( channelButtons );
		free( chanDepthButtons );
		free( interleavButtons );
		free( typeButtons );

		exit( 0 );
		break;

	case MENU_DELETE:
		XBell( display, BELL_VOLUME );
		manageImXDlg( delDlg, "Delete Files", "Are you sure you wish\nto delete these file(s)?", deleteCB, NULL );
		break;

	case MENU_CONVERT:
		convertImg( );
		break;

	case MENU_LOGFILE:
		manageImXDlg( errorDlg, "Log File",
			"Logging coming soon!", NULL, NULL );
		break;

	case MENU_VERBOSE:
		verboseFlag = XmToggleButtonGetState( w );
		break;

	case MENU_EXPERT:
		expertFlag = XmToggleButtonGetState( w );
		ManageExpertMode( expertFlag );
		break;

	case MENU_HELP_FORMATS:
		helpDlgManage( NULL );
		break;

	case MENU_HELP_PARAM:
		XtManageChild( helpOutOptsDlg );
		break;

	case MENU_HELP_ABOUT:
		aboutCB( );
		break;

	default:
		printf( "%s: unknown menu callback.\n",
			ImToolsProgram );
		break;
	}
}



private int
typeDblCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	XmListCallbackStruct	*cb;
	char			*helpType, *firstSpace;

	cb = (XmListCallbackStruct *) call_data;

	XmStringGetLtoR( cb->item, XmSTRING_DEFAULT_CHARSET,
		&helpType );

	firstSpace = NULL;
	firstSpace = strchr( helpType, ' ' );
	if ( firstSpace == NULL )
	{	
		fprintf( stderr, "Bad help image type string.\n" );
		exit( 1 );
	}

	firstSpace[0] = '\0';
	
	helpDlgManage( helpType );

	return ( 1 );
}


/*
 *  FUNCTION
 *	inFileDblCB	- how to handle an input file selection
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	This callback handles a double click selection in the input file
 *	selection box.  Check out filename and based on certain instances
 *	determine what should happen in the interface.
 *
 */
private int
inFileDblCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	XmListCallbackStruct	*cb;
	XmString		fileName;
	char			*charFname;
	char			*homeDir;
	int			i, len, updateDir;
	DIR			*dirp;
	struct dirent		*dirent;
	struct stat		fileStats;

	updateDir = 0;
	cb = (XmListCallbackStruct *) call_data;
	
	/*
	 *  Get the filename char * that was selected
	 */

	fileName = (XmString)cb->item;
	XmStringGetLtoR( fileName, XmSTRING_DEFAULT_CHARSET, &charFname );
	len = strlen( charFname );

	/*
	 *  Remove / or * characters from end of filename 
	 */

	if ( charFname[len - 1] == '/' || charFname[len - 1] == '*' )
		charFname[len - 1] = '\0';


	/*
	 *  Check out what the filename is that the user double clicked on.
	 *  If it is a directory, read the new directory into the list
	 *  	box.
	 *  If it is a file, perform a conversion
	 *  If the file cannot be opened, update the directory listing in
	 *  	in the list box
	 *  If the directory no longer exists, attempt to return to the user's
	 *  	HOME directory.  If this cannot be done return to the root
	 *  	directory.
	 */

	dirp = opendir( "." );

	/*
	 *  Current directory no longer exists, handle error elegantly
	 *  In this case, return to the users home directory.  This should
	 *  be ok since the $HOME environment variable is set by login,
	 *  not by the user's shell.
	 *
	 *  Just in case we will check to make sure that $HOME was actuall
	 *  received (gotten) from the environment, else we will cd to root.
	 */

	if ( dirp == NULL )
	{
		homeDir = getenv( "HOME" );

		if ( homeDir == NULL )
			chdir( "/" );
		else
			chdir( homeDir );

		listFillDir( w );
		textFillCurDir( inputDirText );
		textFillCurDir( outputDirText );
		closedir( dirp );
		return;
	}

	/*
	 *  Make sure thet the item selected is still in the directory
	 */

	dirent = readdir( dirp );
	while ( dirent != NULL && strcmp( charFname, dirent->d_name ) )
	{
		dirent = readdir( dirp );
	}

	/*
	 *  If the item is not in the directory, update the directory list.
	 */

	if ( dirent == NULL )
	{
		listFillDir( w );
		textFillCurDir( inputDirText );
		textFillCurDir( outputDirText );
		closedir( dirp );
		return;
	};


	/*
	 *  Otherwise, if the selected item is a directory, change directories
	 *  to the selected directory
	 */

	stat( dirent->d_name, &fileStats );
	if ( S_IFDIR & fileStats.st_mode )
	{
		chdir( dirent->d_name );

		listFillDir( w );
		textFillCurDir( inputDirText );
		textFillCurDir( outputDirText );
	}


	/*
	 *  If a file start to convert the file.
	 */
	if ( S_IFREG & fileStats.st_mode )
		convertImg( );


	closedir( dirp );
	XtFree( charFname );
}



/*
 *  FUNCTION
 *	inFileExtCB	- called when an extended selection of items occurs
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	When a user selects a single file or multiple files this callback
 *	is called.  There are two cases for selection, if one item only
 *	was selected, or if several items were selected.  For each 
 *	case we need to get something to fill in the output filename text
 *	field with, so basically the routine is getting a good string 
 *	to place there.  In the case of a single filename selection, it
 *	constructs a good filename and places this there, in the case where
 *	multiple files are selected, the field is set to a string which
 *	indictates that multiple file are selected.
 *
 */
private int
inFileExtCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	XmListCallbackStruct	*cb;
	Arg			al[10];
	int			ac;
	int 			nItems, len;
	char			*selItem;
	char			*outName, *outExt;
	ImFileFormat 		**ppFmt;	
	ImFileFormat		*pFmt;
	char			**pNames;
	char			selStr[MAX_BUF_STR];
	XmString		selXStr;

	cb = (XmListCallbackStruct *) call_data;
	nItems = cb->selected_item_count;

	if ( nItems == 1 )
	{
		/*
		 *  Get an ASCII representation of the selected filename
		 *  and create an output filename if the selected file
		 *  is not a directory (has a '/' character at end of 
		 *  name).
		 */

		XmStringGetLtoR( cb->selected_items[0],
			XmSTRING_DEFAULT_CHARSET, &selItem );
		
		len = strlen( selItem );

		switch( selItem[len - 1] )
		{
		case '/':
			XtFree( selItem );
			XmTextFieldSetString( outputFnameText, "" );
			XtSetSensitive( outputFnameText, False );
			if ( autodetValue == True )
			{
				listFillSelFiles( inputTypesList,
					inputDirList );
			}
			return;
			break;

		case '*':
			selItem[len - 1] = '\0';
			break;

		default:
			break;
		}			

		outName = constrOutFname( selItem );

		/*
		 *  Set the output filename to the constructed output
		 *  filename and make sure that the end of the filename
		 *  string can be seen in the output filename text field.
		 */

		XmTextFieldSetString( outputFnameText, outName );
		XtSetSensitive( outputFnameText, True );
		
		len = XmTextFieldGetLastPosition( outputFnameText );
		XmTextFieldShowPosition( outputFnameText, len );
		XmTextFieldSetInsertionPosition( outputFnameText, len );

		XtFree( selItem );
		free( outName );
	}
	else
	{
		/*
		 *  Multiple files selected.  Set output filename string so
		 *  that user knows that several output filenames were
		 *  selected.
		 */

		XmTextFieldSetString( outputFnameText, MULT_FILE_SEL_STR );
		XtSetSensitive( outputFnameText, False );
	}

	/*
	 *  If we are autodetecting the file types then update the
	 *  automatic type detection list.
	 */

	if ( autodetValue == True )
		listFillSelFiles( inputTypesList, inputDirList );
}




/*
 *  FUNCTION
 *	listFillImForm	- put imtool formats into a list box.
 *
 *  PARAMETERS
 *	Widget 		listW		- list widget to put the image type
 *					  into.
 *	InFileFormat 	**ppFmt		- pointer to the current format 
 *					  which is being inserted into the
 *					  list.
 *	Boolean 	inputFormats	- if this value is True, then
 *					  only list values which have 
 *					  input capability.  If this value
 *					  is False, only list types which
 *					  have output capability.
 *
 *  DESCRIPTION
 *	Fills the passed list with a string that gives textural information
 *	about an image type.  This information is in the format:
 *	"FORMAT    INFORMATION_STRING."
 */
public void
listFillImForm( listW, ppFmt, inputFormats )
	Widget 		listW;
	ImFileFormat 	**ppFmt;
	Boolean		inputFormats;
{
	ImFileFormat	*pFmt;
	char 		imTypeDescr[MAX_BUF_STR];
	Arg		al[10];
	int		ac, i;
	XmString	typeDescrip[MAX_NIMFORMATS];

	/*
	 *  Get and convert image format strings into XmStrings and place
	 *  them into an XmString array.
	 */

	i = 0;
	for ( ppFmt = ImFileFormats; *ppFmt; ppFmt++ )
	{
		pFmt = *ppFmt;


		/*
		 *  Check to make sure that the format supports reading
		 *  or writing in order to determine if it should be 
		 *  included in the list box of formats.
		 */
		if ( inputFormats == True )
		{
			if ( pFmt->format_readMap == NULL )
				continue;
		}
		else
		{
			if ( pFmt->format_writeMap == NULL )
				continue;
		}

		sprintf( imTypeDescr, "%-7s %s", pFmt->format_names[0],
				pFmt->format_help );

		typeDescrip[i] = XmStringCreateLtoR( imTypeDescr,
				XmSTRING_DEFAULT_CHARSET );

		i++;
	}

	ac = 0;
	XtSetArg( al[ac], XmNitems, typeDescrip ); ac++;
	XtSetArg( al[ac], XmNitemCount, i ); ac++;
	XtSetValues( listW, al, ac );

	XmListSelectPos( listW, 1, True );

	for ( i = i - 1; i >= 0; i-- )
	{
		XmStringFree( typeDescrip[i] );
	}
}



/*
 *  FUNCTION
 *	typeLabelSet	- set string used in input type label
 *
 *  PARAMETERS
 *	char *str	This is the string to set the type label to
 *
 *  DESCRIPTION
 *	This routine set the label above the input types list (inputTypesList)
 *	to the value specified in str.  This routine is used to help label
 *	the information which is listed in the input types list.
 *
 */
private void
typeLabelSet( str )
	char *str;
{
	Arg		al[5];
	int		ac;
	XmString	labelStr;

	labelStr = XmStringCreateLtoR( str, XmSTRING_DEFAULT_CHARSET );

	ac = 0;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetValues( inputTypeLabel, al, ac );

	XmStringFree( labelStr );
}



/*
 *  FUNCTION
 *	dirChangeCB	- notes if a change of directory occured.
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	If the user changes the input directory text field, we detect this
 *	and will update the directory listing when the text field either
 *	loses focus or the user presses <Return>.
 *
 */
private int
dirChangeCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	DirChange = True;
}



/*
 *  FUNCTION
 *	dirUpdateCB	- update listbox with current directory if changed.
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	If we lose focus or enter is pressed in the text field, see if we
 *	need to update the directory
 */
private int
dirUpdateCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	XmAnyCallbackStruct	*cb;

	cb = (XmAnyCallbackStruct *) call_data;

#ifdef NOTDEF
	if ( DirChange == False )
		return;
#endif

	DirChange = False;

	if ( chdir( XmTextFieldGetString( w ) ) )
	{
		XBell( display, BELL_VOLUME );
	}
	else
	{
		listFillDir( inputDirList );

		/*
		 *  Make sure that callback is made when extended selection
		 *  is made so that the output filename text field
		 *  is updated.
		 */

		XmListSelectPos( inputDirList, 1, True );
		textFillCurDir( outputDirText );
		if ( autodetValue == True )
			listFillSelFiles( inputTypesList, inputDirList );
	}
}
		


/*
 *  FUNCTION
 *	convCB	- callback when convert button pressed.
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Callback used to start a conversion when the convert button is
 *	pressed.
 */
private int
convCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	convertImg( );
}



/*
 *  FUNCTION
 *	prevueCB	- callback when preview button pressed 
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Not yet functional
 *
 */
private int
prevueCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	manageImXDlg( errorDlg, "Preview", "Preview option coming soon!\n(Bug Jason to get it done)", NULL, NULL );
	return;
}



/*
 *  FUNCTION
 *	alaphCB	- callback called when menu item changed in alpha option menu
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Modifies global variable which holds the value of which menu item
 *	on the alpha output parameter option menu is selected.
 *
 */
private int
alphaCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	AlphaVal = (int) client_data;

	return;
}



/*
 *  FUNCTION
 *	cltCB	- callback called when menu item changed in CLT option menu
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Modifies global variable which holds the value of which menu item
 *	on the CLT output parameter option menu is selected.
 *
 */
private int
cltCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	CLTVal = (int) client_data;

	return;
}



/*
 *  FUNCTION
 *	compressCB	- callback called when menu item changed in
 *			  compress option menu
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Modifies global variable which holds the value of which menu item
 *	on the compress output parameter option menu is selected.
 *
 */
private int
compressCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	CompressVal = (int) client_data;

	return;
}



/*
 *  FUNCTION
 *	channelCB	- callback called when menu item changed in
 *			  channel option menu
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Modifies global variable which holds the value of which menu item
 *	on the channel output parameter option menu is selected.
 *
 */
private int
channelCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	ChannelVal = (int) client_data;

	return;
}



/*
 *  FUNCTION
 *	chanDepthCB	- callback called when menu item changed in
 *			  channel depth option menu
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Modifies global variable which holds the value of which menu item
 *	on the channel depth output parameter option menu is selected.
 *
 */
private int
chanDepthCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	ChanDepthVal = (int) client_data;

	return;
}



/*
 *  FUNCTION
 *	interleavCB	- callback called when menu item changed in
 *			  interleave option menu
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Modifies global variable which holds the value of which menu item
 *	on the interleave output parameter option menu is selected.
 *
 */
private int
interleavCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	InterleavVal = (int) client_data;

	return;
}



/*
 *  FUNCTION
 *	typeCB	- callback called when menu item changed in type option menu
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Modifies global variable which holds the value of which menu item
 *	on the type output parameter option menu is selected.
 *
 */
private int
typeCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	TypeVal = (int) client_data;

	return;
}



/*
 *  FUNCTION
 *	storageCB - callback called when menu item changed in storage menu
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Modifies global variable which holds the value of which menu item
 *	on the alpha output parameter option menu is selected.
 *
 */
private int
storageCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	Arg		al[10];
	int		ac;
	XmString	labelStr;

	StorageVal = (int) client_data;

	switch ( StorageVal )
	{
	case 0:
		ChannelVal = 0;
		ChanDepthVal = 0;
		TypeVal = 0;

		/*
		 *  Reset labels to Automatic
		 */

		labelStr = XmStringCreateLtoR( "Automatic",
				XmSTRING_DEFAULT_CHARSET );
		ac = 0;
		XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
		XtSetValues( cltStdLabel, al, ac );
		XtSetValues( alphaStdLabel, al, ac );
		XmStringFree( labelStr );

		break;

	case ISTOR_1BITINDEX:
		ChannelVal = ICHANNEL_1;
		ChanDepthVal = ICHANDEPTH_1;
		TypeVal = ITYPE_INDEX;
		break;

	case ISTOR_4BITINDEX:
		ChannelVal = ICHANNEL_1;
		ChanDepthVal = ICHANDEPTH_4;
		TypeVal = ITYPE_INDEX;
		break;

	case ISTOR_8BITINDEX:
		ChannelVal = ICHANNEL_1;
		ChanDepthVal = ICHANDEPTH_8;
		TypeVal = ITYPE_INDEX;
		break;

	case ISTOR_16BITINDEX:
		ChannelVal = ICHANNEL_1;
		ChanDepthVal = ICHANDEPTH_16;
		TypeVal = ITYPE_INDEX;
		break;

	case ISTOR_15BITRGB:
		ChannelVal = ICHANNEL_3;
		ChanDepthVal = ICHANDEPTH_5;
		TypeVal = ITYPE_RGB;
		break;

	case ISTOR_24BITRGB:
		ChannelVal = ICHANNEL_3;
		ChanDepthVal = ICHANDEPTH_8;
		TypeVal = ITYPE_RGB;
		break;

	default:
		fprintf( stderr, "Invalid StorageVal: %d\n", StorageVal );
		fprintf( stderr, "Add this StorageVal to imxconv's source\n");
		break;
	}

	return;
}



private int
storageOptsCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	Arg		al[10];
	int		ac;
	char		*cltMsg, *alphaMsg;
	XmString	labelStr;

	StorageOptsVal = (int) client_data;

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, storageButtons[StorageVal] ); ac++;
	XtSetValues( StorageMenu, al, ac );

	switch ( StorageOptsVal )
	{
	case STOR_CLT_ALPHA:
		cltMsg = "Yes";
		alphaMsg = "Yes";
		CLTVal = ICLT_YES;
		AlphaVal = IALPHA_YES;
		break;

	case STOR_CLT_NOALPHA:
		cltMsg = "Yes";
		alphaMsg = "No";
		CLTVal = ICLT_YES;
		AlphaVal = IALPHA_NO;
		break;

	case STOR_NOCLT_ALPHA:
		cltMsg = "No";
		alphaMsg = "Yes";
		CLTVal = ICLT_NO;
		AlphaVal = IALPHA_YES;
		break;

	case STOR_NOCLT_NOALPHA:
		cltMsg = "No";
		alphaMsg = "No";
		CLTVal = ICLT_NO;
		AlphaVal = IALPHA_NO;
		break;

	default:
		fprintf( stderr, "Invalid storage option: %d\n",
			StorageOptsVal );
		break;

	}

	labelStr = XmStringCreateLtoR( cltMsg, XmSTRING_DEFAULT_CHARSET );
	ac = 0;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetValues( cltStdLabel, al, ac );
	XmStringFree( labelStr );

	labelStr = XmStringCreateLtoR( alphaMsg, XmSTRING_DEFAULT_CHARSET );
	ac = 0;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetValues( alphaStdLabel, al, ac );
	XmStringFree( labelStr );

	return;
}



/*
 *  FUNCTION
 *	autodetCB	- callback when autodetect image type toggle button
 *			  is toggled
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	Maintains the autodetValue global variable.
 *	If the automatic type detection is on, the list box associated with
 *	automatic type detection (inputTypesList) displays the filenames
 *	selected and the types detected.
 *
 *	If automatic type detection is off, then inputTypesList shows
 *	the valid input types since the user must manually select a 
 *	file type.
 *
 */
private int
autodetCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	autodetValue = XmToggleButtonGetState( w );

	if ( autodetValue == True )
	{
		typeLabelSet( AUTODET_STR );
		listFillSelFiles( inputTypesList, inputDirList );
	}
	else
	{
		typeLabelSet( INPUTTYPE_STR );
		listFillImForm( inputTypesList, *ImFileFormats, True );
	}
}



/*
 *  FUNCTION
 *	greyAllOutOpts	- grey all popdown menu options
 *
 *  DESCRIPTION
 *	Greyes all output parameter option menu buttons.
 *
 */
private void
greyAllOutOpts( )
{
	Arg		al[10];
	int		ac;
	int 		i, len;

	len = sizeof( AlphaOpts ) / sizeof( *AlphaOpts );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( alphaButtons[i], False );

	len = sizeof( CLTOpts ) / sizeof( *CLTOpts );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( cltButtons[i], False );

	len = sizeof( CompressionTypes ) / sizeof( *CompressionTypes );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( compressButtons[i], False );

	len = sizeof( Channels ) / sizeof( *Channels );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( channelButtons[i], False );

	len = sizeof( ChanDepth ) / sizeof( *ChanDepth );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( chanDepthButtons[i], False );

	len = sizeof( Interleaving ) / sizeof( *Interleaving );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( interleavButtons[i], False );

	len = sizeof( Types ) / sizeof( *Types );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( typeButtons[i], False );

	/*
	 *  This line must come just after the greying of the storage
	 *  buttons since it uses the number of storage options
	 *  as part of the length calculation for the length calculation
	 *  for the storage option pull left menu length.
	 *
	 *  Subtract 1 from len in the following line to remove the
	 *  Automatic button from consideration.
	 *
	 *  Different that other menus since we wish to grey the 
	 *  first menu item since it will not be Automatic.
	 */

	len = sizeof( StorageOpts ) / sizeof( *StorageOpts ) * (len-1);
	for ( i = 0; i < len; i++ )
		XtSetSensitive( storageOptsButtons[i], False );

	len = sizeof( CompressionTypes ) / sizeof( *CompressionTypes );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( compressStdButtons[i], False );

	len = sizeof( Storage ) / sizeof( *Storage );
	for ( i = 1; i < len; i++ )
		XtSetSensitive( storageButtons[i], False );
}



/*
 *  FUNCTION
 *	sensitizeButtons	- do the actual sensitization of the
 *				  output option buttons so that the
 *				  available items are not greyed out.
 *
 *  PARAMETERS
 *	ImFileFormat *pFmt	- pointer to the format information for 
 *				  the format selected by the user in 
 *				  the outputTypesList widget.
 *
 *  DESCRIPTION
 *	Uses the information in the gloabal variable holding the information
 *	about the image types (from libim) in order to ungrey all the 
 *	options which are valid for this file format.
 *
 *  NOTES
 *	Much of this code was derived from the code of imformats and 
 *	the associated library routines.
 *
 */
private void
sensitizeButtons( pFmt )
	ImFileFormat *pFmt;
{
	int			i, totalDepth;
	int			storageMenu, pdLen, offset;
	ImFileFormatWriteMap	*pWrite;
	Boolean			cltFlag, alphaFlag; 

	pWrite = pFmt->format_writeMap;

	/*
	 *  If no write support, leave all the buttons desensitized
	 *  Otherwise sensitize only those buttons which can be used for
	 *  the selected format.  This is a safeguard.  Formats without
	 *  write support should not even be displayed in outputTypesList.
	 */

	if ( pWrite == NULL )
		return;

	pdLen = sizeof( StorageOpts ) / sizeof( *StorageOpts );

	for ( ; pWrite->map_outType != -1; pWrite++ )
	{
		if ( pWrite->map_outAttributes & IMALPHAYES )
		{
			alphaFlag = True;
			XtSetSensitive( alphaButtons[IALPHA_YES], True );
		}
		else
		{
			alphaFlag = False;
			XtSetSensitive( alphaButtons[IALPHA_NO], True );
		}

		if ( pWrite->map_outAttributes & IMCLTYES )
		{
			cltFlag = True;
			XtSetSensitive( cltButtons[ICLT_YES], True );
		}
		else
		{
			cltFlag = False;
			XtSetSensitive( cltButtons[ICLT_NO], True );
		}


		switch ( pWrite->map_outType )
		{
		case IMTYPEINDEX:
			XtSetSensitive( typeButtons[ITYPE_INDEX], True );
			break;

		case IMTYPERGB:
			XtSetSensitive( typeButtons[ITYPE_RGB], True );
			break;

		case IMTYPE2D:
			XtSetSensitive( typeButtons[ITYPE_2D], True );
			break;

		default:
			fprintf( stderr, "Unknown type in ImFileFormats\n" );
			fprintf( stderr, "%s needs to be modified\n",
				ImToolsProgram);
			break;
		}

		switch ( pWrite->map_outNChannels )
		{
		case 1:
			XtSetSensitive( channelButtons[ICHANNEL_1], True );
			break;

		case 3:
			XtSetSensitive( channelButtons[ICHANNEL_3], True );
			break;

		default:
			fprintf( stderr, "Unknown channel in ImFileFormats\n" );
			fprintf( stderr, "%s needs to be modified\n",
				ImToolsProgram );
			break;
		}

		switch( pWrite->map_outChannelDepth )
		{
		case 1:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_1], True );
			break;

		case 2:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_2], True );
			break;

		case 4:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_4], True );
			break;

		case 5:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_5], True );
			break;

		case 8:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_8], True );
			break;

		case 16:
			XtSetSensitive( chanDepthButtons[ICHANDEPTH_16], True );
			break;

		default:
			fprintf( stderr, "Unknown depth in ImFileFormats\n" );
			fprintf( stderr, "%s needs to be modified\n",
				ImToolsProgram );
			break;
		}

		switch( pWrite->map_outAttributes & IMCOMPMASK )
		{
		case IMCOMPNO:
			XtSetSensitive( compressButtons[ICOMPRESS_NO], True );
			XtSetSensitive( compressStdButtons[ICOMPRESS_NO],
				True );
			break;

		case IMCOMPRLE:
			XtSetSensitive( compressButtons[ICOMPRESS_RLE], True );
			XtSetSensitive( compressStdButtons[ICOMPRESS_RLE],
				True );
			break;

		case IMCOMPLZW:
			XtSetSensitive( compressButtons[ICOMPRESS_LZW], True );
			XtSetSensitive( compressStdButtons[ICOMPRESS_LZW],
				True );
			break;

		case IMCOMPPB:
			XtSetSensitive( compressButtons[ICOMPRESS_PB], True );
			XtSetSensitive( compressStdButtons[ICOMPRESS_PB],
				True );
			break;

		case IMCOMPDCT:
			XtSetSensitive( compressButtons[ICOMPRESS_DCT], True );
			XtSetSensitive( compressStdButtons[ICOMPRESS_DCT],
				True );
			break;

		default:
			fprintf( stderr, "Unknown compression in ImFileFormats\n" );
			fprintf( stderr, "%s needs to be modified\n",
				ImToolsProgram );
			break;
		}

		switch( pWrite->map_outAttributes & IMINTERMASK )
		{
		case IMINTERNO:
			XtSetSensitive( interleavButtons[IINTERLEAV_NO], True );
			break;

		case IMINTERLINE:
			XtSetSensitive( interleavButtons[IINTERLEAV_LINE],
				True );
			break;

		case IMINTERPLANE:
			XtSetSensitive( interleavButtons[IINTERLEAV_PLANE],
				True );
			break;

		default:
			fprintf( stderr, "Unknown interleaving in ImFileFormats\n" );
			fprintf( stderr, "%s needs to be modified\n",
				ImToolsProgram );
			break;
		}

		/*
		 *  Now ungrey the STANDARD (NON-EXPERT) menus
		 */

		storageMenu = 0;
		totalDepth =
			pWrite->map_outNChannels * pWrite->map_outChannelDepth;
		switch ( pWrite->map_outType )
		{
		case IMTYPEINDEX:
			switch ( totalDepth )
			{
			case 1:
				storageMenu = ISTOR_1BITINDEX;
				break;
			case 4:
				storageMenu = ISTOR_4BITINDEX;
				break;
			case 8:
				storageMenu = ISTOR_8BITINDEX;
				break;
			case 16:
				storageMenu = ISTOR_16BITINDEX;
				break;
			default:
				fprintf( stderr,
					"Unknown total image depth.\n");
				fprintf( stderr, "Please modify imxconv source code to reflect new total image depth.\n" );
				break;
			}
			break;

		case IMTYPERGB:
			switch ( totalDepth )
			{
			case 15:
				storageMenu = ISTOR_15BITRGB;
				break;
			case 24:
				storageMenu = ISTOR_24BITRGB;
				break;
			default:
				fprintf( stderr,
					"Unknown total image depth.\n");
				fprintf( stderr, "Please modify imxconv source code to reflect new total image depth.\n" );
				break;
			}
			break;

		case IMTYPE2D:
			break;
		}

		XtSetSensitive( storageButtons[storageMenu], True );
		
		/*
		 *  Subtract one in order to eliminate the Automatic 
		 *  menu option from being considered
		 */

		offset = pdLen * (storageMenu-1);
		if ( cltFlag && !alphaFlag )
			offset += STOR_CLT_NOALPHA;
		else if ( cltFlag && alphaFlag )
			offset += STOR_CLT_ALPHA;
		else if ( !cltFlag && !alphaFlag )
			offset += STOR_NOCLT_NOALPHA;
		else if ( !cltFlag && alphaFlag )
			offset += STOR_NOCLT_ALPHA;
		else
		{
			fprintf( stderr,
				"Unknown CLT and Alpha combination.\n");
			fprintf( stderr, "Please add this combination to imxconv source code.\n" );
		}

		XtSetSensitive( storageOptsButtons[offset], True );
	}
}
	


/*
 *  FUNCTION
 *	resetPopDowns	- put output parameter pop down menus at first 
 *			  menu option.
 *
 *  DESCTIPTION
 *	Place all output option menu on first item and resets gloabal
 *	variables which hold the value of what each menu item is selected.
 *
 */
private void
resetPopDowns( )
{
	Arg		al[5];
	int		ac;
	XmString	labelStr;

	CompressVal = ChannelVal = ChanDepthVal = 0;
	InterleavVal = TypeVal = 0;
	AlphaVal = CLTVal = 0;
	StorageVal = StorageOptsVal = 0;

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, alphaButtons[0] ); ac++;
	XtSetValues( AlphaMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, cltButtons[0] ); ac++;
	XtSetValues( CLTMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, compressButtons[0] ); ac++;
	XtSetValues( CompressMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, channelButtons[0] ); ac++;
	XtSetValues( ChannelMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, chanDepthButtons[0] ); ac++;
	XtSetValues( ChanDepthMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, interleavButtons[0] ); ac++;
	XtSetValues( InterleavMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, typeButtons[0] ); ac++;
	XtSetValues( TypeMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, storageButtons[0] ); ac++;
	XtSetValues( StorageMenu, al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHistory, compressStdButtons[0] ); ac++;
	XtSetValues( CompressStdMenu, al, ac );

	/*
	 *  Reset labels to Automatic
	 */

	labelStr = XmStringCreateLtoR( "Automatic",
			XmSTRING_DEFAULT_CHARSET );
	ac = 0;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetValues( cltStdLabel, al, ac );
	XtSetValues( alphaStdLabel, al, ac );
	XmStringFree( labelStr );
}



/*
 *  FUNCTION
 *	selectButtons	- selects output option menu buttons based on which
 *			  output format is selected.
 *
 *  DESCRIPTION 
 *	Based on which output file format was selected this routine will
 *	call sensitizeButtons in order to activate the buttons that
 *	are valid for use with the format selected.  This routine uses the
 *	global ImFileFormats array to get the output parameter information.
 *
 *  NOTES
 *	Any pointers to information in the ImFileFormats array should not
 *	be freed or changed, or this side-effect will effect future uses of
 *	information in the ImFileFormats array.
 *
 */
private void
selectButtons( )
{
	ImFileFormat 	**ppFmt;	
	char		**pNames;

	for ( ppFmt = ImFileFormats; *ppFmt; ppFmt++ )
	{
		/*
		 *  Compare format names in ImFileFormats data structure
		 *  to the selected format name in order to access the
		 *  information associated with the image format.
		 */

		pNames = &(*ppFmt)->format_names[0];
		for ( ; *pNames; pNames++ )
		{
			if ( strcmp( *pNames, outFileExt ) == 0 )
			{
				sensitizeButtons( *ppFmt );
				break;
			}
		}
		if ( *pNames )
			break;
	}
}
	


/*
 *  FUNCTION
 *	outTypeSelCB	- records which output type was selected
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	When an output file type is selected, the global variable outExt is
 *	set to the extention of the new type selected.  A new output filename
 *	is also constructed and is placed into the output filename text
 *	field.
 *
 */
private int
outTypeSelCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	XmListCallbackStruct	*cb;
	char			*outType, *firstSpace;
	char			*inFilename;
	char			*outFilename;

	/*
	 *  Get extention of image type selected from the string in the
	 *  list box.  Place the extention onto the output filename after
	 *  removing the current extention on the output filename.
	 */

	cb = (XmListCallbackStruct *) call_data;

	XmStringGetLtoR( cb->item, XmSTRING_DEFAULT_CHARSET,
		&outType );
	
	firstSpace = NULL;
	firstSpace = strchr( outType, ' ' );
	if ( firstSpace == NULL )
	{	
		fprintf( stderr, "Bad output image type string.\n" );
		exit( 1 );
	}

	firstSpace[0] = '\0';
	strcpy( outFileExt, outType );
	XtFree( outType );

	inFilename = XmTextFieldGetString( outputFnameText );

	/*
	 *  Selectively sensitize options which apply to this format.
	 *  Leave other menu options greyed or insensitive.
	 *  Button sensitization is based on the format stored in the
	 *  global variable outFileExt.
	 */

	greyAllOutOpts( );
	resetPopDowns( );
	selectButtons( );

	/*
	 *  Change output filename to reflect the change in output type.
	 */

	if ( inFilename[0] == '\0' )
		return;

	if ( strcmp( inFilename, MULT_FILE_SEL_STR ) != 0 )
	{
		outFilename = constrOutFname( inFilename );
		XmTextFieldSetString( outputFnameText, outFilename );
		free( outFilename );
	}

	XtFree( inFilename );
}



/*
 *  FUNCTION
 *	CreateMenuBar	- construct the menu bar and menu structure
 *
 *  PARAMETERS
 *	Widget parent	- the parent widget to the menubar to be created
 *
 *  DESCRIPTION
 *	Constructs the menubar, including all the popdown menus with their
 *	buttons.  This routine also sets the mnemonic for each menu button.
 *	Returns a Widget which is the menubar.
 *
 */
private Widget
CreateMenuBar( parent )
	Widget parent;
{
	Widget		menuBar;
	Widget		cascade;
	Widget		menuPane;
	Widget		button;
	Widget		separator;

	Arg		al[10];
	int		ac;

	/*
	 *  Create MenuBar
	 */

	ac = 0;
	menuBar = XmCreateMenuBar( parent, "menubar", al, ac );

	/*
	 *  Create "File" PulldownMenu
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( menuBar, "menu_file", al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'C' ); ac++;
	button = XmCreatePushButtonGadget( menuPane, "Convert", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_CONVERT );
	XtManageChild( button );

	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'e' ); ac++;
	button = XmCreatePushButtonGadget( menuPane, "Delete", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_DELETE );
	XtManageChild( button );

	ac = 0;
	separator = XmCreateSeparator( menuPane, "Opt_Separator", al, ac );
	XtManageChild( separator );

	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'x' ); ac++;
	button = XmCreatePushButtonGadget( menuPane, "Exit", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_EXIT );
	XtManageChild( button );

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNmnemonic, 'F' ); ac++;
	cascade = XmCreateCascadeButton( menuBar, "File", al, ac );
	XtManageChild( cascade );

	/*
	 *  Create "Options" PulldownMenu
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( menuBar, "menu_opt", al, ac );

	ac = 0;
	button = XmCreatePushButtonGadget( menuPane, "Log File...", al, ac );
	XtSetArg( al[ac], XmNmnemonic, 'L' ); ac++;
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_LOGFILE );
	XtManageChild( button );
	XtSetSensitive( button, False );

	ac = 0;
	separator = XmCreateSeparator( menuPane, "Opt_Separator", al, ac );
	XtManageChild( separator );

	verboseFlag = True;
	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'V' ); ac++;
	XtSetArg( al[ac], XmNset, verboseFlag ); ac++;
	button = XmCreateToggleButtonGadget( menuPane, "Verbose", al, ac );
	XtAddCallback( button, XmNvalueChangedCallback, MenuCB, MENU_VERBOSE );
	XtManageChild( button );

	expertFlag = False;
	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'E' ); ac++;
	XtSetArg( al[ac], XmNset, expertFlag ); ac++;
	button = XmCreateToggleButtonGadget( menuPane, "Expert Mode",
			al, ac );
	XtAddCallback( button, XmNvalueChangedCallback, MenuCB, MENU_EXPERT );
	XtManageChild( button );

	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'O' ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	cascade = XmCreateCascadeButton( menuBar, "Options", al, ac );
	XtManageChild( cascade );

	/*
	 *  Create "Help" button
	 */
	ac = 0;
	menuPane = XmCreatePulldownMenu( menuBar, "menu_help", al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'I' ); ac++;
	button = XmCreatePushButtonGadget( menuPane, "Image Formats", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_HELP_FORMATS );
	XtManageChild( button );

	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'C' ); ac++;
	button = XmCreatePushButtonGadget( menuPane, "Conversion Parameters",
			al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_HELP_PARAM );
	XtManageChild( button );

	ac = 0;
	separator = XmCreateSeparator( menuPane, "Opt_Separator", al, ac );
	XtManageChild( separator );

	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'A' ); ac++;
	button = XmCreatePushButtonGadget( menuPane, "About ImXConv", al, ac );
	XtAddCallback( button, XmNactivateCallback, MenuCB, MENU_HELP_ABOUT );
	XtManageChild( button );

	ac = 0;
	XtSetArg( al[ac], XmNmnemonic, 'H' ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	cascade = XmCreateCascadeButton( menuBar, "Help", al, ac );
	XtManageChild( cascade );

	ac = 0;
	XtSetArg( al[ac], XmNmenuHelpWidget, cascade ); ac++;
	XtSetValues( menuBar, al, ac );

	return( menuBar );
}



/*
 *  FUNCTION
 *	CreateInputSec	- Create the left 1/3 of the interface, or the input
 *			  file section of the interface.
 *
 *  PARAMETERS
 *	Widget parent	- the parent widget to the input section
 *
 *  DESCRIPTION
 *	This routine constructs the widgets necessary to realize the input
 *	section of the interface.
 *	Returns a Widget which represents the input section.
 *
 *  NOTES
 *	The order that functions are called in this routine is important.
 *	If a function is called and it tries to change a widget which
 *	has not yet been created, run-time errors will result.
 *
 */
private Widget
CreateInputSec( parent )
	Widget parent;
{
	Widget		inputFrame;
	Widget		inputSec;
	Widget		dirText;
	Widget		dirLabel;
	Widget		convLabel;
	Widget		inputFiles;
	Widget		autodetToggle;
	Widget		typeLabel;
	Widget		intypeList;
	Widget		formInputFile, formInputType;
	Arg		al[15];
	int		ac;
	XmString	labelStr;
	char		newTrans[64];
	XtTranslations	transTable;


	/*
	 *  Create frame to put input section into
	 */
	ac = 0;
	XtSetArg( al[ac], XmNshadowType, XmSHADOW_IN ); ac++;
	XtSetArg( al[ac], XmNshadowThickness, FRAME_THICKNESS ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNmarginWidth, HORIZ_FORM_OFFSET ); ac++;
	XtSetArg( al[ac], XmNmarginHeight, VERT_FORM_OFFSET ); ac++;
	inputFrame = XmCreateFrame( parent, "inputFrame", al, ac );


	/*
	 *  Create container for InputSection
	 */
	ac = 0;
	inputSec = XmCreateForm( inputFrame, "inputSec", al, ac );
	XtManageChild( inputSec );


	/*
	 *  Create container for input file selection section
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNtopPosition, 0 ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNbottomPosition, 40 ); ac++;
	formInputFile = XmCreateForm( inputSec, "formInputFile", al, ac );
	XtManageChild( formInputFile );


	/*
	 *  Create label for directory text field
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Input File(s):",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	dirLabel = XmCreateLabel( formInputFile, "dirLabel", al, ac );
	XtManageChild( dirLabel );
	XmStringFree( labelStr );


	/*
	 *  Create directory entry line
	 *  Create new translation of Return key while entry line is 
	 *  active.  Make the Return key call the activate callback.
	 */
	strcpy( newTrans, "<Key>Return : activate()" );
	transTable = XtParseTranslationTable( newTrans );

	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, dirLabel ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	dirText = XmCreateTextField( formInputFile, "dirText", al, ac );
	XtOverrideTranslations( dirText, transTable );
	XtManageChild( dirText );


	/*
	 *  Set up global variable, so that we can access the text field
	 *  from the routine that does the directory browsing
	 */
	inputDirText = dirText;



	/*
	 *  Create Input File Selection List
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, dirText ); ac++;
	XtSetArg( al[ac], XmNtopOffset, SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNvisibleItemCount, VIS_INPUT_FILES ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNscrollBarDisplayPolicy, XmAS_NEEDED ); ac++;
	XtSetArg( al[ac], XmNlistSizePolicy, XmCONSTANT ); ac++;
	XtSetArg( al[ac], XmNselectionPolicy, XmEXTENDED_SELECT ); ac++;

	inputFiles = XmCreateScrolledList( formInputFile, "inputFiles", al, ac);
	
	inputDirList = inputFiles;

	XtAddCallback( inputFiles, XmNdefaultActionCallback, inFileDblCB,
			NULL );
	XtAddCallback( inputFiles, XmNextendedSelectionCallback,
			inFileExtCB, NULL );

	XtManageChild( inputFiles );

	textFillCurDir( inputDirText );
	listFillDir( inputFiles );

	XtAddCallback( dirText, XmNmodifyVerifyCallback, dirChangeCB, NULL );
	XtAddCallback( dirText, XmNlosingFocusCallback, dirUpdateCB, NULL );
	XtAddCallback( dirText, XmNactivateCallback, dirUpdateCB, NULL );


	/*
	 *  Create container for input file type section
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNtopPosition, 40 ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNbottomPosition, 100 ); ac++;
	formInputType = XmCreateForm( inputSec, "formInputType", al, ac );
	XtManageChild( formInputType );

	/*
	 *  Create Automatic type detection toggle button
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Automatic type detection",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopOffset, MED_OFFSET + SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNshadowThickness, 0 ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	autodetToggle = XmCreateToggleButton( formInputType, "autodetToggle",
				al, ac );
	XtManageChild( autodetToggle );
	XmStringFree( labelStr );

	XtAddCallback( autodetToggle, XmNvalueChangedCallback,
			autodetCB, NULL );


	/*
	 *  Create Input Conversion Type List Label
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( AUTODET_STR,
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, autodetToggle ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	typeLabel = XmCreateLabel( formInputType, "typeLabel", al, ac );
	XtManageChild( typeLabel );
	XmStringFree( labelStr );


	/*
	 *  Set global variable so that we can access the label 
	 *  in other routines.
	 */
	inputTypeLabel = typeLabel;


	/*
	 *  Create Input Type List
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, typeLabel ); ac++;
	XtSetArg( al[ac], XmNvisibleItemCount, VIS_INPUT_TYPES ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNscrollBarDisplayPolicy, XmAS_NEEDED ); ac++;
	XtSetArg( al[ac], XmNlistSizePolicy, XmCONSTANT ); ac++;
	intypeList = XmCreateScrolledList( formInputType, "intypeList", al, ac);
	XtManageChild( intypeList );

	XtAddCallback( intypeList, XmNdefaultActionCallback, typeDblCB,
			NULL );

	/*
	 *  Set global variable so that others can access list
	 *  ( autodetect toggle button )
	 */

	inputTypesList = intypeList;


#ifdef NOTDEF
	/*
	 *  Create Input Message Text area
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNtopPosition, 80 ); ac++;
	XtSetArg( al[ac], XmNtopOffset, MED_OFFSET ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNbottomPosition, 100 ); ac++;
	XtSetArg( al[ac], XmNrows, VIS_MESSAGE_ROWS ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNresizeHeight, False ); ac++;
	XtSetArg( al[ac], XmNresizeWidth, False ); ac++;
	XtSetArg( al[ac], XmNeditMode, XmMULTI_LINE_EDIT ); ac++;
	XtSetArg( al[ac], XmNeditable, False ); ac++;
	XtSetArg( al[ac], XmNscrollHorizontal, False ); ac++;
	XtSetArg( al[ac], XmNscrollVertical, False ); ac++;
	inputMessageText = XmCreateScrolledText( inputSec, "inputMessageText",
				al, ac );
	XtManageChild( inputMessageText );
#endif

	/*
	 *  Make is so that the types list box resizes when 
	 *  application window is pulled vertically
	 */

	autodetValue = True;
	XmToggleButtonSetState( autodetToggle, autodetValue, True );

	return( inputFrame );
}


/*
 *  FUNCTION
 *	CreateButtonBar - Construct the conversion button bar
 *
 *  PARAMETERS
 *	Widget parent	- the parent widget to the button bar
 *
 *  DESCRIPTION
 *	This routine constructs the middle 1/3 of the interface, the 
 *	button bar.  The button bar is designed to hold the buttons of
 *	useful functions of the interface, like Convert and Preview.
 *
 */
private Widget
CreateButtonBar( parent )
	Widget parent;
{
	Widget 		buttonBar;
	Widget		convertButton, previewButton;
	Widget		iconButton;
	XmString	labelStr;
	Arg		al[10];
	int		ac;
	Pixmap		imxconvPixmap;
	Screen		*screen;
	Pixel		fg, bg;

	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	buttonBar = XmCreateForm( parent, "buttonBar", al, ac );

	ac = 0;
	labelStr = XmStringCreateLtoR( "View Image", 
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 0 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 14 ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	previewButton = XmCreatePushButton( buttonBar, "previewButton",
				al, ac );
	XtAddCallback( previewButton, XmNactivateCallback, prevueCB, NULL );
	XtManageChild( previewButton );

	ac = 0;
	labelStr = XmStringCreateLtoR( ">> Convert >>", 
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 43 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 57 ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	convertButton = XmCreatePushButton( buttonBar, "convertButton",
				al, ac );
	XtAddCallback( convertButton, XmNactivateCallback, convCB, NULL );
	XtManageChild( convertButton );

	/*
	 *  Get the colors we will need for the foreground and background
	 *  of the bitmap.
	 */
	
	ac = 0;
	XtSetArg( al[ac], XmNforeground, &fg ); ac++;
	XtSetArg( al[ac], XmNbackground, &bg ); ac++;
	XtGetValues( convertButton, al, ac );

	ac = 0;
	screen = XtScreen( appShell );
	imxconvPixmap = XmGetPixmap( screen, "xlogo32", 
		fg, bg );
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 86 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 100 ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelType, XmPIXMAP ); ac++;
	XtSetArg( al[ac], XmNlabelPixmap, imxconvPixmap ); ac++;
	iconButton = XmCreatePushButton( buttonBar, "iconButton",
				al, ac );
	XtAddCallback( iconButton, XmNactivateCallback, aboutCB, NULL );
	XtManageChild( iconButton );

	XmStringFree( labelStr );

	return buttonBar;
}



/*
 *  FUNCTION
 *	CreateOutputSec	- constructs the output section of the interface
 *
 *  PARAMETERS
 *	Widget parent	- the parent widget to the output section
 *
 *  DESCRIPTION
 *	Creates the output section, or right 1/3 of the interface.  Care
 *	must be taken in the order that some of the functions are 
 *	called.  If a function is called and tries to modify a widget
 *	which has been not been created yet, run-time errors will result.
 */
private Widget
CreateOutputSec( parent )
	Widget parent;
{
	Widget		outputFrame;
	Widget		outputSec;
	Widget		dirLabel;
	Widget		dirText, filenameText;
	Widget		paramLabel;
	Widget		includeLabel;
	Widget		menuPane, menuButton;
	Widget		pullDown, pullDownButton;
	Widget		outTypeList;
	Widget		outputParamForm;
	Widget		optionLabel;
	Widget		labelForm;
	Arg		al[15];
	int		ac, i, j, len, pdLen, offset;
	XmString	labelStr;



	/*
	 *  Create frame to put output section into
	 */
	ac = 0;
	XtSetArg( al[ac], XmNshadowType, XmSHADOW_IN ); ac++;
	XtSetArg( al[ac], XmNshadowThickness, FRAME_THICKNESS ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNmarginWidth, HORIZ_FORM_OFFSET ); ac++;
	XtSetArg( al[ac], XmNmarginHeight, VERT_FORM_OFFSET ); ac++;
	outputFrame = XmCreateFrame( parent, "outputFrame", al, ac );


	/*
	 *  Create container for output section of interface
	 */
	ac = 0;
	outputSec = XmCreateForm( outputFrame, "outputSec", al, ac );
	XtManageChild( outputSec );

	
	/*
	 *  Create label for path and filename of output
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Output File:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	dirLabel = XmCreateLabel( outputSec, "dirLabel", al, ac );
	XtManageChild( dirLabel );
	XmStringFree( labelStr );


	/*
	 *  Create output path entry
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, dirLabel ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	dirText = XmCreateTextField( outputSec, "dirText", al, ac );
	XtManageChild( dirText );


	/*
	 *  Set global variable so that other routines can have access
	 *  to this widget (directory changed callback to place the
	 *  the current directory in this widget
	 */
	outputDirText = dirText;
	textFillCurDir( outputDirText );


	/*
	 *  Create output filename entry
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, dirText ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	filenameText = XmCreateTextField( outputSec, "dirText", al, ac );
	XtManageChild( filenameText );

	/*
	 *  Set up global variable so that this widget can be accessed
	 *  from other routines.
	 */
	outputFnameText = filenameText;


	/*
	 *  Create label for output conversion parameters
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Output Conversion Parameters:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, filenameText ); ac++;
	XtSetArg( al[ac], XmNtopOffset, SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	paramLabel = XmCreateLabel( outputSec, "paramLabel", al, ac );
	XtManageChild( paramLabel );
	XmStringFree( labelStr );


	/*
	 *  Create a form to hold the two standard and expert mode
	 *  option button row columns
	 *  (HOLD STANDARD and EXPERT MODES)
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, paramLabel ); ac++;
	outputParamForm = XmCreateForm( outputSec, "outputParamForm",
			al, ac);
	XtManageChild( outputParamForm );
	 

	/*
	 *  Create a row column to place the output parameter option menus in
	 *  (STANDARD MODE)
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 5 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNpacking, XmPACK_COLUMN ); ac++;
	XtSetArg( al[ac], XmNorientation, XmHORIZONTAL ); ac++;
	XtSetArg( al[ac], XmNnumColumns, 4 ); ac++;
	outputStandardOpts = XmCreateRowColumn( outputParamForm,
				"outputStandardOpts", al, ac );



	/*
	 *  Create Storage option menu (pop-down like)
	 *  (STANDARD MODE)
	 */

	ac = 0;
	labelStr = XmStringCreateLtoR( "Storage",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputStandardOpts, "optionLabel",
			al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );



	ac = 0;
	menuPane = XmCreatePulldownMenu( outputStandardOpts, "storagePane",
			al, ac);


	ac = 0;
	len = sizeof( Storage ) / sizeof( *Storage );
	storageButtons = (Widget *) malloc( len * sizeof( Widget ) );

	/*
	 *  Subtract 1 from len in the following line to remove the
	 *  Automatic button from consideration.
	 */

	pdLen = sizeof( StorageOpts ) / sizeof( *StorageOpts );
	storageOptsButtons = (Widget *) malloc(
					pdLen * (len-1) * sizeof( Widget ) );

	for ( i = 0; i < len; i++ )
	{
		ac = 0;
		if ( strcmp( Storage[i], "Automatic" ) )
		{
			ac = 0;
			pullDown = XmCreatePulldownMenu( menuPane, "pullDown",
					al, ac );

			for ( j = 0 ; j < pdLen; j++ )
			{
				ac = 0;
				pullDownButton = XmCreatePushButtonGadget(
					pullDown, StorageOpts[j], al, ac );
				XtAddCallback( pullDownButton,
					XmNactivateCallback, storageOptsCB, j );
				XtManageChild ( pullDownButton );

				/*
				 *  Store all the storage option submenu
				 *  buttons in a linear array.
				 */
				offset = ( (i-1) * pdLen ) + j;
				storageOptsButtons[offset] = pullDownButton;
			}

			XtSetArg( al[ac], XmNsubMenuId, pullDown ); ac++;
		}

		menuButton = XmCreateCascadeButtonGadget( menuPane, Storage[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, storageCB,
				i );
		XtAddCallback( menuButton, XmNcascadingCallback, storageCB,
				i );
		XtManageChild( menuButton );

		/*
		 *  Start building array of buttons used for compress 
		 *  menu.  These buttons form a parallel array with the
		 *  static string array of button labels.  This parallel
		 *  array is used to determine which buttons to sensitize
		 *  when certain image formats are selected.
		 */

		storageButtons[i] = menuButton;
	}


	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNspacing, 0 ); ac++;
	StorageMenu = XmCreateOptionMenu( outputStandardOpts, "optionmenu",
			al, ac );
	XtManageChild( StorageMenu );




	/*
	 *  Create Color Table Labels.
	 *  (STANDARD MODE)
	 */

	ac = 0;
	labelStr = XmStringCreateLtoR( "Color Table",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputStandardOpts, "optionLabel",
			al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	/*
	 *  Store the label in a form so that the label text can be 
	 *  centered within the row column space provided.
	 */
	ac = 0;
	labelForm = XmCreateForm( outputStandardOpts, "labelForm",
			al, ac );
	XtManageChild( labelForm );

	ac = 0;
	labelStr = XmStringCreateLtoR( "Automatic",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_CENTER ); ac++;
	cltStdLabel = XmCreateLabelGadget( labelForm,
				"optionLabelG", al, ac );
	XtManageChild( cltStdLabel );
	XmStringFree( labelStr );



	/*
	 *  Create Alpha Labels.
	 *  (STANDARD MODE)
	 */

	ac = 0;
	labelStr = XmStringCreateLtoR( "Alpha",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputStandardOpts, "optionLabel",
			al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	/*
	 *  Store the label in a form so that the label text can be 
	 *  centered within the row column space provided.
	 */
	ac = 0;
	labelForm = XmCreateForm( outputStandardOpts, "labelForm",
			al, ac );
	XtManageChild( labelForm );

	ac = 0;
	labelStr = XmStringCreateLtoR( "Automatic",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_CENTER ); ac++;
	alphaStdLabel = XmCreateLabelGadget( labelForm,
				"optionLabelG", al, ac );
	XtManageChild( alphaStdLabel );
	XmStringFree( labelStr );

	XtManageChild( labelForm );


	
	/*
	 *  Create Compression option menu (pop-down like)
	 *  (STANDARD MODE)
	 */

	ac = 0;
	labelStr = XmStringCreateLtoR( "Compression",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputStandardOpts, "optionLabel",
			al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	/*
	 *  Store the button in a form so that the button can be 
	 *  expanded within the row column space provided.
	 */
	ac = 0;
	labelForm = XmCreateForm( outputStandardOpts, "labelForm",
			al, ac );

	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	menuPane = XmCreatePulldownMenu( labelForm, "compressPane",
			al, ac );

	ac = 0;
	len = sizeof( CompressionTypes ) / sizeof( *CompressionTypes );
	compressStdButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButtonGadget( menuPane,
				CompressionTypes[i], al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, compressCB,
				i );
		XtManageChild( menuButton );

		/*
		 *  Start building array of buttons used for compress 
		 *  menu.  These buttons form a parallel array with the
		 *  static string array of button labels.  This parallel
		 *  array is used to determine which buttons to sensitize
		 *  when certain image formats are selected.
		 */

		compressStdButtons[i] = menuButton;
	}

	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNspacing, 0 ); ac++;
	CompressStdMenu = XmCreateOptionMenu( labelForm, "optionmenu",
				al, ac );
	XtManageChild( CompressStdMenu );

	XtManageChild( labelForm );


	/*
	 *  Create a row column to place the output parameter option menus in
	 *  (EXPERT MODE)
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 5 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNpacking, XmPACK_COLUMN ); ac++;
	XtSetArg( al[ac], XmNorientation, XmHORIZONTAL ); ac++;
	XtSetArg( al[ac], XmNnumColumns, 7 ); ac++;
	outputExpertOpts = XmCreateRowColumn( outputParamForm,
				"outputExpertOpts", al, ac );


	/*
	 *  Create Alpha option menu (pop-down like)
	 *  (EXPERT MODE)
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Alpha",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputExpertOpts, "optionLabel", al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	ac = 0;
	menuPane = XmCreatePulldownMenu( outputExpertOpts, "alphaPane", al, ac);

	ac = 0;
	len = sizeof( AlphaOpts ) / sizeof( *AlphaOpts );
	alphaButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButtonGadget( menuPane, AlphaOpts[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, alphaCB,
				i );
		XtManageChild( menuButton );

		/*
		 *  Start building array of buttons used for compress 
		 *  menu.  These buttons form a parallel array with the
		 *  static string array of button labels.  This parallel
		 *  array is used to determine which buttons to sensitize
		 *  when certain image formats are selected.
		 */

		alphaButtons[i] = menuButton;
	}

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNspacing, 0 ); ac++;
	AlphaMenu = XmCreateOptionMenu( outputExpertOpts, "optionmenu",
			al, ac );
	XtManageChild( AlphaMenu );

#ifdef NOTDEF
	/*
	 *  This could create more space on the screen by unmanaging
	 *  the unused option menu label
 	 */

	optionLabel = XmOptionLabelGadget( AlphaMenu );
	XtUnmanageChild( optionLabel );
#endif

	
	/*
	 *  Create Color Table option menu (pop-down like)
	 *  (EXPERT MODE)
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Color Table",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputExpertOpts, "optionLabel", al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	ac = 0;
	menuPane = XmCreatePulldownMenu( outputExpertOpts, "cltPane", al, ac);

	ac = 0;
	len = sizeof( CLTOpts ) / sizeof( *CLTOpts );
	cltButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButtonGadget( menuPane, CLTOpts[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, cltCB,
				i );
		XtManageChild( menuButton );

		/*
		 *  Start building array of buttons used for compress 
		 *  menu.  These buttons form a parallel array with the
		 *  static string array of button labels.  This parallel
		 *  array is used to determine which buttons to sensitize
		 *  when certain image formats are selected.
		 */

		cltButtons[i] = menuButton;
	}

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNspacing, 0 ); ac++;
	CLTMenu = XmCreateOptionMenu( outputExpertOpts, "optionmenu", al, ac );
	XtManageChild( CLTMenu );

	
	/*
	 *  Create Compression option menu (pop-down like)
	 *  (EXPERT MODE)
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Compression",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputExpertOpts, "optionLabel", al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	ac = 0;
	menuPane = XmCreatePulldownMenu( outputExpertOpts, "compressPane",
			al, ac);

	ac = 0;
	len = sizeof( CompressionTypes ) / sizeof( *CompressionTypes );
	compressButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButtonGadget( menuPane, CompressionTypes[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, compressCB,
				i );
		XtManageChild( menuButton );

		/*
		 *  Start building array of buttons used for compress 
		 *  menu.  These buttons form a parallel array with the
		 *  static string array of button labels.  This parallel
		 *  array is used to determine which buttons to sensitize
		 *  when certain image formats are selected.
		 */

		compressButtons[i] = menuButton;
	}

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNspacing, 0 ); ac++;
	CompressMenu = XmCreateOptionMenu( outputExpertOpts, "optionmenu",
				al, ac );
	XtManageChild( CompressMenu );

	
	/*
	 *  Create Channels option menu (pop-down like)
	 *  (EXPERT MODE)
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Channels",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputExpertOpts, "optionLabel", al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	ac = 0;
	menuPane = XmCreatePulldownMenu( outputExpertOpts, "channelPane",
			al, ac);

	ac = 0;
	len = sizeof( Channels ) / sizeof( *Channels );
	channelButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButtonGadget( menuPane, Channels[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, channelCB,
				i );
		XtManageChild( menuButton );

		channelButtons[i] = menuButton;
	}

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNspacing, 0 ); ac++;
	ChannelMenu = XmCreateOptionMenu( outputExpertOpts, "optionmenu",
			al, ac );
	XtManageChild( ChannelMenu );

	
	/*
	 *  Create Channel Depth option menu (pop-down like)
	 *  (EXPERT MODE)
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Channel Depth",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputExpertOpts, "optionLabel", al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	ac = 0;
	menuPane = XmCreatePulldownMenu( outputExpertOpts, "chanDepthMP",
			al, ac);

	ac = 0;
	len = sizeof( ChanDepth ) / sizeof( *ChanDepth );
	chanDepthButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButtonGadget( menuPane, ChanDepth[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, chanDepthCB,
				i );
		XtManageChild( menuButton );

		chanDepthButtons[i] = menuButton;
	}

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNspacing, 0 ); ac++;
	ChanDepthMenu = XmCreateOptionMenu( outputExpertOpts, "optionmenu",
				al, ac );
	XtManageChild( ChanDepthMenu );

	
	/*
	 *  Create Type menu (pop-down like)
	 *  (EXPERT MODE)
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Type",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputExpertOpts, "optionLabel", al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	ac = 0;
	menuPane = XmCreatePulldownMenu( outputExpertOpts, "typeMP", al, ac);

	ac = 0;
	len = sizeof( Types ) / sizeof( *Types );
	typeButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButtonGadget( menuPane, Types[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, typeCB,
				i );
		XtManageChild( menuButton );

		typeButtons[i] = menuButton;
	}

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNspacing, 0 ); ac++;
	TypeMenu = XmCreateOptionMenu( outputExpertOpts, "optionmenu",
				al, ac );
	XtManageChild( TypeMenu );


	/*
	 *  Create Interleaving menu (pop-down like)
	 *  (EXPERT MODE)
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Interleaving",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	optionLabel = XmCreateLabel( outputExpertOpts, "optionLabel", al, ac );
	XtManageChild( optionLabel );
	XmStringFree( labelStr );

	ac = 0;
	menuPane = XmCreatePulldownMenu( outputExpertOpts, "interleavMP",
			al, ac);

	ac = 0;
	len = sizeof( Interleaving ) / sizeof( *Interleaving );
	interleavButtons = (Widget *) malloc( len * sizeof( Widget ) );
	for ( i = 0; i < len; i++ )
	{
		menuButton = XmCreatePushButtonGadget( menuPane, Interleaving[i],
				al, ac );
		XtAddCallback( menuButton, XmNactivateCallback, interleavCB,
				i );
		XtManageChild( menuButton );

		interleavButtons[i] = menuButton;
	}

	ac = 0;
	XtSetArg( al[ac], XmNsubMenuId, menuPane ); ac++;
	XtSetArg( al[ac], XmNspacing, 0 ); ac++;
	InterleavMenu = XmCreateOptionMenu( outputExpertOpts, "optionmenu",
				al, ac );
	XtManageChild( InterleavMenu );


	ManageExpertMode( expertFlag );


	/*
	 *  Create label for output types
	 */
	ac = 0;
	labelStr = XmStringCreateLtoR( "Output Type:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNlabelString, labelStr ); ac++;
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, outputParamForm ); ac++;
	outTypeLabel = XmCreateLabel( outputSec, "outTypeLabel", al, ac );
	XtManageChild( outTypeLabel );
	XmStringFree( labelStr );

	/*
	 *  Create Output Type List
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlistSizePolicy, XmCONSTANT ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, outTypeLabel ); ac++;
	XtSetArg( al[ac], XmNtopOffset, SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNvisibleItemCount, VIS_INPUT_TYPES ); ac++;
	XtSetArg( al[ac], XmNcolumns, VIS_NUM_COLS ); ac++;
	XtSetArg( al[ac], XmNscrollBarDisplayPolicy, XmAS_NEEDED ); ac++;

	outTypeList = XmCreateScrolledList( outputSec, "outTypeList", al, ac);
	XtManageChild( outTypeList );

	XtAddCallback( outTypeList, XmNdefaultActionCallback, typeDblCB,
			NULL );

	/*
	 *  Setup global version of output type so that the selected type
	 *  can be retrieved by other functions.
	 */
	outputTypesList = outTypeList;

	XtAddCallback( outputTypesList, XmNbrowseSelectionCallback,
			outTypeSelCB, NULL );

	listFillImForm( outTypeList, *ImFileFormats, False );

	return( outputFrame );
}





/*
 *  FUNCTION
 *	main	- the function which puts together the entire interface
 *
 *  PARAMETERS
 *	unsigned int argc	- the number of command line parameters passed
 *	char **argv		- a string array of the command line 
 *				  parameters sent.
 *  DESCRIPTION
 *	The interface is constructed in a number of phases.  First the
 *	application is register and constructed.  Then the necessart dialog
 *	boxes are constructed, then the main interface window is constructed.
 *
 */

main( argc, argv )
	unsigned int argc;
	char **argv;
{
	Widget		main;
	Widget		menuBar;
	Widget		workRegion;
	Widget		inputSec, buttonBar, outputSec;
	Widget		sepRowCol, sectionSeparator;
	char 		*progname;
	int		ac;
	Arg		al[10];
	XtAppContext	appContext;
	Screen		*screen;
	private Pixmap	iconPixmap;

	if ( ImToolsProgram = strrchr( argv[0], '/' ) )
		ImToolsProgram++;
	else
		ImToolsProgram = argv[0];

	XtToolkitInitialize( );
	appContext = XtCreateApplicationContext( );
	XtAppSetFallbackResources( appContext, colorResources );
	display = XtOpenDisplay( appContext, NULL, ImToolsProgram, 
			ImToolsProgram, NULL, 0, &argc, argv );

	if ( !display )
	{
		XtWarning( "imxconv: can't open display." );
		exit( 1 );
	}

	appShell = XtAppCreateShell( ImToolsProgram, ImToolsProgram,
			applicationShellWidgetClass, display, NULL, 0 );

	/*
	 *  Set a minimum width for the size of the main
	 *  application window.
	 */

	ac = 0;
	XtSetArg( al[ac], XmNminWidth, 731 ); ac++;
	XtSetArg( al[ac], XmNminHeight, 504 ); ac++;
	XtSetValues( appShell, al, ac );


	/*
	 *  Create icon for iconified imxconv
	 */
	
	screen = XtScreen( appShell );
	iconPixmap = XmGetPixmap( screen, "xlogo64", 
		BlackPixelOfScreen( screen ), WhitePixelOfScreen( screen ) );

	ac = 0;
	XtSetArg( al[ac], XmNiconPixmap, iconPixmap ); ac++;
	XtSetValues( appShell, al, ac );


	/*
	 *  Create watch mouse pointer
	 */

	busyCursor = XCreateFontCursor( display, XC_watch );
		
	
	/*
	 *  Create MainWindow;
	 */

	ac = 0;
	XtSetArg( al[ac], XmNscrollingPolicy, XmAPPLICATION_DEFINED ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNbottomWidget, appShell ); ac++;
	main = XmCreateMainWindow( appShell, "main", al, ac );
	XtManageChild( main );

	/*
	 *  CreateMenuBar in MainWindow
	 */

	menuBar = CreateMenuBar( main );
	XtManageChild( menuBar );

	ac = 0;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNbottomWidget, main ); ac++;
	XtSetArg( al[ac], XmNverticalSpacing, VERT_FORM_OFFSET ); ac++;
	XtSetArg( al[ac], XmNhorizontalSpacing, HORIZ_FORM_OFFSET ); ac++;
	XtSetArg( al[ac], XmNmarginWidth, HORIZ_FORM_OFFSET ); ac++;
	XtSetArg( al[ac], XmNmarginHeight, VERT_FORM_OFFSET ); ac++;
	workRegion = XmCreateForm( main, "workRegion", al, ac );
	XtManageChild( workRegion );

	/*
	 *  Create output dialog box and question dialog box
	 */
	outputDlg = CreateOutputDlg( main );
	helpDlg = CreateHelpDlg( main );

	helpOutOptsDlg = CreateTextDlg( main, &helpOutOptsText, 
				"Output Parameter Help",
				"Output Parameter Help:" );

	textDlgConcat( helpOutOptsDlg, helpOutOptsText,
		helpOutOptsStr );
	delDlg = CreateImXDlg( main, XmDIALOG_QUESTION );
	errorDlg = CreateImXDlg( main, XmDIALOG_ERROR );
	aboutDlg = CreateImXDlg( main, XmDIALOG_INFORMATION );

	/*
	 *  Create Button Bar
	 */
	buttonBar = CreateButtonBar( workRegion );
	ac = 0;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetValues( buttonBar, al, ac );
	XtManageChild( buttonBar );

	/*
	 *  Create Input Section
	 */
	inputSec = CreateInputSec( workRegion );
	ac = 0;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, buttonBar ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 47 ); ac++;
	XtSetValues( inputSec, al, ac );
	XtManageChild( inputSec );


	/*
	 *  Create Separator between input and output sections
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 47 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 53 ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, buttonBar ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNorientation, XmVERTICAL ); ac++;
	sectionSeparator = XmCreateSeparator( workRegion, "sectionSeparator",
				al, ac );
	XtManageChild( sectionSeparator );

	/*
	 *  Create Ouput Section
	 */
	outputSec = CreateOutputSec( workRegion );
	ac = 0;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, buttonBar ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 53 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetValues( outputSec, al, ac );
	XtManageChild( outputSec );


	XmMainWindowSetAreas( main, menuBar, NULL, NULL, NULL,
				workRegion );

	XtRealizeWidget( appShell );

	XtAppMainLoop( appContext );
}
