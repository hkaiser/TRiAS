/**	$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxtools.h,v 1.2 93/07/19 16:36:48 secoskyj Exp $
 **	Copyright (c) 1989-1992  San Diego Supercomputer Center (SDSC)
 **		San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

/**
 **  FILE
 **	imxtools.h	- imxtools.c forward declarations
 **
 **  PROJECT
 **	IM		- Image Manipulation Tools
 **
 **  DESCRIPTION
 **	Forward declarations for imxtools.c routines
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **	ImXToolsErrorHandler	f	error handler for libim and Motif
 **	ImXToolsInfoHandler	f	info handler for libim and Motif
 **	ImXToolsOpen		f	open an image file
 **	ImXToolsFileRead	f	read an image into a vfb
 **	ImXToolsFileWrite	f	write a vfb to a file
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	imxtools.h,v $
 **	Revision 1.2  93/07/19  16:36:48  secoskyj
 **	removed HEADER definition
 **	
 **	Revision 1.1  93/07/19  16:23:59  secoskyj
 **	Initial revision
 **	
 **	
 **	
 **/

int	ImXToolsErrorHandler( );
int	ImXToolsInfoHandler( );
FILE	*ImXToolsOpen( );
int	ImXToolsFileRead( );
int	ImXToolsFileWrite( );

