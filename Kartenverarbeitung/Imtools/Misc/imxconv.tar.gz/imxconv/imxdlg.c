/**	$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxdlg.c,v 1.6 93/09/27 12:05:23 secoskyj Exp $
 **	Copyright (c) 1989-1992  San Diego Supercomputer Center (SDSC)
 **		San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER  "$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxdlg.c,v 1.6 93/09/27 12:05:23 secoskyj Exp $"

/**
 **  FILE
 **	imxdlg.c	- Dialog control function
 **
 **  PROJECT
 **	IM		- Image Manipulation Tools
 **
 **  DESCRIPTION
 **	The routines used to control information, question, error, 
 **	output, and any other dialogs are managed here.
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **	main		f  main program
 **
 **  PRIVATE CONTENTS
 **	OK_BUTTON_HEIGHT	d	Height of OK button in outputDlg
 **
 **  HISTORY
 **	$Log:	imxdlg.c,v $
 **	Revision 1.6  93/09/27  12:05:23  secoskyj
 **	Added a text dialog (custom widget) box, which contains a scrolled text
 **	area, and OK button, and a separator
 **	
 **	Revision 1.5  93/08/30  17:40:11  secoskyj
 **	No changes made
 **	
 **	Revision 1.4  93/08/24  15:38:36  secoskyj
 **	make outputDlgAbortButton gloabal so that 
 **	could check to see if button pressed 
 **	while conversion is happening
 **	
 **	Revision 1.3  93/07/22  12:51:50  secoskyj
 **	Changed message dialog routines in order to
 **	make them more generic.  Now one routine is
 **	called with a parameter for the type of
 **	message dialog that is needed.
 **	
 **	Revision 1.2  93/07/19  15:54:33  secoskyj
 **	Added public to each of the function type modifiers
 **	
 **	Revision 1.1  93/07/19  15:40:06  secoskyj
 **	Initial revision
 **	
 **	Revision 1.1  93/07/19  15:18:38  secoskyj
 **	Initial revision
 **	
 **	
 **/

#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#include <Xm/Xm.h>
#include <Xm/PushB.h>
#include <Xm/Form.h>
#include <Xm/Text.h>
#include <Xm/MessageB.h>
#include <Xm/TextF.h>
#include <Xm/Label.h>
#include <Xm/Separator.h>

#include "im.h"

#define OUTPUTDLG_OFFSET	(15)
#define BUTTON_HEIGHT		(30)
#define BUTTON_WIDTH		(110)
#define OK_BUTTON_OFFSET	(BUTTON_HEIGHT + 4 * OUTPUTDLG_OFFSET)

Widget		outputDlg;
Widget		outputDlgAbortButton;
Boolean		cancelFlag = False;
private Widget	outputDlgText;
private Widget	outputDlgOKButton;
private Widget	outputDlgStatus;
private Widget	outputDlgPercent;

/*
 *  FUNCTION
 *	outputDlgCB	- unmange outputDlg when OK button pressed
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	This is the callback when the OK button in the outputDlg is pressed.
 *	Right now it just unmanages the dialog box.
 *
 */
public void
outputDlgCB( w, client_data, call_data )
	Widget 	w;
	caddr_t	client_data;
	caddr_t	call_data;
{
	XtUnmanageChild( outputDlg );
}



public Boolean
outAbortCB( w, client_data, call_data )
	Widget 	w;
	caddr_t	client_data;
	caddr_t	call_data;
{
	cancelFlag = True;
}



/*
 *  FUNCTION
 *	CreateOutputDlg	- create output dialog box
 *
 *  PARAMETERS
 *	Widget parent	- the parent widget to the outputDlg dialog box.
 *
 *  DESCRIPTION
 *	This routine constructs the conversion status output dialog box.
 *	Returns a Widget that represents the output dialog box.
 *
 */
public Widget
CreateOutputDlg( parent )
	Widget parent;
{
	Arg		al[15];
	int		ac;
	int		i;
	Widget		child[5];
	Widget		dlg;
	Widget		outputDlgFileLabel;
	XmString	labelXStr;
	int		*buttonHeight;

	ac = 0;
	XtSetArg( al[ac], XmNtitle, "Conversion Status" ); ac++;
	XtSetArg( al[ac], XmNhorizontalSpacing, OUTPUTDLG_OFFSET ); ac++;
	XtSetArg( al[ac], XmNverticalSpacing, OUTPUTDLG_OFFSET ); ac++;
	XtSetArg( al[ac], XmNautoUnmanage, False ); ac++;
	dlg = XmCreateFormDialog( parent, "outputDlg",
		al, ac );

	/*
	 *  Create label for Converting File:
	 */
	ac = 0;
	labelXStr = XmStringCreateLtoR( "Converting File:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	outputDlgFileLabel= XmCreateLabel( dlg, "fileLabel", al, ac );
	XtManageChild( outputDlgFileLabel );
	XmStringFree( labelXStr );

	/*
	 *  Create label for filename currently converting
	 */
	ac = 0;
	labelXStr = XmStringCreateLtoR( " ",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNleftWidget, outputDlgFileLabel ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	outputDlgStatus= XmCreateLabel( dlg, "indexLabel", al, ac );
	XtManageChild( outputDlgStatus );
	XmStringFree( labelXStr );

	/*
	 *  Create verbose output text area
	 */
	ac = 0;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, outputDlgFileLabel ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomOffset, OK_BUTTON_OFFSET ); ac++;
	XtSetArg( al[ac], XmNresizeHeight, True ); ac++;
	XtSetArg( al[ac], XmNresizeWidth, True ); ac++;
	XtSetArg( al[ac], XmNeditMode, XmMULTI_LINE_EDIT ); ac++;
	XtSetArg( al[ac], XmNeditable, False ); ac++;
	XtSetArg( al[ac], XmNrows, 24 ); ac++;
	XtSetArg( al[ac], XmNcolumns, 80 ); ac++;
	XtSetArg( al[ac], XmNscrollHorizontal, True ); ac++;
	XtSetArg( al[ac], XmNscrollVertical, True ); ac++;
	outputDlgText = XmCreateScrolledText( dlg, "outputDlgText", al, ac );
	XtManageChild( outputDlgText );


	/*
	 *  Create label for file count, percent complete
	 */
	ac = 0;
	labelXStr = XmStringCreateLtoR( "( / )",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_END ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, outputDlgText ); ac++;
	XtSetArg( al[ac], XmNtopOffset, 10 ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	outputDlgPercent= XmCreateLabel( dlg, "percentLabel", al, ac );
	XtManageChild( outputDlgPercent );
	XmStringFree( labelXStr );


	/*
	 *  Create OK button to unmange the dialog
	 */
	labelXStr = XmStringCreateLtoR( "OK", XmSTRING_DEFAULT_CHARSET );
	ac = 0;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomOffset, OUTPUTDLG_OFFSET + 5 ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNheight, BUTTON_HEIGHT ); ac++;
	XtSetArg( al[ac], XmNwidth, BUTTON_WIDTH ); ac++;
	XtSetArg( al[ac], XmNshowAsDefault, 0 ); ac++;
	outputDlgOKButton = XmCreatePushButton( dlg, "outputDlgOKButton",
				al, ac );
	XtManageChild( outputDlgOKButton );
	XtAddCallback( outputDlgOKButton, XmNactivateCallback, outputDlgCB,	
		NULL );
	XmStringFree( labelXStr );


	/*
	 *  Create Abort button to cancel the conversion
	 */
	labelXStr = XmStringCreateLtoR( "Abort", XmSTRING_DEFAULT_CHARSET );
	ac = 0;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNheight, BUTTON_HEIGHT ); ac++;
	XtSetArg( al[ac], XmNwidth, BUTTON_WIDTH ); ac++;
	XtSetArg( al[ac], XmNshowAsDefault, 1 ); ac++;
	outputDlgAbortButton = XmCreatePushButton( dlg,
		"outputDlgAbortButton", al, ac );
	XtManageChild( outputDlgAbortButton );
	XtAddCallback( outputDlgAbortButton, XmNactivateCallback, 
		outAbortCB, NULL );
	XmStringFree( labelXStr );

	return( dlg );
}




/*
 *  FUNCTION
 *	outputDlgManage	- manage the output dialog under conditions of params
 *
 *  PARAMETERS
 *	Boolean verbose	- should we be verbose in dialog or not?
 *
 *  DESCRIPTION
 *	Manages the output dialog, but if verbose is not True, then the
 *	text widget is not manages.
 *
 */
public void
outputDlgManage( verbose )
	Boolean verbose;
{
	if ( verbose == True )
		XtManageChild( outputDlg );
	else
		XtUnmanageChild( outputDlg );
}




/*
 *  FUNCTION
 *	outputDlgStatusSet	- change dialog status label
 *
 *  PARAMETERS
 *	char *str	- string to put into output dialog status lable
 *
 *  DESCRIPTION
 *	Change the output dialog status label to something more current.
 *
 */
public void
outputDlgStatusSet( strFilename )
	char *strFilename;
{
	Arg		al[5];
	int		ac;
	XmString	strX;

	strX = XmStringCreateLtoR( strFilename, XmSTRING_DEFAULT_CHARSET );
	ac = 0;
	XtSetArg( al[ac], XmNlabelString, strX ); ac++;
	XtSetValues( outputDlgStatus, al, ac );
	XmStringFree( strX );
}


/*
 *  FUNCTION
 *	outputDlgPercentSet	- set the percent label
 *
 *  PARAMETERS
 *	char *strPercent	- string to set the label to
 *
 */
public void
outputDlgPercentSet( strPercent )
	char *strPercent;
{
	Arg		al[5];
	int		ac;
	XmString	strX;

	strX = XmStringCreateLtoR( strPercent, XmSTRING_DEFAULT_CHARSET );
	ac = 0;
	XtSetArg( al[ac], XmNlabelString, strX ); ac++;
	XtSetValues( outputDlgPercent, al, ac );
	XmStringFree( strX );
}



/*
 *  FUNCTION
 *	outputDlgOK	- turn ok button on or off
 *
 *  PARAMETERS
 *	Boolean yesno	- boolean whether to activate or deactivate the OK
 *			  button.
 *
 *  DESCRIPTION
 *	Sensitizes or desensitizes the output dialog OK button.
 *
 */
public void
outputDlgOKButtonCtrl( yesno )
	Boolean yesno;
{
	XtSetSensitive( outputDlgOKButton, yesno );
}



/*
 *  FUNCTION
 *	outputDlgConcat - concat a string to the current outputDlg message
 *
 *  PARAMETERS
 *	char *str	- the string to concat onto the existing text
 *			  widget string.
 *
 *  DESCRIPTION
 *	Concatenates the passed string onto the end of the string that is
 *	currently in the text box.  This is useful for the verbose messages
 *	output by the libim routines.  The libim routines can output the
 *	messages to the text box instead of the screen by calling this
 *	routine.
 *
 */
public void
outputDlgConcat( str )
	char *str;
{
	int	end;

	end = XmTextGetLastPosition( outputDlgText );
	XmTextInsert( outputDlgText, end, str );
	end = XmTextGetLastPosition( outputDlgText );
	XmTextShowPosition( outputDlgText, end );
	XmUpdateDisplay( outputDlg );
}



/*
 *  FUNCTION
 *	outputDlgClr	- clear string in output dialog	outputDlg message
 *
 *  DESCRIPTION
 *	Sets the text in the output dialog's text widget to NULL, or it
 *	clears out the text box.
 *
 */
public void
outputDlgClr( )
{
	XmTextSetString( outputDlgText, "" );
}




/*
 *  FUNCTION
 *	CreateImXDlg	- create a dialog based on passed parameters
 *
 *  PARAMETERS
 *	Widget 	parent	- the parent widget for the dialog
 *	int	type	- the type of dialog to create
 *
 *  DESCRIPTION
 *	Creates one of several convenience dialogs.
 *
 */
public Widget
CreateImXDlg( parent, type )
	Widget 		parent;
	unsigned char	type;
{
	Arg		al[5];
	int		ac;
	Widget		dlg;
	Widget		child;

	ac = 0;
	XtSetArg( al[ac], XmNmessageAlignment, XmALIGNMENT_CENTER ); ac++;
	XtSetArg( al[ac], XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL );
	ac++;

	switch( type )
	{
	case XmDIALOG_QUESTION:
		XtSetArg( al[ac], XmNdefaultButtonType,
				XmDIALOG_CANCEL_BUTTON ); ac++;
		dlg = XmCreateQuestionDialog( parent, "questDlg", al, ac );
		break;

	case XmDIALOG_WORKING:
		XtSetArg( al[ac], XmNdefaultButtonType,
				XmDIALOG_OK_BUTTON ); ac++;
		dlg = XmCreateWorkingDialog( parent, "workingDlg", al, ac );
		break;

	case XmDIALOG_INFORMATION:
		XtSetArg( al[ac], XmNdefaultButtonType,
				XmDIALOG_OK_BUTTON ); ac++;
		dlg = XmCreateInformationDialog( parent, "infoDlg", al, ac );
		child = XmMessageBoxGetChild( dlg, XmDIALOG_CANCEL_BUTTON );
		XtUnmanageChild( child );
		break;

	case XmDIALOG_ERROR:
		XtSetArg( al[ac], XmNdefaultButtonType,
				XmDIALOG_OK_BUTTON ); ac++;
		dlg = XmCreateErrorDialog( parent, "errorDlg", al, ac );
		child = XmMessageBoxGetChild( dlg, XmDIALOG_CANCEL_BUTTON );
		XtUnmanageChild( child );
		break;

	case XmDIALOG_WARNING:
		XtSetArg( al[ac], XmNdefaultButtonType,
				XmDIALOG_OK_BUTTON ); ac++;
		dlg = XmCreateWarningDialog( parent, "warnDlg", al, ac );
		child = XmMessageBoxGetChild( dlg, XmDIALOG_CANCEL_BUTTON );
		XtUnmanageChild( child );
		break;

	default:
		return NULL;
		break;
	}

	child = XmMessageBoxGetChild( dlg, XmDIALOG_HELP_BUTTON );
	XtUnmanageChild( child );

	return dlg;
}



/*
 *  FUNCTION
 *	manageImXDlg	- manage dialog and display the msgStr in it.
 *
 *  PARAMETERS
 *	Widget 	dlgW		- the dialog to manage
 *	char 	*titleStr	- the string to place on the dialog title bar
 *	char 	*msgStr		- message to place in the question dialog
 *	int 	(*okAction)( )	- callback if OK button pressed
 *	int 	(*cancel)( )	- callback if CANCEL button pressed
 *
 *  DESCRIPTION
 *
 */
public void
manageImXDlg( dlgW, titleStr, msgStr, okAction, cancel )
	Widget 	dlgW;
	char	*titleStr;
	char 	*msgStr;
	int 	(*okAction)( );
	int 	(*cancel)( );
{
	Arg		al[5];
	int		ac;
	XmString	msgXStr;
	XmString	titleXStr;

	msgXStr = XmStringCreateLtoR( msgStr, XmSTRING_DEFAULT_CHARSET );
	titleXStr = XmStringCreateLtoR( titleStr, XmSTRING_DEFAULT_CHARSET );

	ac = 0;
	XtSetArg( al[ac], XmNmessageString, msgXStr ); ac++;
	XtSetArg( al[ac], XmNdialogTitle, titleXStr ); ac++;
	XtSetValues( dlgW, al, ac );
	XtManageChild( dlgW );

	/*
	 *  Get rid of old callbacks, or they will still be called
	 */
	XtRemoveAllCallbacks( dlgW, XmNokCallback );
	XtRemoveAllCallbacks( dlgW, XmNcancelCallback );

	if ( okAction != NULL )
		XtAddCallback( dlgW, XmNokCallback, okAction, NULL );

	if ( cancel != NULL )
		XtAddCallback( dlgW, XmNcancelCallback, cancel, NULL );
}




public Widget
CreateTextDlg( parent, textWidget, title, label )
	Widget 	parent;
	Widget 	*textWidget;
	char 	*title;
	char	*label;
{
	Arg		al[15];
	int		ac;
	Widget		dlg, dlgLabel, localTextWidget, okButton;
	Widget		dlgSeparator;
	XmString	labelXStr;

	/*
	 *  Create dialog to hold the list and OK button
	 */
	ac = 0;
	XtSetArg( al[ac], XmNtitle, title ); ac++;
	XtSetArg( al[ac], XmNhorizontalSpacing, OUTPUTDLG_OFFSET ); ac++;
	XtSetArg( al[ac], XmNverticalSpacing, OUTPUTDLG_OFFSET ); ac++;
	XtSetArg( al[ac], XmNautoUnmanage, True ); ac++;
	dlg = XmCreateFormDialog( parent, "outputDlg",
		al, ac );

	/*
	 *  Create label
	 */
	ac = 0;
	labelXStr = XmStringCreateLtoR( label, XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	dlgLabel = XmCreateLabel( dlg, "textDlgLabel", al, ac );
	XtManageChild( dlgLabel );
	XmStringFree( labelXStr );

	/*
	 *  Create output text area
	 */
	ac = 0;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, dlgLabel ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomOffset, OK_BUTTON_OFFSET ); ac++;
	XtSetArg( al[ac], XmNresizeHeight, True ); ac++;
	XtSetArg( al[ac], XmNresizeWidth, True ); ac++;
	XtSetArg( al[ac], XmNeditMode, XmMULTI_LINE_EDIT ); ac++;
	XtSetArg( al[ac], XmNeditable, False ); ac++;
	XtSetArg( al[ac], XmNrows, 24 ); ac++;
	XtSetArg( al[ac], XmNcolumns, 80 ); ac++;
	XtSetArg( al[ac], XmNscrollHorizontal, True ); ac++;
	XtSetArg( al[ac], XmNscrollVertical, True ); ac++;
	localTextWidget = XmCreateScrolledText( dlg, "textDlgText", al, ac );
	XtManageChild( localTextWidget );

	*textWidget = localTextWidget;

	/*
	 *  Create OK button to unmange the dialog
	 */
	labelXStr = XmStringCreateLtoR( "OK", XmSTRING_DEFAULT_CHARSET );
	ac = 0;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomOffset, OUTPUTDLG_OFFSET + 5 ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 45 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 55 ); ac++;
	XtSetArg( al[ac], XmNheight, BUTTON_HEIGHT ); ac++;
	XtSetArg( al[ac], XmNshowAsDefault, 1 ); ac++;
	okButton = XmCreatePushButton( dlg, "textDlgButton",
				al, ac );
	XtManageChild( okButton );
	XmStringFree( labelXStr );

	/*
	 *  Create separator just between ok button and text widget
	 */
	ac = 0;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 100 ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 0 ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNbottomWidget, okButton ); ac++;
	XtSetArg( al[ac], XmNbottomOffset, 2 * OUTPUTDLG_OFFSET / 2 ); ac++;
	dlgSeparator = XmCreateSeparator( dlg, "textDlgSeparator", al, ac );
	XtManageChild( dlgSeparator );

	return ( dlg );
}



textDlgConcat( textDlg, textWidget, msgStr )
	Widget	textDlg;
	Widget 	textWidget;
	char	*msgStr;
{
	int	end;

	end = XmTextGetLastPosition( textWidget );
	XmTextInsert( textWidget, end, msgStr );
	end = XmTextGetLastPosition( textWidget );
	XmTextShowPosition( textWidget, 0 );
	XmUpdateDisplay( textDlg );
}
