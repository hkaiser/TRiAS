/****************************************************************************
 * rgbimage.cc
 * Authors Joel Welling, Rob Earhart
 * Copyright 1993, Pittsburgh Supercomputing Center, Carnegie Mellon University
 *
 * Permission use, copy, and modify this software and its documentation
 * without fee for personal use or use within your organization is hereby
 * granted, provided that the above copyright notice is preserved in all
 * copies and that that copyright and this permission notice appear in
 * supporting documentation.  Permission to redistribute this software to
 * other organizations or individuals is not granted;  that must be
 * negotiated with the PSC.  Neither the PSC nor Carnegie Mellon
 * University make any representations about the suitability of this
 * software for any purpose.  It is provided "as is" without express or
 * implied warranty.
 *****************************************************************************/

/**
 **	$Header: /sdsc/dev/vis/image/imtools/v3.0/imxdisplay/src/RCS/rgbimage.cc,v 1.3 94/06/30 15:10:28 secoskyj Exp $
 **	Copyright (c) 1989-1994  San Diego Supercomputer Center (SDSC)
 **		a division of General Atomics, San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER  "$Header: /sdsc/dev/vis/image/imtools/v3.0/imxdisplay/src/RCS/rgbimage.cc,v 1.3 94/06/30 15:10:28 secoskyj Exp $"

/**
 **  FILE
 **	rgbimage.cc	-  
 **
 **  PROJECT
 **	IM		-  
 **
 **  DESCRIPTION
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	rgbimage.cc,v $
 **	Revision 1.3  94/06/30  15:10:28  secoskyj
 **	Make checking of image file type to accomodate passing an image file
 **	type to the rgbImage constructor.  This was used to accomodate a user
 **	specifying a file type with a dash operator for a file on teh
 **	command line
 **	
 **	Revision 1.2  94/05/20  17:37:18  secoskyj
 **	Will not convert incoming images to rgb.
 **	Just loads the image into a vfb and relies
 **	on the *_init routines in ximagehandler.cc
 **	to convert the vfbs to the correct format
 **	for display
 **	
 **	Revision 1.1  94/03/23  17:38:46  secoskyj
 **	Initial revision
 **	
 **	
 **/


#include <stdio.h>
#include <stdlib.h>
extern "C" {
#include <im.h>
};
#include "rgbimage.h"

rgbImage::rgbImage( int xin, int yin, ImVfb *initial_buf )
{
    xdim= xin;
    ydim= yin;
    if (!initial_buf) {
      buf= ImVfbAlloc( xdim, ydim, IMVFBRGB | IMVFBALPHA);
      owns_buffer= 1;
    }
    else {
      buf= initial_buf;
      owns_buffer= 0;
    }
    image_valid= 1;
}

rgbImage::rgbImage( FILE *fp, char *fname, char *format )
{
  owns_buffer= 0;
  // Allocate tag tables and add error stream
  TagTable *dataTable= TagTableAlloc();
  if (!dataTable) {
    image_valid= 0;
    return;
  }
  TagTable *flagsTable= TagTableAlloc();
  if (!dataTable || !flagsTable) {
    image_valid= 0;
    return;
  }
  FILE *tmp= stderr;
  if ( TagTableAppend( flagsTable,
		       TagEntryAlloc("error stream", POINTER, &tmp))
       == -1 ) {
    image_valid= 0;
    return;
  }

  // Get the input file format
  if ( format == NULL || format[0] == '\0' )
  {
	  format = ImFileQFFormat( fp, fname );
	  if (!format) {
	    image_valid= 0;
	    TagTableFree( dataTable );
	    TagTableFree( flagsTable );
	    return;
	  }
  }

  // Read the file
  if ( ImFileFRead( fp, format, flagsTable, dataTable ) == -1 ) {
    image_valid= 0;
    TagTableFree( dataTable );
    TagTableFree( flagsTable );
    return;
  }

  // Get the image
  TagEntry *imageEntry= TagTableQDirect( dataTable, "image vfb", 0 );
  if (!imageEntry) {
    image_valid= 0;
    TagTableFree( dataTable );
    TagTableFree( flagsTable );
    return;
  }
  if (TagEntryQValue( imageEntry, &buf ) == -1) {
    image_valid= 0;
    TagTableFree( dataTable );
    TagTableFree( flagsTable );
    return;
  }
  owns_buffer= 1;

  xdim= ImVfbQWidth( buf );
  ydim= ImVfbQHeight( buf );

  // Clean up
  TagTableFree( dataTable );
  TagTableFree( flagsTable );

  // Heh. So it\'s valid after all.
  image_valid= 1;
}



/*
 *  Convert to rgb if not already rgb 
 */

int rgbImage::toRgb( )
{
  if ( !(ImVfbQFields(buf) & IMVFBRGB) ) {
    ImVfb *rgbVfb;
    int datSrcFields;

    datSrcFields = ImVfbQFields( buf ) & IMVFBOTHERMASK;
    rgbVfb = ImVfbAlloc( ImVfbQWidth( buf ), ImVfbQHeight( buf ),
		IMVFBRGB | datSrcFields );
    if ( rgbVfb == NULL ) {
      return 0;
    }

    if ( !ImVfbToRgb(buf, rgbVfb) ) {
      ImVfbFree( rgbVfb );
      return 0;
    }

    ImCltFree( ImVfbQClt( buf ) );
    ImVfbFree( buf );
    buf = rgbVfb;
  }

  return 1;
}



/*
 *  Convert to index8 if not already index8 
 */

int rgbImage::toIndex8( )
{
  if ( !(ImVfbQFields(buf) & IMVFBINDEX8) ) {
    ImVfb *index8Vfb;
    int datSrcFields;

    datSrcFields = ImVfbQFields( buf ) & IMVFBOTHERMASK;
    index8Vfb = ImVfbAlloc( ImVfbQWidth( buf ), ImVfbQHeight( buf ),
		IMVFBINDEX8 | datSrcFields );
    if ( index8Vfb == NULL ) {
      return 0;
    }

    if ( !ImVfbToIndex8(buf, index8Vfb) ) {
      ImVfbFree( index8Vfb );
      return 0;
    }

    ImVfbFree( buf );
    buf = index8Vfb;
  }

  return 1;
}


int rgbImage::index8( int x, int y )
{
	ImVfbPtr	pSrc;

	pSrc = ImVfbQPtr( buf, x, y );
	return ImVfbQIndex8( buf, pSrc );
}



rgbImage::~rgbImage()
{
  if (valid() && owns_buffer) ImVfbFree( buf );
}

void rgbImage::clear( rgbPixel pix )
{
  ImVfbPtr p, p1, p2;

  p1= ImVfbQPtr( buf, 0, 0 );
  p2= ImVfbQPtr( buf, xdim-1, ydim-1 );
  for ( p=p1; p<=p2; ImVfbSInc(buf,p) ) {
    ImVfbSRed( buf, p, pix.r() );
    ImVfbSGreen( buf, p, pix.g() );
    ImVfbSBlue( buf, p, pix.b() );
    ImVfbSAlpha( buf, p, pix.a() );
  }
}

void rgbImage::add_under( rgbImage *other )
// Note that this method assumes premultiplication by alpha!
{
  ImVfbPtr p, p1, p2;
  ImVfbPtr p_other;
  float alpha;

  p1= ImVfbQPtr( buf, 0, 0 );
  p2= ImVfbQPtr( buf, xdim-1, ydim-1 );
  p_other= ImVfbQPtr( other->buf, 0, 0 );
  for ( p=p1; p<=p2; ImVfbSInc(buf,p) ) {
    alpha= ((float)ImVfbQAlpha( buf, p ))/255.0;
    ImVfbSRed( buf, p, (int)(ImVfbQRed(buf,p)
			     + (1.0-alpha)*ImVfbQRed(other->buf,p_other)));
    ImVfbSGreen( buf, p, (int)(ImVfbQGreen(buf,p)
			     + (1.0-alpha)*ImVfbQGreen(other->buf,p_other)));
    ImVfbSBlue( buf, p, (int)(ImVfbQBlue(buf,p)
			     + (1.0-alpha)*ImVfbQBlue(other->buf,p_other)));
    ImVfbSAlpha( buf, p, (int)(ImVfbQAlpha(buf,p)
			     + (1.0-alpha)*ImVfbQAlpha(other->buf,p_other)));
    ImVfbSInc( other->buf, p_other );
  }
}

void rgbImage::rescale_by_alpha()
// Note that this method assumes premultiplication by alpha!  The purpose
// of this routine is to undo that premultiplication.
{
  ImVfbPtr p, p1, p2;
  float inv_alpha;

  p1= ImVfbQPtr( buf, 0, 0 );
  p2= ImVfbQPtr( buf, xdim-1, ydim-1 );
  for ( p=p1; p<=p2; ImVfbSInc(buf,p) ) {
    if ((ImVfbQAlpha( buf, p ) != 255) && (ImVfbQAlpha( buf, p ) != 0)) {
      inv_alpha= 255.0/((float)ImVfbQAlpha( buf, p ));
      ImVfbSRed( buf, p, bounds_check((int)(inv_alpha*ImVfbQRed(buf,p))) );
      ImVfbSGreen( buf, p, bounds_check((int)(inv_alpha*ImVfbQGreen(buf,p))) );
      ImVfbSBlue( buf, p, bounds_check((int)(inv_alpha*ImVfbQBlue(buf,p))) );
      ImVfbSAlpha( buf, p, 255 );
    }
  }
}

int rgbImage::save( char *fname, char *format )
{
  if (valid()) { 
    FILE *file;
    TagTable *dataTable;

    dataTable= TagTableAlloc();
    file= fopen(fname, "w");
    if (!file) {
      fprintf(stderr,
	      "rgbImage::save: cannot open file %s for writing!\n",
	      fname);
      return(0);
    }
    TagTableAppend( dataTable, TagEntryAlloc( "image vfb", POINTER, &buf ) ); 
    if ( ImFileFWrite( file, format, NULL, dataTable ) == -1 ) {
      fprintf(stderr,
	      "rgbImage::save: image save failed; error %d!\n",
	      ImErrNo);
      TagTableFree(dataTable);
      return(0);
    }
    if (fclose( file ) == EOF) {
      fprintf(stderr,"rgbImage::save: could not close file <%s>!\n",
	      fname);
      return(0);
    }
    return(1);
  }
  else {
    fprintf(stderr,"rgbImage::save: can't save an invalid image!\n");
    return(0);
  }
}
