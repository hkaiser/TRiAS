/****************************************************************************
 * rgbimage.h
 * Authors Joel Welling, Rob Earhart
 * Copyright 1993, Pittsburgh Supercomputing Center, Carnegie Mellon University
 *
 * Permission use, copy, and modify this software and its documentation
 * without fee for personal use or use within your organization is hereby
 * granted, provided that the above copyright notice is preserved in all
 * copies and that that copyright and this permission notice appear in
 * supporting documentation.  Permission to redistribute this software to
 * other organizations or individuals is not granted;  that must be
 * negotiated with the PSC.  Neither the PSC nor Carnegie Mellon
 * University make any representations about the suitability of this
 * software for any purpose.  It is provided "as is" without express or
 * implied warranty.
 *****************************************************************************/

/**
 **	$Header: /sdsc/dev/vis/image/imtools/v3.0/imxdisplay/src/RCS/rgbimage.h,v 1.3 94/06/30 15:11:33 secoskyj Exp $
 **	Copyright (c) 1989-1994  San Diego Supercomputer Center (SDSC)
 **		a division of General Atomics, San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/


/**
 **  FILE
 **	rgbimage.h	-  
 **
 **  PROJECT
 **	IM		-  
 **
 **  DESCRIPTION
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	rgbimage.h,v $
 **	Revision 1.3  94/06/30  15:11:33  secoskyj
 **	added an optional parameter to the rgbImage constructor for
 **	an image format type.
 **	
 **	
 **	Revision 1.2  94/03/23  18:08:11  secoskyj
 **	Removed HEADER definition
 **	
 **	Revision 1.1  94/03/23  17:41:10  secoskyj
 **	Initial revision
 **	
 **	
 **/


class netRgbImage;

class rgbPixel {
// range= 0 - 255 for all int values, 0.0 - 1.0 for floats
public:
  rgbPixel( int r, int g, int b, int a = 255)
    { rval= r; gval= g; bval= b; aval= a; }
  rgbPixel()
    { rval= 0; gval= 0; bval= 0; aval= 0; }
  rgbPixel( const rgbPixel& other )
      { rval= other.r(); gval= other.g(); bval= other.b(); aval= other.a();}
  void set_r( int value ) { rval= value; }
  void set_g( int value ) { gval= value; }
  void set_b( int value ) { bval= value; }
  void set_a( int value ) { aval= value; }
  int r() const { return( rval ); }
  int g() const { return( gval ); }
  int b() const { return( bval ); }
  int a() const { return( aval ); }
  float fr() const { return( (float)rval/255.0 ); }
  float fg() const { return( (float)gval/255.0 ); }
  float fb() const { return( (float)bval/255.0 ); }
  float fa() const { return( (float)aval/255.0 ); }
private:
  unsigned char rval;
  unsigned char gval;
  unsigned char bval;
  unsigned char aval;
};

class rgbImage {
    friend netRgbImage;
public:
  rgbImage(int xin, int yin, ImVfb *initial_buf= NULL );
  rgbImage( FILE *fp, char *filename, char *format = NULL );
  virtual ~rgbImage();
  void clear( rgbPixel pix );
  void clear() { clear( rgbPixel() ); } // clears with black
  void add_under( rgbImage *other ); // result is composite of this over other
  void rescale_by_alpha(); // takes out premult. by alpha; alpha becomes 255
  int pix_r(const int i, const int j ) const
    {return( ImVfbQRed( buf, ImVfbQPtr( buf, i, j )));};
  int pix_g(const int i, const int j ) const
    {return( ImVfbQGreen( buf, ImVfbQPtr( buf, i, j )));};
  int pix_b(const int i, const int j ) const
    {return( ImVfbQBlue( buf, ImVfbQPtr( buf, i, j )));};
  int pix_a(const int i, const int j ) const
    {return( ImVfbQAlpha( buf, ImVfbQPtr( buf, i, j )));};
  rgbPixel pix( const int i, const int j ) const
  {
    ImVfbPtr p= ImVfbQPtr( buf, i, j );
    return( rgbPixel( ImVfbQRed( buf, p ),
		     ImVfbQGreen( buf, p ),
		     ImVfbQBlue( buf, p ),
		     ImVfbQAlpha( buf, p) ) );
  }
  void setpix( const int i, const int j, const rgbPixel& pix )
  {
    ImVfbPtr p= ImVfbQPtr( buf, i, j );
    ImVfbSRed( buf, p, pix.r() );
    ImVfbSGreen( buf, p, pix.g() );
    ImVfbSBlue( buf, p, pix.b() );
    ImVfbSAlpha( buf, p, pix.a() );
  }
  int xsize() const { return xdim; }
  int ysize() const { return ydim; }
  int valid() const { return image_valid; };
  int save( char *fname, char *format ); // returns non-zero on success
  int toRgb( );
  int toIndex8( );
  ImClt *vfbClt( ) { return ImVfbQClt( buf ); };
  int index8( int x, int y );
private:
  int bounds_check( int val ) const
  { return( val < 0 ? 0 : ( val > 255 ? 255 : val ) ); }
  int xdim;
  int ydim;
  char image_valid;
  char owns_buffer;
  ImVfb *buf;
};

