/**
 **	$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxtools.c,v 1.6 93/09/07 09:50:00 secoskyj Exp $
 **	Copyright (c) 1989-1992  San Diego Supercomputer Center (SDSC)
 **		San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER	"$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxtools.c,v 1.6 93/09/07 09:50:00 secoskyj Exp $"

/**
 **  FILE
 **	imxtools.c	-  generic image tools code used by most tools
 **			   graphics user interface version
 **
 **  PROJECT
 **	IM		-  Image Manipulation Tools
 **
 **  DESCRIPTION
 **	imtools.c contains generic tool code used by most of the image tools.
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **	ImXToolsErrorHandler	f  standard error code handler
 **	ImXToolsInfoHandler	f  standard info handler
 **	ImXToolsOpen		f  open a file/stream & get its format
 **	ImXToolsFileRead	f  read in an image file
 **	ImXToolsFileWrite	f  write out an image file
 **
 **  PRIVATE CONTENTS
 **	none
 **
 **  HISTORY
 **	$Log:	imxtools.c,v $
 **	Revision 1.6  93/09/07  09:50:00  secoskyj
 **	modified conversion error messages to referece
 **	the image format help screen instead of imformats -long -long
 **	
 **	Revision 1.5  93/07/19  15:57:33  secoskyj
 **	Added public to the type motifiers of the functoins
 **	
 **	Revision 1.4  93/07/08  17:35:55  secoskyj
 **	Fixed bug.  XImToolsFileRead and FileWrite were strcpy'ing
 **	too much into the format string causing a segmentation
 **	fault.
 **	
 **	Revision 1.3  93/07/08  12:15:04  secoskyj
 **	Update to new directory name
 **	
 **	Revision 1.2  93/07/06  14:08:24  secoskyj
 **	XImToolsFileRead and XImToolsFileWrite were not returning
 **	values when they successfully complete.
 **	
 **	Revision 1.1  93/07/05  19:37:36  secoskyj
 **	Initial revision
 **	
 **	
 **/

#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/MessageB.h>

#include "imtools.h"



/*
 *  FUNCTION
 *	ImXToolsErrorHandler	-  standard error code handler
 *	ImXToolsInfoHandler	-  standard info handler
 *
 *  DESCRIPTION
 *	Outputs error or information messages to the conversion status
 *	output dialog.
 *
 */
public int				/* Returns status		*/
ImXToolsErrorHandler( severity, imerrno, message )
	int severity;			/* Error severity		*/
	int imerrno;			/* Error number			*/
	char *message;			/* Message to display		*/
{
	switch ( imerrno )
	{
	case IMENOTPOSSIBLE:
	case IMEMANYVFB:
	case IMENOVFB:
		/* We'll handle these specially later.			*/
		return ( 0 );
	}

	outputDlgConcat( message );
	return ( 0 );
}

public int				/* Returns status		*/
ImXToolsInfoHandler( program, filename, message )
	char *program;			/* Program name			*/
	char *filename;			/* File name			*/
	char *message;			/* Message to display		*/
{
	char	buf[1024];

	sprintf( buf, "%s: %s: %s", program, filename, message );
	outputDlgConcat( buf );
	return ( 0 );
}




/*
 *  FUNCTION
 *	ImXToolsOpen	-  open a file/stream & get its format
 *
 *  DESCRIPTION
 *	Open a file checking to make sure that the format passed is 
 *	correct, or that the format can be detected.
 *
 */
public FILE *				/* Returns open file pointer	*/
ImXToolsOpen( fileName, flags, format, actualFileName, actualFormat )
	char *fileName;			/* Name of file to open		*/
	char *flags;			/* Open flags			*/
	char *format;			/* File format to use (if any)	*/
	char *actualFileName;		/* Processed file name		*/
	char *actualFormat;		/* Processed file format	*/
{
	FILE *fp;			/* File pointer			*/
	char buf[1024];

	/*
	 *  Open the file.
	 */
	strcpy( actualFileName, fileName );
	if ( (fp = fopen( fileName, flags )) == NULL )
	{
		sprintf( buf, "Cannot open '%s', Skipping.\n", fileName );
		outputDlgConcat( buf );
		return( NULL );
	}


	/*
	 *  Figure out what format we've got, if not given explicitly.
	 */
	if ( (format == NULL || *format == '\0') &&
		(format = ImFileQFFormat( fp, fileName )) == NULL )
	{
		sprintf( buf, "Cannot determine file format for '%s', Skipping.\n", fileName );
		outputDlgConcat( buf );
		return( NULL );
	}
	strcpy( actualFormat, format );
	return ( fp );
}







/*
 *  FUNCTION
 *	ImXToolsFileRead	-  read in an image file
 *
 *  DESCRIPTION
 *	The file is opened.  The flags table is updated to include the
 *	name of the file.  The file is read in, and then closed.  Data
 *	read in is returned to the caller.
 */

public int				/* Returns nothing		*/
ImXToolsFileRead( filename, format, flags, data )
	char     *filename;		/* Input file name		*/
	char     *format;		/* File format			*/
	TagTable *flags;		/* Read flags			*/
	TagTable *data;			/* Where to put the data	*/
{
	FILE		*fp;			/* File pointer		*/
	char		tmpFilename[1024];	/* Tmp string pointer	*/
	char		tmpFormat[1024];	/* Tmp format name	*/
	char		buf[1024];
	Widget		child;


	/*
	 *  Open the file.
	 *
	 *  'filename' is the name of the file, as given on the command-line.
	 *  If this is a '-', then we'll open stdin.  In this case the filename
	 *  returned by ImToolsOpen() will be different from that given.
	 *  
	 *  'format' is the image file format of the file, as given on the
	 *  command-line.  If not given at all, 'format' will be a '\0' string.
	 */
	fp = ImXToolsOpen( filename, "r", format, tmpFilename, tmpFormat );
	if ( fp == NULL )
		return( 1 );


	/*
	 *  If we're being verbose, tell the user what we've got.
	 */
	if ( ImToolsVerbose )
	{
		sprintf( buf, "Reading '%s' using format '%s'\n",
			tmpFilename, tmpFormat );

		outputDlgConcat( buf );
	}



	/*
	 *  Update the flags table to include the name of the file we're
	 *  reading.
	 */
	if ( flags != TAGTABLENULL )
		ImToolsChangeTagEntry( flags, "file name", tmpFilename );


	/*
	 *  Read in the file (might be stdin).
	 */
	if ( ImFileFRead( fp, tmpFormat, flags, data ) == -1 )
	{
		sprintf( buf, "Read failed\n" );
		outputDlgConcat( buf );

		return( 1 );
	}


	/*
	 *  Close the file, if not stdin.
	 */
	if ( fp != stdin )
		fclose( fp );
	return( 0 );
}





/*
 *  FUNCTION
 *	ImXToolsFileWrite	-  write out an image file
 *
 *  DESCRIPTION
 *	The file is opened.  The flags table is updated to include the
 *	name of the file.  The file is written out, and then closed.
 */

public int				/* Returns nothing		*/
ImXToolsFileWrite( filename, format, flags, data )
	char    *filename;		/* Output file name		*/
	char    *format;		/* File format			*/
	TagTable *flags;		/* Write flags			*/
	TagTable *data;			/* Where to get the data	*/
{
	FILE     *fp;			/* File pointer			*/
	char      tmpFilename[1024];	/* Tmp string pointer		*/
	char      tmpFormat[1024];	/* Tmp format name		*/
	char	  buf[1024];

	/*
	 *  Open the file.
	 *
	 *  'filename' is the name of the file, as given on the command-line.
	 *  If this is a '-', then we'll open stdout.  In this case the filename
	 *  returned by ImToolsOpen() will be different from that given.
	 *  
	 *  'format' is the image file format of the file, as given on the
	 *  command-line.  If not given at all, 'format' will be a '\0' string.
	 */
	fp = ImXToolsOpen( filename, "w", format, tmpFilename, tmpFormat );
	if ( fp == NULL )
		return( 1 );


	/*
	 *  If we're being verbose, tell the user what we've got.
	 */
	if ( ImToolsVerbose )
	{
		sprintf( buf, "Writing '%s' using format '%s'\n",
			tmpFilename, tmpFormat );

		outputDlgConcat( buf );
	}


	/*
	 *  Update the flags table to include the name of the file we're
	 *  writing.
	 */
	if ( flags != TAGTABLENULL )
		ImToolsChangeTagEntry( flags, "file name", tmpFilename );


	/*
	 *  Write the file.
	 *
	 *  The image tool's standard error handler handles most errors by
	 *  simply printing them to stderr.  Some errors, however, have
	 *  rather brief default error messages.  These are handled specially
	 *  here.
	 */
	if ( ImFileFWrite( fp, tmpFormat, flags, data ) == -1 )
	{
		switch ( ImErrNo )
		{
		case IMENOTPOSSIBLE:
			sprintf( buf, "The %s format cannot support the output force options given.\n", tmpFormat );
			outputDlgConcat( buf );
			sprintf( buf, "You can get a list of what the format can support\n" );
			outputDlgConcat( buf );
			sprintf( buf, "by looking at the %s Image Format Help screen.\n", tmpFormat );
			outputDlgConcat( buf );
			if ( strcmp( tmpFilename, "stdout" ) != 0 )
				unlink( tmpFilename );
			return( 1 );

		case IMEMANYVFB:
			sprintf( buf, "The input file contained multiple images, however the\n" );
			outputDlgConcat( buf );
			sprintf( buf, "output %s format can only support 1 image per file.\n", tmpFormat );
			outputDlgConcat( buf );
			sprintf( buf, "Use the 'imsplit' tool to split the input file into\n" );
			outputDlgConcat( buf );
			sprintf( buf, "multiple output files before converting to the %s format.\n", tmpFormat );
			outputDlgConcat( buf );
			if ( strcmp( tmpFilename, "stdout" ) != 0 )
				unlink( tmpFilename );
			return( 1 );

		case IMENOVFB:
			sprintf( buf, "The input file contained no images suitable for output\n" );
			outputDlgConcat( buf );
			sprintf( buf, "in the %s format.\n", tmpFormat );
			outputDlgConcat( buf );
			if ( strcmp( tmpFilename, "stdout" ) != 0 )
				unlink( tmpFilename );
			return( 1 );

		default:
			sprintf( buf, "Write failed\n" );
			outputDlgConcat( buf );
			if ( strcmp( tmpFilename, "stdout" ) != 0 )
				unlink( tmpFilename );
			return( 1 );
		}
	}


	/*
	 *  Close the file, if not stdout.
	 */
	if ( fp != stdout )
		fclose( fp );
	return( 0 );
}
