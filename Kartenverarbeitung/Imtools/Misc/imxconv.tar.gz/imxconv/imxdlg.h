/**	$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxdlg.h,v 1.4 93/09/27 12:07:11 secoskyj Exp $
 **	Copyright (c) 1989-1992  San Diego Supercomputer Center (SDSC)
 **		San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

/**
 **  FILE
 **	imxdlg.h	- imxdlg.c forward declarations
 **
 **  PROJECT
 **	IM		- Image Manipulation Tools
 **
 **  DESCRIPTION
 **	Forward declarations for imxdlg.c routines
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **	outputDlgDB		f	output dialog callback when OK pressed
 **	CreateOutputDlg		f	create output dialog box
 **	outputDlgOKButtonCtrl	f	sensitize or desensitize OK button
 **	outputDlgConcat		f	concat a string into the text widget
 **	outputDlgClr		f	clear the output dialog text widget
 **	CreateQuestDlg		f	create a question dialog box
 **	manageQuestDlg		f	manage question dialog with a message
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	imxdlg.h,v $
 **	Revision 1.4  93/09/27  12:07:11  secoskyj
 **	Added function prototypes (forward declarations) for text dialog 
 **	support functions
 **	
 **	Revision 1.3  93/07/22  12:52:40  secoskyj
 **	Removed forward declarations for old message
 **	dialog routines and added declarations for
 **	new message dialog routiens
 **	
 **	Revision 1.2  93/07/19  16:36:35  secoskyj
 **	removed HEADER definition
 **	
 **	Revision 1.1  93/07/19  16:19:36  secoskyj
 **	Initial revision
 **	
 **	Revision 1.1  93/07/19  16:06:19  secoskyj
 **	Initial revision
 **	
 **	
 **/

void		outputDlgCB( );
Widget 		CreateOutputDlg( );
void		outputDlgOKButtonCtrl( );
void		outputDlgConcat( );
void		outputDlgClr( );
void		outputDlgStatusSet( );
void		outputDlgManage( );

Widget		CreateImXDlg( );
void		manageImXDlg( );

Widget		CreateTextDlg( );
void		textDlgConcat( );
