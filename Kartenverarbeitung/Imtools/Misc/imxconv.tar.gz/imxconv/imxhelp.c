/**	$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxhelp.c,v 1.1 93/09/27 12:12:36 secoskyj Exp $
 **	Copyright (c) 1989-1992  San Diego Supercomputer Center (SDSC)
 **		San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER  "$Header: /sdsc/dev/vis/image/imtools/v2.2/imxconv/src/RCS/imxhelp.c,v 1.1 93/09/27 12:12:36 secoskyj Exp $"

/**
 **  FILE
 **	imxhelp.c	- Help Dialog control function
 **
 **  PROJECT
 **	IM		- Image Manipulation Tools
 **
 **  DESCRIPTION
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **	main		f  main program
 **
 **  PRIVATE CONTENTS
 **	OK_BUTTON_HEIGHT	d	Height of OK button in outputDlg
 **
 **  HISTORY
 **	$Log:	imxhelp.c,v $
 **	Revision 1.1  93/09/27  12:12:36  secoskyj
 **	Initial revision
 **	
 **	
 **	
 **/

#include <stdio.h>
#include <string.h>

#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#include <Xm/Xm.h>
#include <Xm/PushB.h>
#include <Xm/Form.h>
#include <Xm/Text.h>
#include <Xm/MessageB.h>
#include <Xm/TextF.h>
#include <Xm/Label.h>
#include <Xm/List.h>
#include <Xm/Separator.h>

#include "im.h"

#define HELPDLG_OFFSET		(15)
#define BUTTON_HEIGHT		(30)
#define BUTTON_WIDTH		(110)
#define OK_BUTTON_OFFSET	(BUTTON_HEIGHT + 4 * HELPDLG_OFFSET)
#define SMALL_OFFSET		(5)

void		listFillImForm( );
Widget		helpDlg, convParamDlg;
Widget		helpText, helpFormatList;
Widget		helpOutOptsDlg, helpOutOptsText;

public
char *helpOutOptsStr = "\
Alpha: \n\
	On:	Forces storage of an alpha plane \n\
	Off:	Blocks storage of an alpha plane \n\
\n\
	The default is to store an alpha place if the image has one\n\
\n\
Color Table:\n\
	On:	Forces storage of a color table\n\
	Off:	Blocks storage of a color table\n\
\n\
	The default is to store a color table if the image to be \n\
	stored has one\n\
\n\
Compression:\n\
	None:		Do not compress\n\
	RLE:		Use Run-Length Encoded compression\n\
	PackBits:	Use Macintosh PackBits compression\n\
	LZW:		Use Limpel-Ziv Welsh compression\n\
	DCT:		Currently Unsupported\n\
\n\
	Not all formats support all schemes.  The default is the best\n\
	or most widly used compression scheme supported by the \n\
	format.\n\
\n\
Channels:\n\
	The number of channels to store in the output image.\n\
\n\
Channel Depth:\n\
	The number of bits per channel.  The default is the best match\n\
	to the image to be stored.\n\
\n\
Type:\n\
	Index:		Forces storage of the image as color indexes\n\
			(pseudo-color)\n\
	RGB:		Forces storage of the image as RGB color values\n\
			(true-color)\n\
	2D Geometry:	Currently Unsupported\n\
\n\
Interleaving:\n\
	Forces the use of an RGB interleaving scheme.\n\
\n\
	None:	Do not innterleave\n\
		(RGBRGBRGBRGBRGB...)\n\
	Line:	Use scanline interleaving\n\
		(RRR...GGG...BBB...RRR...GGG...)\n\
	Plane:	Use plane interleaving\n\
		(RRRRRR...GGGGGG...BBBBBB...)\n\
\n\
	Interleave only applies to RGB image storage.  Not all formats\n\
	support all schemes.  The default is the best or most widly used\n\
	scheme supported by the format.\n\
";



/*
 *  FUNCTION
 *	helpDlgCB	- unmange helpDlg when OK button pressed
 *
 *  PARAMETERS
 *	Standard Motif callback parameters
 *
 *  DESCRIPTION
 *	This is the callback when the OK button in the helpDlg is pressed.
 *	Right now it just unmanages the dialog box.
 *
 */
private void
helpDlgCB( w, client_data, call_data )
	Widget 	w;
	caddr_t	client_data;
	caddr_t	call_data;
{
	XtUnmanageChild( helpDlg );
}



public void
helpDlgManage( fmt )
	char *fmt;
{
	Arg		al[5];
	int		ac;
	Boolean		res;
	int		i;
	XmStringTable	*typeXSel;
	char		*typeSel;
	char		*firstSpace;

	if ( fmt == NULL )
	{
		XmListSelectPos( helpFormatList, 1, True );
		XmListSetPos( helpFormatList, 1 );
	}
	else
	{
		ac = 0;
		XtSetArg( al[ac], XmNitems, &typeXSel ); ac++;
		XtSetArg( al[ac], XmNitemCount, &i ); ac++;
		XtGetValues( helpFormatList, al, ac );

		res = FALSE;
		for ( i = i - 1 ; i >= 0; i-- )
		{
			XmStringGetLtoR( (XmString) typeXSel[i], 
					XmSTRING_DEFAULT_CHARSET, &typeSel );

			firstSpace = NULL;
			firstSpace = strchr( typeSel, ' ' );
			if ( firstSpace == NULL )
			{	
				fprintf( stderr,
					"Bad help image type string.\n" );
				exit( 1 );
			}

			firstSpace[0] = '\0';

			if ( !strcmp( typeSel, fmt ) )
			{
				res = TRUE;
				break;
			}

			XtFree( typeSel );
		}

		/*
		 *  If a valid position was found, then select that help
		 *  item and display the help on that format.
		 *  If not, then select the first format for help
		 */
		if ( res == TRUE )
		{
			XmListSelectPos( helpFormatList, i+1, True );
			XmListSetPos( helpFormatList, i+1 );
		}
		else
		{
			XmListSelectPos( helpFormatList, 1, True );
			XmListSetPos( helpFormatList, 1 );
		}
	}

	XtManageChild( helpDlg );
}


private void
helpDlgConcat( str )
	char *str;
{
	int	end;

	end = XmTextGetLastPosition( helpText );
	XmTextInsert( helpText, end, str );
	end = XmTextGetLastPosition( helpText );
	XmTextShowPosition( helpText, 0 );
	XmUpdateDisplay( helpDlg );
}


private void
helpDlgClr( )
{
	XmTextSetString( helpText, "" );
}


private int
helpTextPrint( pFmt )
	ImFileFormat *pFmt;
{
	ImFileFormatReadMap 	*pRead;
	ImFileFormatWriteMap 	*pWrite;
	char			**pNames;
	char			buffer[10240];
	char			tmpStr[128];

	helpDlgClr( );

	buffer[0] = '\0';

	sprintf( tmpStr, "%-7s %s\n", pFmt->format_names[0],
		pFmt->format_help );
	strcat( buffer, tmpStr );

	pNames = &pFmt->format_names[1];
	if ( pNames != NULL && *pNames != NULL )
	{
		sprintf( tmpStr, "        a.k.a.:   %s",
			*pNames++ );
		for ( ; *pNames; pNames++ )
		{
			if ( (strlen( tmpStr )+2+strlen( *pNames )) >80)
			{
				sprintf( tmpStr, "%s,\n", tmpStr );
				strcat( buffer, tmpStr );
				strcpy( tmpStr, "          " );
			}
			else
				strcat( tmpStr, ", " );
			strcat( tmpStr, *pNames );
		}
		sprintf( tmpStr, "%s\n", tmpStr );
		strcat( buffer, tmpStr );
	}

	sprintf( tmpStr, "        Creator:  %s\n", pFmt->format_creator );
	strcat( buffer, tmpStr );

	strcat( buffer, "\n" );
	strcat( buffer, "Read support:\n" );
	pRead = pFmt->format_readMap;
	if ( pRead == NULL )
		strcat( buffer, "        None.\n" );
	else
	{
		strcat( buffer, "        Type   #chan  #bits  CLT?  Alpha?  Compression  Interleaving\n" );
		strcat( buffer, "        -----  -----  -----  ----  ------  -----------  -----------\n" );
		for ( ; pRead->map_inType != -1; pRead++ )
		{
			strcat( buffer, "        " );
			switch ( pRead->map_inType )
			{
			case IMTYPEINDEX:
				strcat( buffer, "index " );
				break;
			case IMTYPERGB:	
				strcat( buffer, "rgb   " );
				break;
			case IMTYPE2D:	
				strcat( buffer, "2D geometry\n" );
				continue;
			default:
				strcat( buffer, "unknown?\n" );
				continue;
			}
			sprintf( tmpStr, " %-5d  %-5d", pRead->map_inNChannels,
				pRead->map_inChannelDepth );
			strcat( buffer, tmpStr );

			if ( pRead->map_inAttributes & IMCLTYES )
				strcat( buffer, "  yes " );
			else
				strcat( buffer, "  no  " );
			if ( pRead->map_inAttributes & IMALPHAYES )
				strcat( buffer, "  yes    " );
			else
				strcat( buffer, "  no     " );
			switch ( pRead->map_inAttributes & IMCOMPMASK )
			{
			case IMCOMPNO:	strcat( buffer, " none       " ); break;
			case IMCOMPRLE:	strcat( buffer, " RLE        " ); break;
			case IMCOMPLZW:	strcat( buffer, " LZW        " ); break;
			case IMCOMPPB:	strcat( buffer, " PackBits   " ); break;
			case IMCOMPDCT:	strcat( buffer, " DCT        " ); break;
			}
			switch ( pRead->map_inAttributes & IMINTERMASK )
			{
			case IMINTERNO:
				strcat( buffer, "  none" );
				break;
			case IMINTERLINE:
				strcat( buffer, "  scanline" );
				break;
			case IMINTERPLANE:
				strcat( buffer, "  plane" );
				break;
			}
			strcat( buffer, "\n" );
		}
	}

	strcat( buffer, "\n" );
	strcat( buffer, "Write support:\n" );
	pWrite = pFmt->format_writeMap;
	if ( pWrite == NULL )
		strcat( buffer, "        None.\n" );
	else
	{
		strcat( buffer, "        Type   #chan  #bits  CLT?  Alpha?  Compression  Interleaving\n" );
		strcat( buffer, "        -----  -----  -----  ----  ------  -----------  -----------\n" );
		for ( ; pWrite->map_outType != -1; pWrite++ )
		{
			strcat( buffer, "        " );
			switch ( pWrite->map_outType )
			{
			case IMTYPEINDEX:
				strcat( buffer, "index " );
				break;
			case IMTYPERGB:	
				strcat( buffer, "rgb   " );
				break;
			case IMTYPE2D:	
				strcat( buffer, "2D geometry\n" );
				continue;
			default:
				strcat( buffer, "unknown?\n" );
				continue;
			}
			sprintf( tmpStr, " %-5d  %-5d",
				pWrite->map_outNChannels,
				pWrite->map_outChannelDepth );
			strcat( buffer, tmpStr );

			if ( pWrite->map_outAttributes & IMCLTYES )
				strcat( buffer, "  yes " );
			else
				strcat( buffer, "  no  " );
			if ( pWrite->map_outAttributes & IMALPHAYES )
				strcat( buffer, "  yes    " );
			else
				strcat( buffer, "  no     " );
			switch ( pWrite->map_outAttributes & IMCOMPMASK )
			{
			case IMCOMPNO:	strcat( buffer, " none       " ); break;
			case IMCOMPRLE:	strcat( buffer, " RLE        " ); break;
			case IMCOMPLZW:	strcat( buffer, " LZW        " ); break;
			case IMCOMPPB:	strcat( buffer, " PackBits   " ); break;
			case IMCOMPDCT:	strcat( buffer, " DCT        " ); break;
			}
			switch ( pWrite->map_outAttributes & IMINTERMASK )
			{
			case IMINTERNO:
				strcat( buffer, "  none" );
				break;
			case IMINTERLINE:
				strcat( buffer, "  scanline" );
				break;
			case IMINTERPLANE:
				strcat( buffer, "  plane" );
				break;
			}
			strcat( buffer, "\n" );
		}
	}

	strcat( buffer, "\n" );
	helpDlgConcat( buffer );
	return ( 0 );
}




private void
helpTypeSelCB( w, client_data, call_data )
	Widget w;
	caddr_t client_data;
	caddr_t call_data;
{
	ImFileFormat 		**ppFmt;
	char			*pName, **pNames;
	XmListCallbackStruct	*cb;
	char			helpFileExt[32];
	char			*helpType, *firstSpace;

	cb = (XmListCallbackStruct *) call_data;

	XmStringGetLtoR( cb->item, XmSTRING_DEFAULT_CHARSET,
		&helpType );
	
	firstSpace = NULL;
	firstSpace = strchr( helpType, ' ' );
	if ( firstSpace == NULL )
	{	
		fprintf( stderr, "Bad help image type string.\n" );
		exit( 1 );
	}

	firstSpace[0] = '\0';
	strcpy( helpFileExt, helpType );
	XtFree( helpType );

	for ( ppFmt = ImFileFormats; *ppFmt; ppFmt++ )
	{
		pNames = &(*ppFmt)->format_names[0];
		for ( ; *pNames; pNames++ )
		{
			if ( strcmp( *pNames, helpFileExt ) == 0 )
			{
				helpTextPrint( *ppFmt );
				break;
			}
		}
		if ( *pNames )
			break;
	}
}



/*
 *  FUNCTION
 *	CreateHelpDlg	- create help dialog box
 *
 *  PARAMETERS
 *	Widget parent	- the parent widget to the helpDlg dialog box.
 *
 *  DESCRIPTION
 *	This routine constructs the conversion help dialog box.
 *	Returns a Widget that represents the help dialog box.
 *
 */
public Widget
CreateHelpDlg( parent )
	Widget parent;
{
	Arg		al[15];
	int		ac;
	Widget		dlg;
	Widget		helpFormatForm;
	Widget		helpFormatLabel;
	Widget		helpOKButton;
	Widget		helpTextForm, helpTextLabel;
	Widget		helpSeparator;
	XmString	labelXStr;

	/*
	 *  Create dialog to hold the help information
	 */
	ac = 0;
	XtSetArg( al[ac], XmNtitle, "Format Help" ); ac++;
	XtSetArg( al[ac], XmNhorizontalSpacing, HELPDLG_OFFSET ); ac++;
	XtSetArg( al[ac], XmNverticalSpacing, HELPDLG_OFFSET ); ac++;
	XtSetArg( al[ac], XmNautoUnmanage, False ); ac++;
	dlg = XmCreateFormDialog( parent, "outputDlg",
		al, ac );

	/*
	 *  Create a form to hold the format list and associated labels
	 */
	ac = 0;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomOffset, OK_BUTTON_OFFSET ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 38 ); ac++;
	helpFormatForm = XmCreateForm( dlg, "formatForm", al, ac );


	/*
	 *  Create label for File Formats:
	 */
	ac = 0;
	labelXStr = XmStringCreateLtoR( "Supported Image Formats:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	helpFormatLabel= XmCreateLabel( helpFormatForm, "formatLabel", al, ac );
	XtManageChild( helpFormatLabel );
	XmStringFree( labelXStr );

	/*
	 *  Create list to hold the format types
	 */
	ac = 0;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlistSizePolicy, XmCONSTANT ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, helpFormatLabel ); ac++;
	XtSetArg( al[ac], XmNtopOffset, SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNvisibleItemCount, 20 ); ac++;
	XtSetArg( al[ac], XmNscrollBarDisplayPolicy, XmAS_NEEDED ); ac++;
	helpFormatList = XmCreateScrolledList( helpFormatForm, "formatList",	
				al, ac);
	XtManageChild( helpFormatList );

	listFillImForm( helpFormatList, *ImFileFormats, False );

	XtManageChild( helpFormatForm );


	/*
	 *  Create a form to hold the format help and assoc. label
	 */
	ac = 0;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomOffset, OK_BUTTON_OFFSET ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 40 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	helpTextForm = XmCreateForm( dlg, "formatForm", al, ac );


	/*
	 *  Create label for Help Text:
	 */
	ac = 0;
	labelXStr = XmStringCreateLtoR( "Format Support:",
			XmSTRING_DEFAULT_CHARSET );
	XtSetArg( al[ac], XmNalignment, XmALIGNMENT_BEGINNING ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	helpTextLabel = XmCreateLabel( helpTextForm, "textLabel", al, ac );
	XtManageChild( helpTextLabel );
	XmStringFree( labelXStr );

	/*
	 *  Create verbose output text area
	 */
	ac = 0;
	XtSetArg( al[ac], XmNtopAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNtopWidget, helpTextLabel ); ac++;
	XtSetArg( al[ac], XmNtopOffset, SMALL_OFFSET ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNresizeHeight, True ); ac++;
	XtSetArg( al[ac], XmNresizeWidth, True ); ac++;
	XtSetArg( al[ac], XmNeditMode, XmMULTI_LINE_EDIT ); ac++;
	XtSetArg( al[ac], XmNeditable, False ); ac++;
	XtSetArg( al[ac], XmNrows, 20 ); ac++;
	XtSetArg( al[ac], XmNcolumns, 60 ); ac++;
	XtSetArg( al[ac], XmNscrollHorizontal, True ); ac++;
	XtSetArg( al[ac], XmNscrollVertical, True ); ac++;
	helpText = XmCreateScrolledText( helpTextForm, "helpText", al, ac );
	XtManageChild( helpText );

	XtManageChild( helpTextForm );

	/*
	 *  Create OK button to unmange the dialog
	 */
	labelXStr = XmStringCreateLtoR( "OK", XmSTRING_DEFAULT_CHARSET );
	ac = 0;
	XtSetArg( al[ac], XmNlabelString, labelXStr ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_FORM ); ac++;
	XtSetArg( al[ac], XmNbottomOffset, HELPDLG_OFFSET + 5 ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 45 ); ac++;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 55 ); ac++;
	XtSetArg( al[ac], XmNheight, BUTTON_HEIGHT ); ac++;
	XtSetArg( al[ac], XmNshowAsDefault, 1 ); ac++;
	helpOKButton = XmCreatePushButton( dlg, "helpOKButton",
				al, ac );
	XtManageChild( helpOKButton );
	XtAddCallback( helpOKButton, XmNactivateCallback, helpDlgCB, NULL );
	XmStringFree( labelXStr );

	XtAddCallback( helpFormatList, XmNbrowseSelectionCallback,
			helpTypeSelCB, NULL );

	/*
	 *  Create separator just between ok button and text widget
	 */
	ac = 0;
	XtSetArg( al[ac], XmNrightAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNrightPosition, 100 ); ac++;
	XtSetArg( al[ac], XmNleftAttachment, XmATTACH_POSITION ); ac++;
	XtSetArg( al[ac], XmNleftPosition, 0 ); ac++;
	XtSetArg( al[ac], XmNbottomAttachment, XmATTACH_WIDGET ); ac++;
	XtSetArg( al[ac], XmNbottomWidget, helpOKButton ); ac++;
	XtSetArg( al[ac], XmNbottomOffset, 2 * HELPDLG_OFFSET / 2 ); ac++;
	helpSeparator = XmCreateSeparator( dlg, "helpDlgSeparator", al, ac );
	XtManageChild( helpSeparator );

	return( dlg );
}
