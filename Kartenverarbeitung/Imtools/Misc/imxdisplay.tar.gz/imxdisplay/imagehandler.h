/****************************************************************************
 * imagehandler.h
 * Author Joel Welling
 * Copyright 1993, Pittsburgh Supercomputing Center, Carnegie Mellon University
 *
 * Permission use, copy, and modify this software and its documentation
 * without fee for personal use or use within your organization is hereby
 * granted, provided that the above copyright notice is preserved in all
 * copies and that that copyright and this permission notice appear in
 * supporting documentation.  Permission to redistribute this software to
 * other organizations or individuals is not granted;  that must be
 * negotiated with the PSC.  Neither the PSC nor Carnegie Mellon
 * University make any representations about the suitability of this
 * software for any purpose.  It is provided "as is" without express or
 * implied warranty.
 *****************************************************************************/

/**
 **	$Header: /sdsc/dev/vis/image/ihandler/src/RCS/imagehandler.h,v 1.2 94/03/23 18:08:01 secoskyj Exp $
 **	Copyright (c) 1989-1994  San Diego Supercomputer Center (SDSC)
 **		a division of General Atomics, San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/


/**
 **  FILE
 **	imagehander.h	-  
 **
 **  PROJECT
 **	IM		-  
 **
 **  DESCRIPTION
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	imagehandler.h,v $
 **	Revision 1.2  94/03/23  18:08:01  secoskyj
 **	Removed HEADER definition
 **	
 **	Revision 1.1  94/03/23  17:36:39  secoskyj
 **	Initial revision
 **	
 **	
 **/


class baseImageHandler { 
public:
  baseImageHandler();
  virtual ~baseImageHandler();
  virtual void display( rgbImage *image , short refresh=1)= 0;
  rgbImage *last_image() {return(current_image);};
protected:
  rgbImage *current_image;
};

class fileImageHandler : public baseImageHandler {
public:
  fileImageHandler( char *fname_in, char *format_in );
  ~fileImageHandler();
  void display( rgbImage *image, short refresh=1);
protected:
  char *fname;
  char *format;
};
