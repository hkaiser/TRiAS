/*****************************************************************************
 * m-anim.cc for pvm 2.4
 * Author Robert Earhart
 * Copyright 1993, Pittsburgh Supercomputing Center, Carnegie Mellon University
 *
 * Permission use, copy, and modify this software and its documentation
 * without fee for personal use or use within your organization is hereby
 * granted, provided that the above copyright notice is preserved in all
 * copies and that that copyright and this permission notice appear in
 * supporting documentation.  Permission to redistribute this software to
 * other organizations or individuals is not granted;  that must be
 * negotiated with the PSC.  Neither the PSC nor Carnegie Mellon
 * University make any representations about the suitability of this
 * software for any purpose.  It is provided "as is" without express or
 * implied warranty.
 *****************************************************************************/

/**
 **	$Header: /sdsc/dev/vis/image/imtools/v3.0/imxdisplay/src/RCS/imxdisplay.cc,v 1.7 94/06/30 17:01:37 secoskyj Exp $
 **	Copyright (c) 1989-1994  San Diego Supercomputer Center (SDSC)
 **		a division of General Atomics, San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER  "$Header: /sdsc/dev/vis/image/imtools/v3.0/imxdisplay/src/RCS/imxdisplay.cc,v 1.7 94/06/30 17:01:37 secoskyj Exp $"

/**
 **  FILE
 **	imxdisplay.cc	-  
 **
 **  PROJECT
 **	IM		-  
 **
 **  DESCRIPTION
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	imxdisplay.cc,v $
 **	Revision 1.7  94/06/30  17:01:37  secoskyj
 **	Changed version number from 2.0 to 3.0
 **	
 **	Revision 1.6  94/06/30  15:00:02  secoskyj
 **	Command line completed with help screens and -frames option
 **	Three different 8-bit display options completed
 **	Help screens set up so that better text messages may be entered
 **	  at a later date.
 **	Name changed from m-anim to imxdisplay
 **	Filename and ratio complete displayed when loading images
 **	Dithering can use larger std colormaps if available (up to 6x6x6)
 **	Action/Animation buttons filled in
 **	File Open menu item created and greyed out
 **	Changed default delay time form 0ms to 60ms so that the interface
 **	  is more reactive to user commands at startup
 **	
 **	Revision 1.5  94/05/27  20:00:04  secoskyj
 **	More robustly working with switching btwn dither and perfect color
 **	
 **	Revision 1.4  94/05/18  10:10:51  secoskyj
 **	Working for pseudocolor with colormaps changing, leave and enter window
 **	notify changes colormap.  One problem, need to store default colormap
 **	to restore it when leave m-anim window.
 **	
 **	Revision 1.3  94/03/23  23:45:57  secoskyj
 **	Removed one fprintf debug message
 **	
 **	Revision 1.2  94/03/23  18:14:54  secoskyj
 **	int argc -> unsigned argc in main()
 **	
 **	Revision 1.1  94/03/23  17:32:57  secoskyj
 **	Initial revision
 **	
 **	
 **/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <X11/keysym.h>
#include <X11/cursorfont.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/FileSB.h>
#include <Xm/CascadeB.h>
#include <Xm/CascadeBG.h>
#include <Xm/DialogS.h>
#include <Xm/DrawingA.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/MainW.h>
#include <Xm/MenuShell.h>
#include <Xm/MessageB.h>
#include <Xm/MwmUtil.h>
#include <Xm/PushB.h>
#include <Xm/PushBG.h>
#include <Xm/RowColumn.h>
#include <Xm/ScrollBar.h>
#include <Xm/SeparatoG.h>
#include <Xm/Text.h>
#include <Xm/ToggleB.h>
#include <Xm/ToggleBG.h>

#include "playb.xbm"
#include "stop.xbm"
#include "playf.xbm"

#include <im.h>
#include "rgbimage.h"
#include "imagehandler.h"
#include "ximagehandler.h"


int SubVisual;
static char **toolInFilenames, **toolInFormats;
static int toolFrameStart, toolFrameEnd;
static int toolNInFiles;
extern Boolean okClt;
extern int initedClt;

#include "imtools.h"

static ArgCommand toolCommand =
{
	"imxdisplay",		/* command name			*/

	IMTOOLSMAJOR,		/* major version #		*/
	IMTOOLSMINOR,		/* minor version #		*/
	IMTOOLSSUBMINOR,	/* subminor version #		*/

	NULL,			/* -help pre-option list info	*/
	NULL,			/* -help post-option list info	*/
	NULL,			/* -fullhelp pre-option info	*/
	NULL,			/* -fullhelp post-option info	*/
	ARGFNONE,		/* don't output help msg on err	*/

	"[options...] infilename(s)",
	"[options...] infilename(s)",
	"SDSC Image Tools, May 1994.",
	"Copyright (c) 1989-1993  San Diego Supercomputer Center (SDSC), CA, USA",

	NULL,			/* registration info string	*/
	NULL			/* feedback info string		*/
};

static char *toolPreOptHelp = "\
%command displays and animates one or more images.\n\
";

char *toolBaseHelp =
"\n\
Image File Formats and Filenames:\n\
    By default, input and output file's image file formats are determined by\n\
    the file's magic number (input only), or the filename extension (like\n\
    .hdf for HDF files, or .pix for PIX files).\n\
\n\
    To override the default, explicit format names may precede the filename,\n\
    such as -hdf for an HDF file, or -pix for a PIX file.\n\
\n\
    A single dash ('-') for an input or output filename indicates stdin or\n\
    stdout.  When using stdin or stdout, an explicit format name is necessary.\n\
\n\
File Format Conversions and Supported Features\n\
    The Image Tools support a wide range of image file formats and their\n\
    variants.  Information on format support may be displayed by running the\n\
    tool 'imformats'.  Executed without any options, imformats displays a\n\
    short list of supported file formats.  Executed with the -long option,\n\
    imformats will show more information on what variants of the formats are\n\
    supported.  Executed with -long -long (given twice), a fully detailed\n\
    list of input and output support for the format is displayed.\n\
\n\
    Further information on each of the image file formats is available in the\n\
    man pages for each format.  For instance, to obtain information on support\n\
    of the TIFF file format, look at the 'imtiff' man page.\n\
";


static char *toolHelp = "\n\
Typical Invocations:\n\
	To display and animate all gif files in the current directory\n\
		imxdisplay *.gif\n\
\n\
	To display and animate files 0000.ras to 0009.ras\n\
		imxdisplay -frames 0-9 000%d.ras\n\
\n\
	To display and animate files fileA, fileB, and fileC which are\n\
	pix files\n\
		imxdisplay -pix fileA fileB fileC\n\
\n\
	To display file ditherMe.bmp dithered (8-bit visual only)\n\
		imxdisplay ditherMe.bmp -outdither\n\
\n\
	To display and animate files 0000.ras to 0009.ras and force\n\
	all to use 0000.ras's colortable (8-bit visuals only)\n\
		imxdisplay -frames 10 000%d.ras -outforce\n\
";

static char *toolFullHelp = "\n\
File options:\n\
    -infile selects the files to be included in the storyboard.\n\
\n\
    When listing input files explicitly, each input file name is given on\n\
    the command line.\n\
\n\
    Input files may be listed implicitly by giving a file name template with\n\
    an embedded %d (ala printf) where the frame number should be placed.\n\
    The -frames argument then gives a range of frame numbers to use for\n\
    input file names.\n\
\n\
Display options:\n\
	Only one of the following display options may be specified at a time\n\
	and are valid ONLY on 8-bit (pseudocolor) visuals.\n\
\n\
	-outdither	dithers the images when they are displayed\n\
	-outforce 	forces all images to use the first image's colormap\n\
	-outperfect 	images are displayed using their own colormap\n\
			(may flicker on playing an animation)\n\
";

static char *toolNote = "\n\
Additional Help:\n\
    This is an abbreviated help listing.  For a full listing of options,\n\
    including a list of image file formats supported, type:\n\
        %command -fullhelp\n\
";


#define TOOLNOPTIONS	6
static ArgOption toolOptions[TOOLNOPTIONS] =
{
	/*
	 *  File management CLI
	 */

	{ "infile", "image_filenames", "Specify input image file names",
	  ARGFREQUIRED|ARGFMULTIPLE|ARGFIMPKEYWORD, 1, 1, ARGTSTRING },

	{ "frames", "range", "Specify frame numbers of input files",
	  ARGFNONE , 1, 1, ARGTINT | ARGTRANGE },

	{ "outdither", NULL, "Display images dithered",
	  ARGFNONE, 0, 0, ARGTNONE },

	{ "outforce", NULL, "Display only with first image's colormap",
	  ARGFNONE, 0, 0, ARGTNONE },

	{ "outperfect", NULL, "Display with own colormap",
	  ARGFNONE, 0, 0, ARGTNONE },

	{ "verbose", NULL, "Be verbose",
	  ARGFFULLHELP, 0, 0, ARGTNONE },
};

#define TOOLNEQUIVS	0
#if TOOLNEQUIVS == 0
static ArgEquiv *toolEquivs;
#else
static ArgEquiv toolEquivs[TOOLNEQUIVS] =
{
};
#endif


static void toolInit( int argc, char *argv[] )
{
	int	    i, j, k;		/* Counters			*/
	int	    noccur;		/* Number of option occurrences	*/
	int         nOpt;		/* Number of options		*/
	int         nEquiv;		/* Number of equivalences	*/
	ArgOption  *options1;		/* Argument options		*/
	ArgOption  *options;		/* Argument options		*/
	ArgEquiv   *equivs1;		/* Argument equivalent keywords	*/
	ArgEquiv   *equivs;		/* Argument equivalent keywords	*/
        ArgValue   *value;              /* Argument value               */

	char       *tmp;		/* Temporary string holder	*/
	char       *tmpFormat;		/* Tmp format name		*/
	char	    tmpName[1024];	/* tmp space for filename	*/
	int         res;		/* temporary result holder	*/
	int	    nFrames;		/* number of frames		*/
	int	    oldToolNInFiles;	/* keep track if -frames used	*/
	char	  **tmpFilenames;
	char	  **tmpFormats;
	int	    frameFlag = 0;	/* marks if we saw a '%' 	*/

	/*
	 *  Save the name of the program, as invoked.
	 */
	ImToolsProgram = argv[0];


	/*
	 *  Use the standard Image Tools user registration and feedback forms.
	 */
	toolCommand.arg_register = ImToolsRegister;
	toolCommand.arg_feedback = ImToolsFeedback;


	/*
	 *  Allocate space for the total help string for the tool.  Copy the
	 *  tool-specific help in, then concatenate on the generic help text
	 *  used by most of the image tools.
	 */
	if ( (tmp = (char *)malloc( sizeof( char ) *
		(strlen( toolPreOptHelp ) + 1 ))) == NULL )
	{
		perror( ImToolsProgram );
		exit( 1 );
	}
	strcpy( tmp, toolPreOptHelp );
	toolCommand.arg_help1     = tmp;
	toolCommand.arg_fullhelp1 = tmp;

	if ( (tmp = (char *)malloc( sizeof( char ) * (strlen( toolNote ) +
		strlen( toolHelp ) + 1) )) == NULL )
	{
		perror( ImToolsProgram );
		exit( 1 );
	}
	strcpy( tmp, toolHelp );
	strcat( tmp, toolNote );
	toolCommand.arg_help2 = tmp;

	if ( (tmp = (char *)malloc( sizeof( char ) * (strlen( toolBaseHelp ) +
		strlen( toolHelp ) + strlen( toolFullHelp ) + 1) )) == NULL )
	{
		perror( ImToolsProgram );
		exit( 1 );
	}
	strcpy( tmp, toolHelp );
	strcat( tmp, toolFullHelp );
	strcat( tmp, toolBaseHelp );
	toolCommand.arg_fullhelp2 = tmp;


	/*
	 *  Build up an option list by merging the tool-specific options,
	 *  the standard (base) tool options, and those for the various
	 *  image file formats.
	 */
	nOpt = ImToolsMergeOptions( TOOLNOPTIONS, toolOptions,
		0, NULL, &options1 );
	if ( (nOpt = ImFileFormatOptions( nOpt, options1, &options )) == -1)
	{
		ImPError( ImToolsProgram );
		exit( 1 );
	}


	/*
	 *  Build up an equivalent keyword list by merging the tool-specific
	 *  equivalences, the standard (base) tool equivalences, and those
	 *  for the various image file formats.
	 */
	nEquiv = ImToolsMergeEquivs( TOOLNEQUIVS, toolEquivs,
		 IMTOOLSNBASEEQUIVS, ImToolsBaseEquivs, &equivs1 );
	if ( (nEquiv = ImFileFormatEquivs( nEquiv, equivs1, &equivs )) == -1)
	{
		ImPError( ImToolsProgram );
		exit( 1 );
	}


	/*
	 *  Parse the command line!
	 */
	nOpt = ArgParse( argc, argv, &toolCommand, nOpt, options,
		nEquiv, equivs );
	if ( ArgQNOccur( "verbose" ) != 0 )
		ImToolsVerbose = TRUE;

	/*
	 *  Check color space option
	 */

	/*
	 *  Do not need to check to see if one of the output options was 
	 *  entered more than once since this is handled by ArgParse()
	 */

	res = ArgQNOccur( "outforce" ) + ArgQNOccur( "outperfect" ) +
		ArgQNOccur( "outdither" );

	if ( res != 1 )
	{
		if ( res == 0 )
			SubVisual = XIH_VCUSTOM;
		else
		{
			fprintf( stderr, "%s: Cannot specify more than one output type.\n", ImToolsProgram );
			exit( 1 );
		}
	}
			

	if ( ArgQNOccur( "outforce" ) != 0 )
		SubVisual = XIH_VSHARED;

	if ( ArgQNOccur( "outperfect" ) != 0 )
		SubVisual = XIH_VCUSTOM;

	if ( ArgQNOccur( "outdither" ) != 0 )
		SubVisual = XIH_VPSEUDO;


	/*
	 *  Check if a number of frames were entered on command line
	 */

        toolFrameStart = toolFrameEnd = -1;
        if ( ArgQNOccur( "frames" ) != 0 )
        {
                value = ArgQValue( "frames", 0, 0 );
                switch ( value->arg_rform )
                {
                case ARGRCLOSED:        /* n-m  start and end values    */
                        toolFrameStart = value->arg_ir1;
                        toolFrameEnd   = value->arg_ir2;
                        break;

                case ARGROPEN:          /* n-   length only             */
			fprintf( stderr, "%s: Missing end of frame range on -frames option.\n", ImToolsProgram );
			exit( 1 );

                case ARGRSINGLE:        /* n    length only             */
			toolFrameStart = 0;
                        toolFrameEnd   = value->arg_i - 1;
                        break;
                }

		if ( toolFrameStart < 0 )
		{
			fprintf ( stderr, "%s: -frame start number must be positive.\n", ImToolsProgram );
			exit( 1 );
		}
		if ( toolFrameEnd < 0 )
		{
			fprintf ( stderr, "%s: -frame end number must be positive.\n", ImToolsProgram );
			exit( 1 );
		}
        }

	/*
	 *  Figure out the total number of frames
	 *  +1 is to include the last frame
	 */
	nFrames = abs( toolFrameStart - toolFrameEnd ) + 1;



	/*
	 *  Determine how many input files we've got and allocate space for
	 *  their names.
	 */
	toolNInFiles = 0;
	for ( j =0; j < ArgQNOccur( "infile" ); j++ )
		toolNInFiles += ArgQNValue( "infile", j );

	/*
	 *  allocate toolNInFiles+1 in order to interface with exisiting
	 *  animation software easily.  Othewise may get obscure off
	 *  by one errors when accessing filenames
	 */

	toolInFilenames = (char **)malloc( sizeof( char * ) * (toolNInFiles+1));
	if ( toolInFilenames == NULL )
	{
		perror( ImToolsProgram );
		exit( 1 );
	}
	toolInFilenames[0] = (char *)malloc( sizeof(char) * 
					(strlen( ImToolsProgram )+1) );
	strcpy( toolInFilenames[0], ImToolsProgram );

	toolInFormats = (char **)malloc( sizeof( char * ) * (toolNInFiles+1) );
	if ( toolInFormats == NULL )
	{
		perror( ImToolsProgram );
		exit( 1 );
	}
	toolInFormats[0] = "\0";


	/*
	 *  Get each input file's name (-infile), and search backwards in the
	 *  command-line option list to find the last format selection (if
	 *  any).  Stop the search on the beginning of the command-line.
	 */
	oldToolNInFiles = toolNInFiles;
	for ( k = 1; k < ArgQNOccur( "infile" ) + 1;k++ )
	{
		toolInFilenames[k] = ArgQValue( "infile", k-1, 0 )->arg_s;

		/*
		 *  If this filename will be expanded using -frames
		 *  option, then add nFrames to the total number of filenames
		 *  The -1 is to subtract out the %d file name.
		 */
		if ( strchr( toolInFilenames[k], '%' ) != NULL )
			toolNInFiles = toolNInFiles + nFrames - 1;

		tmpFormat = NULL;
		for ( i = ArgQOccurOpt( "infile", k-1 ) - 1; i >= 0; i-- )
		{
			tmp = ArgQOpt( i, &noccur );


			/*
			 *  Stop looking backward when we reach any other file
			 *  name argument.
			 */
			if ( strcmp( tmp, "infile" ) == 0 )
				break;


			/*
			 *  Skip it if it isn't the name of a file format.
			 */
			if ( !ImToolsIsFormat( tmp ) )
				continue;


			if ( tmpFormat != NULL )
			{
				fprintf( stderr, "%s:  Only 1 file format selection may precede -infile.\n", ImToolsProgram );
				exit( 1 );
			}
			tmpFormat = tmp;
		}
		toolInFormats[k] = (char *)malloc( sizeof( char ) * 1024 );
		if ( toolInFormats[k] == NULL )
		{
			perror( ImToolsProgram );
			exit( 1 );
		}

		if ( tmpFormat == NULL )
			toolInFormats[k] = "\0";
		else
			strcpy( toolInFormats[k], tmpFormat );
	}

	/*
	 *  Free up old spaced used if -frames option was used and
	 *  malloc up enough space to hold the -frames filenames.
	 *  Explode out the -frames filenames to create a cleaner 
	 *  interface with the argv, argc interface in the original
	 *  m-anim.
	 */
	if ( toolNInFiles == oldToolNInFiles )
		return;

	tmpFilenames = (char **)malloc( sizeof( char * ) * (toolNInFiles+1) );
	if ( tmpFilenames == NULL )
	{
		perror( ImToolsProgram );
		exit( 1 );
	}

	tmpFormats = (char **)malloc( sizeof( char * ) * (toolNInFiles+1) );
	if ( tmpFormats == NULL )
	{
		perror( ImToolsProgram );
		exit( 1 );
	}


	i = 0;
	for ( k = 0; k < ( oldToolNInFiles+1 ); k++ )
	{
		if ( strchr( toolInFilenames[k], '%' ) != NULL )
		{
			/*
			 *  Expand the filename
			 */

			if ( toolFrameStart < toolFrameEnd )
			{
				for ( j = toolFrameStart; j <= toolFrameEnd;
					j++ )
				{
					sprintf( tmpName,
						toolInFilenames[k], j );

					tmpFilenames[i] = (char *)
							malloc( sizeof(char)*
							strlen( tmpName ) + 1 );

					tmpFormats[i] = (char *)
						malloc( sizeof(char)*
						strlen( toolInFormats[k] ) + 1);

					strcpy( tmpFilenames[i], tmpName );
					strcpy( tmpFormats[i],
							toolInFormats[k] );
					i++;
				}
			}
			else
			{
				for ( j = 0; j <= toolFrameStart - toolFrameEnd;
					j++ )
				{
					sprintf( tmpName,
						toolInFilenames[k],
						toolFrameStart - j );

					tmpFilenames[i] = (char *)
							malloc( sizeof(char)*
							strlen( tmpName ) + 1 );

					tmpFormats[i] = (char *)
						malloc( sizeof(char)*
						strlen( toolInFormats[k] ) + 1);

					strcpy( tmpFilenames[i], tmpName );
					strcpy( tmpFormats[i],
							toolInFormats[k] );
					i++;
				}
			}
			frameFlag = 1;
		}
		else
		{
			tmpFilenames[i] = (char *) malloc( sizeof( char ) *
					(strlen( toolInFilenames[k] ) + 1) );
			tmpFormats[i] = (char *) malloc( sizeof( char )*
					(strlen( toolInFormats[k] ) + 1) );

			strcpy( tmpFilenames[i], toolInFilenames[k] );
			strcpy( tmpFormats[i], toolInFormats[k] );
			i++;
		}
	}

	if ( toolFrameEnd != -1 && frameFlag == 0 )
	{
		fprintf( stderr, "%s: -frames requires that input files include %%d in their names.\n", ImToolsProgram );
		exit( 1 );
	}

	for ( i = 0; i < oldToolNInFiles; i++ )
	{
		free( toolInFilenames[i] );
		free( toolInFormats[i] );
	}

	free( toolInFilenames );
	free( toolInFormats );
	toolInFilenames = tmpFilenames;
	toolInFormats = tmpFormats;

	return;
}



static void manage_meCB(Widget w, Widget client_data, caddr_t call_data)
{
    XtManageChild(client_data);
}
 
static void unmanageCB(Widget w, Widget me, caddr_t call_data)
{
    XtUnmanageChild(me);
}


static Widget works_init(Widget w)
{
    Arg args[20];
    register int n;
char *works_text = "\
 Imxdisplay  accepts a list of files, and loads them into your X server\n\
sequentially. It then allows you to scroll through them, or play\n\
them back in a movie like fashion.\n\
\n\
  Command line information can be obtained by executing imxdisplay -help\n\
\n\
  Enjoy! Questions/Comments should be sent to the email address\n\
\"info@sdsc.edu\".\n\
";
    
    XmString okText=XmStringCreateSimple("OK");
    XmString messageText=XmStringCreateLtoR(works_text,
              XmSTRING_DEFAULT_CHARSET);

    n=0;
    XtSetArg(args[n], XmNtitle, "How it Works"); n++;
    XtSetArg(args[n], XmNleftOffset, 2); n++;
    XtSetArg(args[n], XmNrightOffset, 2); n++;
    XtSetArg(args[n], XmNbottomOffset, 2); n++;
    XtSetArg(args[n], XmNokLabelString, okText); n++;
    XtSetArg(args[n], XmNdialogType, XmDIALOG_INFORMATION); n++;
    XtSetArg(args[n], XmNmessageString, messageText); n++;
    Widget message_box=XmCreateMessageDialog(w, "works", args, n);

    XmStringFree(okText);
    XmStringFree(messageText);

    Widget it;
    if (it=XmMessageBoxGetChild(message_box, XmDIALOG_HELP_BUTTON))
      XtUnmanageChild(it);
    if (it=XmMessageBoxGetChild(message_box, XmDIALOG_CANCEL_BUTTON))
      XtUnmanageChild(it);

    if (it=XmMessageBoxGetChild(message_box, XmDIALOG_OK_BUTTON)) {
	XtAddCallback(it, XmNactivateCallback,
		      (XtCallbackProc)unmanageCB, (XtPointer)message_box);

	n=0;
	XtSetArg(args[n], XmNdefaultButton, it); n++;
	XtSetValues(message_box, args, n);
    }
    return(message_box);
}
    
static Widget formats_init(Widget w)
{
    Arg 		args[20];
    register int 	n;
    char 		*top_text= "Supported formats are:";
    char 		*formats_text, *descrip_text;
    ImFileFormat 	**ppFmt;
    ImFileFormat	*pFmt;
    int			formatLen, descrLen, numFormats;
    int			formatPos, descrPos;

	/*
	 *  Figure out how much space we will need to store the strings
	 */

	formatLen = 0;
	descrLen = 0;
	numFormats = 0;
	for ( ppFmt = ImFileFormats; *ppFmt; ppFmt++ )
	{
		pFmt = *ppFmt;

		formatLen += strlen( pFmt->format_names[0] );
		descrLen += strlen( pFmt->format_help );
		numFormats++;
	}

	/*
	 *  numFormats in the malloc is to allow space for '\n' chars
	 */

	formats_text = (char *) malloc( sizeof( char ) *
				(formatLen + 1 + numFormats) );
	if ( formats_text == NULL )
	{
		fprintf( stderr, "Could not allocate space for format text\n" );
		exit( 1 );
	}

	descrip_text = (char *) malloc( sizeof( char ) *
				(descrLen + 1 + numFormats) );
	if ( descrip_text == NULL )
	{
		fprintf( stderr, "Could not allocate space for description text\n" );
		exit( 1 );
	}

	/*
	 *  Make two strings, one for the format names and another
	 *  for their descriptions.
	 */

	formatPos = 0;
	descrPos = 0;
	for ( ppFmt = ImFileFormats; *ppFmt; ppFmt++ )
	{
		pFmt = *ppFmt;

		sprintf( formats_text + formatPos, "%s\n", 
				pFmt->format_names[0] );
		sprintf( descrip_text + descrPos, "%s\n",
				pFmt->format_help );

		formatPos += strlen( pFmt->format_names[0] ) + 1;
		descrPos += strlen( pFmt->format_help ) + 1;
	}


    n=0;
    XtSetArg(args[n], XmNtitle, "Format List"); n++;
    Widget message_box=XmCreateFormDialog(w, "formats", args, n);

    n=0;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNeditable, False); n++;
    XtSetArg(args[n], XmNcursorPositionVisible, False); n++;
    XtSetArg(args[n], XmNeditMode, XmMULTI_LINE_EDIT); n++;
    XtSetArg(args[n], XmNvalue, top_text); n++;
    XtSetArg(args[n], XmNshadowThickness, 0); n++;
    XtSetArg(args[n], XmNtraversalOn, False); n++;
    XtSetArg(args[n], XmNtopOffset, 2); n++;
    XtSetArg(args[n], XmNleftOffset, 2); n++;
    XtSetArg(args[n], XmNrightOffset, 2); n++;
    Widget top=XmCreateText(message_box, "top", args, n);
    XtManageChild(top);

    XmString okText=XmStringCreateSimple("OK");
    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNleftOffset, 2); n++;
    XtSetArg(args[n], XmNrightOffset, 2); n++;
    XtSetArg(args[n], XmNbottomOffset, 2); n++;
    XtSetArg(args[n], XmNokLabelString, okText); n++;
    Widget bboard=XmCreateMessageBox(message_box, "buttons", args, n);
    XtManageChild(bboard);

    XmStringFree(okText);

    Widget it;
    if (it=XmMessageBoxGetChild(bboard, XmDIALOG_HELP_BUTTON))
      XtUnmanageChild(it);
    if (it=XmMessageBoxGetChild(bboard, XmDIALOG_CANCEL_BUTTON))
      XtUnmanageChild(it);
    if (it=XmMessageBoxGetChild(bboard, XmDIALOG_MESSAGE_LABEL))
      XtUnmanageChild(it);
    if (it=XmMessageBoxGetChild(bboard, XmDIALOG_SYMBOL_LABEL))
      XtUnmanageChild(it);

    if (it=XmMessageBoxGetChild(bboard, XmDIALOG_OK_BUTTON))
      XtAddCallback(it, XmNactivateCallback,
		    (XtCallbackProc)unmanageCB, (XtPointer)message_box);

    n=0;
    XtSetArg(args[n], XmNdefaultButton, it); n++;
    XtSetValues(bboard, args, n);

    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNbottomWidget, bboard); n++;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNtopWidget, top); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNeditable, False); n++;
    XtSetArg(args[n], XmNcursorPositionVisible, False); n++;
    XtSetArg(args[n], XmNeditMode, XmMULTI_LINE_EDIT); n++;
    XtSetArg(args[n], XmNvalue, formats_text); n++;
    XtSetArg(args[n], XmNshadowThickness, 0); n++;
    XtSetArg(args[n], XmNtraversalOn, False); n++;
    XtSetArg(args[n], XmNleftOffset, 2); n++;
    XtSetArg(args[n], XmNrightOffset, 2); n++;
    XtSetArg(args[n], XmNtraversalOn, False); n++;
    XtSetArg(args[n], XmNwidth, 50); n++;
    Widget formats=XmCreateText(message_box, "formats", args, n);
    XtManageChild(formats);
    
    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNbottomWidget, bboard); n++;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNtopWidget, top); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNleftWidget, formats); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNeditable, False); n++;
    XtSetArg(args[n], XmNcursorPositionVisible, False); n++;
    XtSetArg(args[n], XmNeditMode, XmMULTI_LINE_EDIT); n++;
    XtSetArg(args[n], XmNvalue, descrip_text); n++;
    XtSetArg(args[n], XmNshadowThickness, 0); n++;
    XtSetArg(args[n], XmNtraversalOn, False); n++;
    XtSetArg(args[n], XmNleftOffset, 2); n++;
    XtSetArg(args[n], XmNrightOffset, 2); n++;
    XtSetArg(args[n], XmNwidth, 300); n++;
    XtSetArg(args[n], XmNheight, numFormats * 14); n++;
    Widget descrip=XmCreateText(message_box, "descrip", args, n);
    XtManageChild(descrip);

    free( formats_text );
    free( descrip_text );
    return(message_box);
}

static Widget about_init(Widget w)
{
    Arg args[10];
    register int n;
    char *text= "\
Imxdisplay version 3.0\n\
\n\
By Jason Secosky\n\
\n\
This is a Motif based tool designed\n\
for viewing a sequence of images (generally, an animation).\n\
\n\
M-anim version 1.0 by Robert Earhart and Joel Welling\n\
\n\
Copyright 1994, Pittsburgh Supercomputing Center and \n\
San Diego Supercomputer Center";

    n=0;
    XmString helpText=XmStringCreateLtoR(text, XmSTRING_DEFAULT_CHARSET);
    XmString okText=XmStringCreateSimple("OK");
    XtSetArg(args[n], XmNmessageString, helpText); n++;
    XtSetArg(args[n], XmNokLabelString, okText); n++;
    XtSetArg(args[n], XmNmessageAlignment, XmALIGNMENT_CENTER); n++;
    XtSetArg(args[n], XmNtitle, "Help"); n++;
    XtSetArg(args[n], XmNautoUnmanage, False); n++;
    Widget message_box=XmCreateMessageDialog(w, "help", args, n);
 
    Widget it;
    if (it=XmMessageBoxGetChild(message_box, XmDIALOG_HELP_BUTTON))
      XtUnmanageChild(it);
    if (it=XmMessageBoxGetChild(message_box, XmDIALOG_CANCEL_BUTTON))
      XtUnmanageChild(it);

    Widget button=XmMessageBoxGetChild(message_box, XmDIALOG_OK_BUTTON);
    XtAddCallback(button, XmNactivateCallback,
		  (XtCallbackProc)unmanageCB, (XtPointer)message_box);
    
    XmStringFree(okText);
    XmStringFree(helpText);
    return(message_box);
}

static void openCB(Widget w, Boolean *done, caddr_t call_data)
{
	return;
}

static void quitCB(Widget w, Boolean *done, caddr_t call_data)
{
    *done=True;
}

typedef struct redraw_struct {
    XtAppContext app_context;
    int number, current;
    XImageHandler **the_images;
    int argc;
    char **argv;
    char **formats;
    Widget top;
    Widget the_picture, sb, message_box;
    XmString readyString, renderingString, forwardString, backwordString;
    Widget playb, stop, playf, active, once, repeat, bounce;
    Widget dither, perfect, shared, colorSpace;
    XtIntervalId timer;
    unsigned long timeout;
    int stepsize;
    Boolean time_installed;
} redraw_data;

/*
 *  Store information about the image here, should really be in main(),
 *  but I need to access this data structure from withing the translation
 *  callbacks.  Unfortunately I have not figured out a way to pass this
 *  data into them.  Maybe if they were a member function?
 */

redraw_data *the_data = new redraw_data;


static void animate_proc(redraw_data *cdat) {

    Boolean re_add = True; /*Toggle for whether to add work proc again or not*/

    cdat->time_installed = False;

    if (cdat->stepsize > 0)
	if ((cdat->current + cdat->stepsize) > cdat->number)
	    if (XmToggleButtonGadgetGetState(cdat->once)) {
		cdat->current = cdat->number;
		re_add = False;
		XmToggleButtonGadgetSetState(cdat->stop,True, True);
	    } else
		if (XmToggleButtonGadgetGetState(cdat->repeat))
		    cdat->current = 1;
		else {			/* Must be bouncing */
		    cdat->current=cdat->number;
		    XmToggleButtonGadgetSetState(cdat->playb,True, True);
		}
	else cdat->current+=cdat->stepsize;
    else if (cdat->stepsize < 0)
	if ((cdat->current + cdat->stepsize) < 1)
	    if (XmToggleButtonGadgetGetState(cdat->once)) {
		cdat->current = 1;
		re_add = False;
		XmToggleButtonGadgetSetState(cdat->stop,True, True);
	    } else if (XmToggleButtonGadgetGetState(cdat->repeat))
		cdat->current = cdat->number;
	    else {   			/* Must be boucing */
		cdat->current= 1;
		XmToggleButtonGadgetSetState(cdat->playf, True, True);
	    }
	else
	    cdat->current += cdat->stepsize;
    else
	re_add = False;
    
    int value, slider, increment, page;
    XmScrollBarGetValues(cdat->sb, &value, &slider, &increment, &page);
    XmScrollBarSetValues(cdat->sb, cdat->current, slider, increment, page,
			 False);
    if (re_add && (! cdat->time_installed)) {
	cdat->timer=XtAppAddTimeOut(cdat->app_context, cdat->timeout,
				    (XtTimerCallbackProc)&animate_proc,
				    (XtPointer) cdat);
	cdat->time_installed = True;
    }
    
    cdat->the_images[cdat->current]->redraw(); /* This should definitly happen
						AFTER we reinstall this proc,
						so the timeouts look better.*/
}

static void movestyleCB(Widget w, redraw_data *cdat,
			XmToggleButtonCallbackStruct *call_data)
{
    if (! (XmToggleButtonGadgetGetState(w))) {
	XmToggleButtonGadgetSetState(w, True, False);
	return;
    }

    if (w != cdat->once)
	XmToggleButtonGadgetSetState(cdat->once, False, False);
    if (w != cdat->repeat)
	XmToggleButtonGadgetSetState(cdat->repeat, False, False);
    if (w != cdat->bounce)
	XmToggleButtonGadgetSetState(cdat->bounce, False, False);
}

static void toggleplayCB(Widget w, redraw_data *cdat,
			 XmToggleButtonCallbackStruct *call_data)
{
    Arg args[15];
    register int n;
    
    if (! (XmToggleButtonGadgetGetState(w))) {
	XmToggleButtonGadgetSetState(w, True, False);
	return;
    }

    XmToggleButtonGadgetSetState(cdat->active, False, False);
    
    n=0;
    XtSetArg(args[n], XmNdialogType, XmDIALOG_INFORMATION); n++;
    
    if (w == cdat->stop) {
	XmProcessTraversal(cdat->active, XmTRAVERSE_CURRENT);
	XmProcessTraversal(cdat->active, XmTRAVERSE_CURRENT);
	if (cdat->time_installed) {
	    XtRemoveTimeOut(cdat->timer);
	    cdat->time_installed = False;
	}
	cdat->stepsize = 0;
	XtSetArg(args[n], XmNmessageString, cdat->readyString); n++;
    } else {
	XmProcessTraversal(cdat->stop, XmTRAVERSE_CURRENT);
	XmProcessTraversal(cdat->stop, XmTRAVERSE_CURRENT);
	if (! cdat->time_installed) {
	    cdat->timer=XtAppAddTimeOut(cdat->app_context, cdat->timeout,
					(XtTimerCallbackProc)&animate_proc,
					(XtPointer) cdat);
	    cdat->time_installed = True;
	}
	if (w == cdat->playf) {
	    cdat->stepsize = 1;
	    XtSetArg(args[n], XmNmessageString, cdat->forwardString); n++;
	}
	else {
	    cdat->stepsize = -1;
	    XtSetArg(args[n], XmNmessageString, cdat->backwordString); n++;
	}
    }
    XtSetValues(cdat->message_box, args, n);
    cdat->active = w;
}

static void scrollCB(Widget w, redraw_data *cdat,
		     XmScrollBarCallbackStruct *call_data);

static void redrawCB(Widget w, redraw_data *cdat,
		     XmDrawingAreaCallbackStruct *call_data)
{
    int i;

    if (! XtIsRealized(w))
	return;
    if (! cdat->the_images) {			/* groan... read them in... */
	Arg args[15];
	register int n;	

	cdat->the_images = (XImageHandler **)calloc((cdat->number) + 1,
						sizeof(XImageHandler *));
	if (! cdat->the_images) {
	    perror(ImToolsProgram);
	    exit(1);
	}

	Cursor watch=XCreateFontCursor(XtDisplay(w), XC_watch);
	n=0;
	XtSetArg(args[n], XmNdialogType, XmDIALOG_WORKING); n++;
	XtSetArg(args[n], XmNmessageString, cdat->renderingString); n++;
	XtSetValues(cdat->message_box, args, n);
    
	XDefineCursor(XtDisplay(w), XtWindow(cdat->top), watch);
	rgbImage *the_image;
	FILE *the_file;

	XtRemoveCallback(w, XmNexposeCallback,
			 (XtCallbackProc) redrawCB,
			 (XtPointer) cdat);
	    
	/*I wish I knew why this call needs to be made twice... but it does
	  so I will.*/
	XmProcessTraversal(cdat->sb, XmTRAVERSE_CURRENT);
	XmProcessTraversal(cdat->sb, XmTRAVERSE_CURRENT);
	
	/*
	 *  Check to make sure all of the files may be read in order
	 *  to check for typos from the command line.
	 */

	for (i = 1; i < (cdat->argc); i++ )
	{
		if ( access( cdat->argv[i], R_OK ) == -1 )
		{
			fprintf( stderr, "%s: Input file %s cannot be read.\n", ImToolsProgram, cdat->argv[i] );
			exit( 1 );
		}
	}

        XEvent the_event;
	char strFileName[128];
	XmString xFileName;
	int tmpCurrent = cdat->current;
	for (int count=1; count<(cdat->argc); count++) {
	    /*
	     *  Needed for call to installCltCB
	     *  or else may not have allocated and will seg fault
	     */

	    cdat->current = count;
	    n=0;
	    XtSetArg(args[n], XmNvalue, count); n++;
	    XtSetValues(cdat->sb, args, n);

	    sprintf( strFileName, "Loading (%d/%d): %s", count,
			cdat->number, cdat->argv[count] );
	    xFileName=XmStringCreateSimple( strFileName );
	    XtSetArg( args[n], XmNmessageString, xFileName ); n++;
	    XtSetValues( cdat->message_box, args, n );
	    XmStringFree( xFileName );
	    
	    XmUpdateDisplay(w);

	    if (! (the_file=fopen(cdat->argv[count], "r"))) {
		perror(ImToolsProgram);
		exit(1);
	    }

	    the_image=new rgbImage(the_file, cdat->argv[count],
				cdat->formats[count]);
	    if (! the_image->valid()) {
		fprintf(stderr, "%s: Invalid image file %s\n",
			ImToolsProgram, cdat->argv[count]);
		exit(1);
	    }

	    cdat->the_images[count]= new XImageHandler(XtDisplay(w),
						       0, XtWindow(w));
	    
	    if (! cdat->the_images[count]) {
		perror(ImToolsProgram);
		exit(1);
	    }
	    
	    cdat->the_images[count]->display(the_image, True);

	    /*
	     *  Watch for the enter and leave window events on the 
	     *  drawable area so that we will switch colormaps
	     *  when the next image is displayed.  Leave all other
	     *  X events in the input queue to be processed later
	     */

	    while ( XCheckWindowEvent( XtDisplay( w ),
	    				XtWindow( cdat->the_picture ), 
					EnterWindowMask | LeaveWindowMask,
					&the_event ) )
	    {
		XtDispatchEvent( &the_event );
	    }

	    fclose(the_file);
	    delete(the_image); 
	}
	/*
	 *  Remember what current use to be before we went through
	 *  above loop.
	 */
	cdat->current = tmpCurrent;

	XUndefineCursor(XtDisplay(w), XtWindow(cdat->top));
	n=0;
	XtSetArg(args[n], XmNdialogType, XmDIALOG_INFORMATION); n++;
	XtSetArg(args[n], XmNmessageString, cdat->readyString); n++;
 	XtSetValues(cdat->message_box, args, n);


	n=0;
	XtSetArg(args[n], XmNvalue, cdat->current); n++;
	XtSetValues(cdat->sb, args, n);

	XmUpdateDisplay(w);

	XtAddCallback(cdat->sb, XmNvalueChangedCallback,
		      (XtCallbackProc) scrollCB,
		      (XtPointer) cdat);

/*
  XtAddCallback(cdat->sb, XmNdragCallback,
  (XtCallbackProc) scrollCB,
  (XtPointer) cdat);
*/
	XtAddCallback(w, XmNexposeCallback,
			 (XtCallbackProc) redrawCB,
			 (XtPointer) cdat);

	/*I wish I knew why this call needs to be made twice... but it does
	  so I will.*/
	XmProcessTraversal(cdat->playf, XmTRAVERSE_CURRENT);
	XmProcessTraversal(cdat->playf, XmTRAVERSE_CURRENT);
    }
    cdat->the_images[cdat->current]->redraw();
    cdat->time_installed = False;
}




static void colorSpaceCB(Widget w, redraw_data *cdat,
			XmToggleButtonCallbackStruct *call_data)
{
    Arg args[5];
    int i, n;
    static Widget priorW = NULL;

    if ( priorW == NULL )
    {
	switch( SubVisual )
	{
	case XIH_VCUSTOM:
		priorW = cdat->perfect;
		break;
	case XIH_VPSEUDO:
		priorW = cdat->dither;
		break;
	case XIH_VSHARED:
		priorW = cdat->shared;
		break;
	default:
		priorW = cdat->perfect;
		break;
	}
    }


    if (! (XmToggleButtonGadgetGetState(w))) {
	XmToggleButtonGadgetSetState(w, True, False);
	return;
    }

    if ( priorW != NULL )
    {
	XmToggleButtonGadgetSetState(priorW, False, False);
    }

    priorW = w;

    if ( w == cdat->dither )
	SubVisual = XIH_VPSEUDO;
    else if ( w == cdat->perfect )
	SubVisual = XIH_VCUSTOM;
    else if ( w == cdat->shared )
    {
	initedClt = 0;
	SubVisual = XIH_VSHARED;
    }
    else
	SubVisual = XIH_VPSEUDO;

    for (n=1; n <= cdat->number; n++)
    {
	/*
	 *  Uninstall all colormaps and indicate that we may need to init
	 *  up another colormap by reseting the map_info_set private 
	 *  variable using the resetMapInfo member function
	 */

    	cdat->the_images[n]->resetMapInfo();
	cdat->the_images[n]->unInstallClt();
	delete( cdat->the_images[n] );
    }
    delete( cdat->the_images );
    cdat->the_images = NULL;

    /*
     *  Read in the images again
     */

    redrawCB( cdat->the_picture, cdat, NULL );
}




static void installCltCB( Widget w, XEvent *event, String *params, 
				Cardinal numParams )
{
    if (! XtIsRealized(w))
	return;
    okClt = True;
    the_data->the_images[the_data->current]->installClt();
}



static void unInstallCltCB( Widget w, XEvent *event, String *params, 
				Cardinal numParams )
{
    if (! XtIsRealized(w))
	return;
    okClt = False;
    the_data->the_images[the_data->current]->unInstallClt();
}


static void set_speedCB(Widget w, redraw_data *cdat,
		     XmToggleButtonCallbackStruct *call_data)
{
    Arg args[1];
    if (call_data->set) {
	XtSetArg(args[0], XmNuserData, &cdat->timeout);
	XtGetValues(w, args, 1);
    }
}

static void scrollCB(Widget w, redraw_data *cdat,
		     XmScrollBarCallbackStruct *call_data)
{
    cdat->current=call_data->value;
    cdat->the_images[cdat->current]->redraw();
    if (! cdat->time_installed)		/* do NOT reinstall. :) */
	cdat->timer=XtAppAddTimeOut(cdat->app_context, cdat->timeout,
				    (XtTimerCallbackProc)&animate_proc,
				    (XtPointer) cdat);
}






int main(unsigned argc, char *argv[]) {
    Arg args[15];
    register int n;
    Display *display;
    Visual *visual;
    Widget top;
    XtTranslations transTable;
    XtActionsRec actions[] =
	{
		{ "installCltCB", installCltCB },
		{ "unInstallCltCB", unInstallCltCB },
	};

    String translations = 
	"<EnterWindow>:	installCltCB()\n\
	 <LeaveWindow>:	unInstallCltCB()";
    okClt = False;

    XtToolkitInitialize();

    the_data->app_context = XtCreateApplicationContext();

    if ((display = XtOpenDisplay(the_data->app_context, NULL, argv[0],
				 "Imxdisplay", NULL, 0, &argc,
				 argv)) == NULL) {
	fprintf(stderr, "\n%s: Can't open display\n", argv[0]);
	exit(1);
    }
    toolInit( argc, argv );

    /*
     *  Add the EnterNotify, LeaveNotify actions funcions used by translations
     *  parsed below.
     */
    XtAppAddActions( the_data->app_context, actions, XtNumber( actions ) );
    transTable = XtParseTranslationTable(translations);

    n=0;
    XtSetArg(args[n], XmNargc, argc); n++;
    XtSetArg(args[n], XmNargv, argv); n++;
    XtSetArg(args[n], XmNmwmFunctions, -MWM_FUNC_RESIZE); n++;
    XtSetArg(args[n], XmNmwmDecorations, -MWM_DECOR_RESIZEH
             -MWM_DECOR_BORDER); n++;
    Widget toplevel=XtAppCreateShell(argv[0], "Imxdisplay",
				     applicationShellWidgetClass,
				     display, args, n);


    the_data->number = toolNInFiles;
    the_data->current = 1;
    the_data->the_images = NULL;
    the_data->argc = toolNInFiles+1;
    the_data->argv = toolInFilenames;
    the_data->formats = toolInFormats;

    
    /*Main window*/
    n=0;
    the_data->top=XmCreateMainWindow(toplevel, "main", args, n);
    XtManageChild(the_data->top);
 
    /*Menu bar*/
    n=0;
    Widget menu_bar = XmCreateMenuBar(the_data->top, "menubar", args, n);
    XtManageChild(menu_bar);

    /*File Menu*/
    n=0;
    Widget menu_pane = XmCreatePulldownMenu(menu_bar, "file_menu", args, n);

    Boolean done;
    
    n=0;
    XmString labelString=XmStringCreateSimple("Open");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    Widget button = XmCreatePushButton(menu_pane, "open", args, n);
    XtManageChild(button);
    XtAddCallback(button, XmNactivateCallback,
                  (XtCallbackProc) openCB, (XtPointer)&done);
    XmStringFree(labelString);
    XtSetSensitive( button, False );

    n=0;
    Widget sep = XmCreateSeparatorGadget(menu_pane, "sep", args, n);
    XtManageChild(sep);

    n=0;
    labelString=XmStringCreateSimple("Exit");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    button = XmCreatePushButton(menu_pane, "quit", args, n);
    XtManageChild(button);
    XtAddCallback(button, XmNactivateCallback,
                  (XtCallbackProc) quitCB, (XtPointer)&done);
    XmStringFree(labelString);

    n=0;
    labelString=XmStringCreateSimple("File");
    XtSetArg(args[n], XmNsubMenuId, menu_pane); n++;
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    Widget cascade = XmCreateCascadeButton (menu_bar, "file", args, n);
    XtManageChild(cascade);
    XmStringFree(labelString);

    /*Control Menu*/
    n=0;
    menu_pane = XmCreatePulldownMenu(menu_bar, "control_menu", args, n);

    /*
     *  Set up menu buttons for different color space options.
     *
     *  Use Own Colormap / Perfect Color:
     *		When each image is displayed on the screen, its own
     *		colormap is also installed.
     *
     *	Force to First / Shared Color:
     *		Force all images to use the colormap of the first
     *		loaded image.  This is done so that only one colormap
     *		is installed.  This option is useful in order prevent
     *		color flickering on 8-bit displays with homogeneous
     *		images.  This requires that all images be remapped to the
     *		first image's colormap.
     *
     *	Dither / Pseudocolor
     *		Dither all images at load time and use one colormap
     *		for all.  The installed colormap will grab as many 
     *		colors as possible from the System/Default colormap.
     *
     */

    n=0;
    labelString=XmStringCreateSimple("Use Own Colormap");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNindicatorType, XmONE_OF_MANY); n++;
    if ( SubVisual == XIH_VCUSTOM )
    {
	    XtSetArg(args[n], XmNset, True); n++;
    }
    else
    {
	    XtSetArg(args[n], XmNset, False); n++;
    }
    the_data->perfect = XmCreateToggleButtonGadget(menu_pane, "perfect", args,
						  n);
    XtManageChild(the_data->perfect);
    XtAddCallback(the_data->perfect, XmNvalueChangedCallback,
                  (XtCallbackProc) colorSpaceCB, (XtPointer)the_data);
    XmStringFree(labelString);

    n=0;
    labelString=XmStringCreateSimple("Force to First");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNindicatorType, XmONE_OF_MANY); n++;
    if ( SubVisual == XIH_VSHARED )
    {
	    XtSetArg(args[n], XmNset, True); n++;
    }
    else
    {
	    XtSetArg(args[n], XmNset, False); n++;
    }
    the_data->shared = XmCreateToggleButtonGadget(menu_pane, "shared", args, n);
    XtManageChild(the_data->shared);
    XtAddCallback(the_data->shared, XmNvalueChangedCallback,
                  (XtCallbackProc) colorSpaceCB, (XtPointer)the_data);
    XmStringFree(labelString);

    n=0;
    labelString=XmStringCreateSimple("Dither");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNindicatorType, XmONE_OF_MANY); n++;
    if ( SubVisual == XIH_VPSEUDO )
    {
	    XtSetArg(args[n], XmNset, True); n++;
    }
    else
    {
	    XtSetArg(args[n], XmNset, False); n++;
    }
    the_data->dither = XmCreateToggleButtonGadget(menu_pane, "dither", args, n);
    XtManageChild(the_data->dither);
    XtAddCallback(the_data->dither, XmNvalueChangedCallback,
                  (XtCallbackProc) colorSpaceCB, (XtPointer)the_data);
    XmStringFree(labelString);

    n=0;
    sep = XmCreateSeparatorGadget(menu_pane, "sep", args, n);
    XtManageChild(sep);

    n=0;
    labelString=XmStringCreateSimple("Once Only");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNindicatorType, XmONE_OF_MANY); n++;
    XtSetArg(args[n], XmNset, True); n++;
    the_data->once = XmCreateToggleButtonGadget(menu_pane, "once", args, n);
    XtManageChild(the_data->once);
    XtAddCallback(the_data->once, XmNvalueChangedCallback,
                  (XtCallbackProc) movestyleCB, (XtPointer)the_data);
    XmStringFree(labelString);

    n=0;
    labelString=XmStringCreateSimple("Repeat");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNindicatorType, XmONE_OF_MANY); n++;
    the_data->repeat = XmCreateToggleButtonGadget(menu_pane, "repeat", args,
						  n);
    XtManageChild(the_data->repeat);
    XtAddCallback(the_data->repeat, XmNvalueChangedCallback,
                  (XtCallbackProc) movestyleCB, (XtPointer)the_data);
    XmStringFree(labelString);

    n=0;
    labelString=XmStringCreateSimple("Bounce");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNindicatorType, XmONE_OF_MANY); n++;
    the_data->bounce = XmCreateToggleButtonGadget(menu_pane, "bounce", args,
						  n);
    XtManageChild(the_data->bounce);
    XtAddCallback(the_data->bounce, XmNvalueChangedCallback,
                  (XtCallbackProc) movestyleCB, (XtPointer)the_data);
    XmStringFree(labelString);

    n=0;
    sep = XmCreateSeparatorGadget(menu_pane, "sep", args, n);
    XtManageChild(sep);

    n=0;
    XtSetArg(args[n], XmNradioBehavior, True); n++;
    XtSetArg(args[n], XmNradioAlwaysOne, True); n++;
    Widget delay_menu_pane = XmCreatePulldownMenu(menu_pane, "delay_menu",
						  args, n);

    n=0;
    labelString=XmStringCreateSimple("0 ms.");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNuserData, 1); n++;
    button = XmCreateToggleButtonGadget(delay_menu_pane, "0", args, n); n++;
    XtManageChild(button);
    XtAddCallback(button, XmNvalueChangedCallback,
                  (XtCallbackProc) set_speedCB, (XtPointer)the_data);

    n=0;
    labelString=XmStringCreateSimple("30 ms.");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNuserData, 30); n++;
    button = XmCreateToggleButtonGadget(delay_menu_pane, "30", args, n); n++;
    XtManageChild(button);
    XtAddCallback(button, XmNvalueChangedCallback,
                  (XtCallbackProc) set_speedCB, (XtPointer)the_data);
    
    n=0;
    labelString=XmStringCreateSimple("60 ms.");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNuserData, 60); n++;
    XtSetArg(args[n], XmNset, True); n++;
    button = XmCreateToggleButtonGadget(delay_menu_pane, "60", args, n); n++;
    XtManageChild(button);
    XtAddCallback(button, XmNvalueChangedCallback,
                  (XtCallbackProc) set_speedCB, (XtPointer)the_data);
    
    the_data->timeout = 60;
    
    n=0;
    labelString=XmStringCreateSimple("100 ms.");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNuserData, 100); n++;
    button = XmCreateToggleButtonGadget(delay_menu_pane, "100", args, n); n++;
    XtManageChild(button);
    XtAddCallback(button, XmNvalueChangedCallback,
                  (XtCallbackProc) set_speedCB, (XtPointer)the_data);
    
    n=0;
    labelString=XmStringCreateSimple("150 ms.");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNuserData, 150); n++;
    button = XmCreateToggleButtonGadget(delay_menu_pane, "150", args, n); n++;
    XtManageChild(button);
    XtAddCallback(button, XmNvalueChangedCallback,
                  (XtCallbackProc) set_speedCB, (XtPointer)the_data);
    
    n=0;
    labelString=XmStringCreateSimple("200 ms.");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNuserData, 200); n++;
    button = XmCreateToggleButtonGadget(delay_menu_pane, "200", args, n); n++;
    XtManageChild(button);
    XtAddCallback(button, XmNvalueChangedCallback,
                  (XtCallbackProc) set_speedCB, (XtPointer)the_data);
    
    n=0;
    labelString=XmStringCreateSimple("Delay");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNsubMenuId, delay_menu_pane); n++;
    button  = XmCreateCascadeButtonGadget(menu_pane, "delay", args, n);
    XtManageChild(button);
    XmStringFree(labelString);

    n=0;
    labelString=XmStringCreateSimple("Control");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNsubMenuId, menu_pane); n++;
    cascade=XmCreateCascadeButton(menu_bar, "control", args, n);
    XtManageChild(cascade);
    XmStringFree(labelString);
    
    /*Help Menu*/
    n=0;
    menu_pane = XmCreatePulldownMenu(menu_bar, "help_menu", args, n);
 
    n=0;
    labelString=XmStringCreateSimple("How It Works...");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    button = XmCreatePushButton(menu_pane, "how", args, n);
    XtManageChild(button);
    XtAddCallback(button, XmNactivateCallback,
                  (XtCallbackProc) manage_meCB,
                  (XtPointer) works_init(toplevel));
    XmStringFree(labelString);
    
    n=0;
    labelString=XmStringCreateSimple("Image Formats...");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    button = XmCreatePushButton(menu_pane, "formats", args, n);
    XtManageChild(button);
    XtAddCallback(button, XmNactivateCallback,
                  (XtCallbackProc) manage_meCB,
                  (XtPointer) formats_init(toplevel));
    XmStringFree(labelString);

    n=0;
    sep = XmCreateSeparatorGadget(menu_pane, "sep", args, n);
    XtManageChild(sep);
    
    n=0;
    labelString=XmStringCreateSimple("About...");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    button = XmCreatePushButton(menu_pane, "about", args, n);
    XtManageChild(button);
    XtAddCallback(button, XmNactivateCallback,
                  (XtCallbackProc) manage_meCB,
                  (XtPointer) about_init(toplevel));
    XmStringFree(labelString);
    
    n=0;
    labelString=XmStringCreateSimple("Help");
    XtSetArg(args[n], XmNlabelString, labelString); n++;
    XtSetArg(args[n], XmNsubMenuId, menu_pane); n++;
    cascade=XmCreateCascadeButton(menu_bar, "help", args, n);
    XtManageChild(cascade);
    XmStringFree(labelString);
 
    n=0;
    XtSetArg(args[n], XmNmenuHelpWidget, cascade); n++;
    XtSetValues(menu_bar, args, n);


    n=0;
    Widget mainform=XmCreateForm(the_data->top, "mainform", args, n);
    XtManageChild(mainform);

    XmMainWindowSetAreas(the_data->top, menu_bar, NULL,
			 NULL, NULL, mainform);

    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM); n++;
    Widget frame=XmCreateFrame(mainform, "frame", args, n);
    XtManageChild(frame);

    n=0;
    XtSetArg(args[n], XmNfractionBase, 2); n++;
    Widget form=XmCreateForm(frame, "form", args, n);
    XtManageChild(form);
    
    the_data->readyString=XmStringCreateSimple("Ready.");
    the_data->renderingString=XmStringCreateSimple("Loading Images...");
    the_data->forwardString=XmStringCreateSimple("Animating Forwards...");
    the_data->backwordString=XmStringCreateSimple("Animating Backwords...");
    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION); n++;
    XtSetArg(args[n], XmNrightPosition, 1); n++;
    XtSetArg(args[n], XmNmessageString, the_data->readyString); n++;
    XtSetArg(args[n], XmNdialogType, XmDIALOG_INFORMATION); n++;
    the_data->message_box=XmCreateMessageBox(form, "message_box",
					     args, n);
    XtManageChild(the_data->message_box);

    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET); n++;
    XtSetArg(args[n], XmNtopWidget, the_data->message_box); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNleftWidget, the_data->message_box); n++;
    XtSetArg(args[n], XmNorientation, XmVERTICAL); n++;
    sep=XmCreateSeparatorGadget(form, "sep1", args, n);
    XtManageChild(sep);

    Widget it;
    if (it=XmMessageBoxGetChild(the_data->message_box, XmDIALOG_CANCEL_BUTTON))
	XtUnmanageChild(it);
    if (it=XmMessageBoxGetChild(the_data->message_box, XmDIALOG_HELP_BUTTON))
	XtUnmanageChild(it);
    if (it=XmMessageBoxGetChild(the_data->message_box, XmDIALOG_OK_BUTTON))
	XtUnmanageChild(it);
    if (it=XmMessageBoxGetChild(the_data->message_box, XmDIALOG_SEPARATOR))
	XtUnmanageChild(it);


    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET); n++;
    XtSetArg(args[n], XmNtopWidget, the_data->message_box); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNleftWidget, sep); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNfractionBase, 3); n++;
    Widget rc=XmCreateForm(form, "rc", args, n);
    XtManageChild(rc);

    Cardinal dep;
    Pixel fg, bg;
    
    n=0;
    XtSetArg(args[n], XmNdepth, &dep); n++;
    XtSetArg(args[n], XmNforeground, &fg); n++;
    XtSetArg(args[n], XmNbackground, &bg); n++;
    XtGetValues(rc, args, n);
    
    n=0;
    XtSetArg(args[n], XmNlabelPixmap,
	     XCreatePixmapFromBitmapData(display,
					 DefaultRootWindow(display),
					 playb_bits, playb_width,
					 playb_height, fg, bg, dep));n++;
    XtSetArg(args[n], XmNlabelType, XmPIXMAP); n++;
    XtSetArg(args[n], XmNindicatorOn, False); n++;
    XtSetArg(args[n], XmNshadowThickness, 2); n++;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION); n++;
    XtSetArg(args[n], XmNrightPosition, 1); n++;
    the_data->playb=XmCreateToggleButtonGadget(rc, "playb", args, n);
    XtManageChild(the_data->playb);
    XtAddCallback(the_data->playb, XmNvalueChangedCallback,
                  (XtCallbackProc) toggleplayCB,
                  (XtPointer) the_data);

    n=0;
    XtSetArg(args[n], XmNlabelPixmap,
	     XCreatePixmapFromBitmapData(display,
					 DefaultRootWindow(display),
					 stop_bits, stop_width,
					 stop_height, fg, bg, dep));n++;
    XtSetArg(args[n], XmNlabelType, XmPIXMAP); n++;
    XtSetArg(args[n], XmNindicatorOn, False); n++;
    XtSetArg(args[n], XmNshadowThickness, 2); n++;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION); n++;
    XtSetArg(args[n], XmNleftPosition, 1); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION); n++;
    XtSetArg(args[n], XmNrightPosition, 2); n++;
    XtSetArg(args[n], XmNset, True); n++;
    the_data->stop=XmCreateToggleButtonGadget(rc, "stop", args, n);
    XtManageChild(the_data->stop);
    XtAddCallback(the_data->stop, XmNvalueChangedCallback,
                  (XtCallbackProc) toggleplayCB,
                  (XtPointer) the_data);

    n=0;
    XtSetArg(args[n], XmNlabelPixmap,
	     XCreatePixmapFromBitmapData(display,
					 DefaultRootWindow(display),
					 playf_bits, playf_width,
					 playf_height, fg, bg, dep));n++;
    XtSetArg(args[n], XmNlabelType, XmPIXMAP); n++;
    XtSetArg(args[n], XmNindicatorOn, False); n++;
    XtSetArg(args[n], XmNshadowThickness, 2); n++;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION); n++;
    XtSetArg(args[n], XmNleftPosition, 2); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    the_data->playf=XmCreateToggleButtonGadget(rc, "playf", args, n);
    XtManageChild(the_data->playf);
    XtAddCallback(the_data->playf, XmNvalueChangedCallback,
                  (XtCallbackProc) toggleplayCB,
                  (XtPointer) the_data);

    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNbottomWidget, sep); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    Widget sep2=XmCreateSeparatorGadget(form, "sep2", args, n);
    XtManageChild(sep2);

    n=0;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET); n++; 
    XtSetArg(args[n], XmNbottomWidget, sep2); n++; 
    XtSetArg(args[n], XmNsliderSize, 1); n++;
    XtSetArg(args[n], XmNminimum, 1); n++;
    XtSetArg(args[n], XmNmaximum, the_data->argc); n++;
    XtSetArg(args[n], XmNvalue, 1); n++;
    XtSetArg(args[n], XmNorientation, XmHORIZONTAL); n++;
    the_data->sb=XmCreateScrollBar(form, "sb", args, n);
    XtManageChild(the_data->sb);

    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNbottomWidget, the_data->sb); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    sep2=XmCreateSeparatorGadget(form, "sep3", args, n);
    XtManageChild(sep2);

    FILE *the_file;			/* HACK hack hack... shh... :) */
    if (! (the_file=fopen(the_data->argv[1], "r"))) {
	perror(ImToolsProgram);
	exit(1);
    }

    rgbImage *the_image=new rgbImage( the_file, the_data->argv[1],
				the_data->formats[1] );
    if (! the_image->valid()) {
	fprintf(stderr, "%s: Invalid image file %s\n", ImToolsProgram,
		the_data->argv[1]);
	exit(1);
    }
    
    n=0;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET); n++;
    XtSetArg(args[n], XmNbottomWidget, sep2); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNwidth, the_image->xsize()); n++;
    XtSetArg(args[n], XmNheight, the_image->ysize()); n++;
    the_data->the_picture=XmCreateDrawingArea(form, "draw", args, n);
    XtManageChild(the_data->the_picture);

    XtOverrideTranslations( the_data->the_picture, transTable );
    XtAddCallback(the_data->the_picture, XmNexposeCallback,
                  (XtCallbackProc) redrawCB,
                  (XtPointer) the_data);

    fclose(the_file);
    delete the_image;

    the_data->active = the_data->stop;
    
    XEvent the_event;
    
    XtRealizeWidget(toplevel);

    /*
     *  If this is a 24 bit display then grey out the color space
     *  menu since dithering / perfect color is not necessary
     */

    {
	XWindowAttributes win_attrs;
	XGetWindowAttributes(display, XtWindow(toplevel), &win_attrs);
	visual = win_attrs.visual;
    }

    switch (visual->c_class)
    {
    case (int)TrueColor:
    case (int)DirectColor:
	XtSetSensitive( the_data->colorSpace, False );
	XtSetSensitive( the_data->perfect, False );
	XtSetSensitive( the_data->dither, False );
    default:
	break;
	/*
	 *  For all other visual, leave sensitized/active
	 */
    	break;
    }
    

    for (done = False; ! done ;) {
        XtAppNextEvent(the_data->app_context, &the_event);
        XtDispatchEvent(&the_event);
    };

    /*When we're done, we *MUST* delete our XImageHandlers, because they
      *COULD* be using shared memory images, and we don't want to leave
      those lying around the machine...*/

    for (n=1; n <= the_data->number; n++)
	delete(the_data->the_images[n]);
}
