/****************************************************************************
 * imagehandler.cc
 * Author Joel Welling
 * Copyright 1993, Pittsburgh Supercomputing Center, Carnegie Mellon University
 *
 * Permission use, copy, and modify this software and its documentation
 * without fee for personal use or use within your organization is hereby
 * granted, provided that the above copyright notice is preserved in all
 * copies and that that copyright and this permission notice appear in
 * supporting documentation.  Permission to redistribute this software to
 * other organizations or individuals is not granted;  that must be
 * negotiated with the PSC.  Neither the PSC nor Carnegie Mellon
 * University make any representations about the suitability of this
 * software for any purpose.  It is provided "as is" without express or
 * implied warranty.
 *****************************************************************************/

/**
 **	$Header: /sdsc/dev/vis/image/ihandler/src/RCS/imagehandler.cc,v 1.1 94/03/23 17:35:17 secoskyj Exp $
 **	Copyright (c) 1989-1994  San Diego Supercomputer Center (SDSC)
 **		a division of General Atomics, San Diego, California, USA
 **
 **	Users and possessors of this source code are hereby granted a
 **	nonexclusive, royalty-free copyright and design patent license to
 **	use this code in individual software.  License is not granted for
 **	commercial resale, in whole or in part, without prior written
 **	permission from SDSC.  This source is provided "AS IS" without express
 **	or implied warranty of any kind.
 **
 **	For further information contact:
 **		E-Mail:		info@sds.sdsc.edu
 **
 **		Surface Mail:	Information Center
 **				San Diego Supercomputer Center
 **				P.O. Box 85608
 **				San Diego, CA  92138-5608
 **				(619) 534-5000
 **/

#define HEADER  "$Header: /sdsc/dev/vis/image/ihandler/src/RCS/imagehandler.cc,v 1.1 94/03/23 17:35:17 secoskyj Exp $"

/**
 **  FILE
 **	imagehander.cc	-  
 **
 **  PROJECT
 **	IM		-  
 **
 **  DESCRIPTION
 **
 **  PUBLIC CONTENTS
 **			d =defined constant
 **			f =function
 **			m =defined macro
 **			t =typedef/struct/union
 **			v =variable
 **			? =other
 **
 **
 **  PRIVATE CONTENTS
 **
 **  HISTORY
 **	$Log:	imagehandler.cc,v $
 **	Revision 1.1  94/03/23  17:35:17  secoskyj
 **	Initial revision
 **	
 **	
 **/


#include <stdio.h>
#include <stdlib.h>
#include <im.h>
#include <strings.h>
#include "rgbimage.h"
#include "imagehandler.h"

baseImageHandler::baseImageHandler()
{
  current_image= NULL;
}

baseImageHandler::~baseImageHandler()
{
}

fileImageHandler::fileImageHandler( char *fname_in, char *format_in )
{
  fname= new char[strlen(fname_in)+1];
  strcpy(fname,fname_in);
  format= new char[strlen(format_in)+1];
  strcpy(format, format_in);
}

fileImageHandler::~fileImageHandler()
{
  delete fname;
  delete format;
}

void fileImageHandler::display( rgbImage *image, short refresh )
{
  if (image->valid()) (void)image->save(fname,format);
}
